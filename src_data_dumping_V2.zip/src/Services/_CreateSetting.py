import pandas as pd
import json
from deepdiff import DeepDiff
from ConfigScripts import _APIConfig
from Framework.Utils import _API
from Framework.Utils import _Db
from ConfigScripts import _Configirations


setting_ids = []
TAX_SENSITIVITY_DICT = {'veryhigh':'VeryHigh','medium':'Medium','high':'High','low':'Low'}


def Create_Add_Settings_Api_Body(full_list):
    result = []
    for each_tuple in full_list:
        final_json = {
        "TaxSensitivity": "",
        "FederalLongTermTaxRate": "",
        "FederalShortTermTaxRate": "",
        "StateTaxRate": "",
        "CashRestriction":{"cusip":"","cashRestrictionAmount":""} ,
        "SecurityRestrictions": [{"Cusip":"","Ticker":"","Description":"","SecurityRestrictionType":""}],
        "SectorRestrictions": [{"GicsSubIndustryCode":"","GicsSubIndustryDescription":""}],
        "ShortTermRealizedGainBudgetAmount": "",
        "LongTermRealizedGainBudgetAmount": "",
        "YearToDateShortTermRealizedGainLoss": "",
        "YearToDateLongTermRealizedGainLoss": ""
        }
        
        each_df = each_tuple[1]
        if(len(each_df)==1):
            for index,row in each_df.iterrows():
                
                if(str(row['securityRestrictions__cusip']) != 'nan' and str(row['sectorRestrictions__gicsSubIndustryCode']) != 'nan'):
                    if(str(row['taxSensitivity']) != 'nan'):
                        final_json['TaxSensitivity'] = TAX_SENSITIVITY_DICT[row['taxSensitivity'].lower()]
                    else:
                        final_json['TaxSensitivity'] = None
                    if(str(row['federalLongTermTaxRate'])!='nan'):
                        final_json['FederalLongTermTaxRate'] = float(row['federalLongTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalLongTermTaxRate'] = None
                    if(str(row['federalShortTermTaxRate'])!='nan'):
                        final_json['FederalShortTermTaxRate'] = float(row['federalShortTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalShortTermTaxRate'] = None
                    if(str(row['stateTaxRate'])!='nan'):
                        final_json['StateTaxRate'] = float(row['stateTaxRate'].split('%')[0])
                    else:
                        final_json['StateTaxRate'] = None
                    # final_json['CashRestriction'] = row['cashRestriction']
                    if(str(row['cashRestriction__cusip']) != 'nan'):
                        final_json['CashRestriction']["cusip"] = row['cashRestriction__cusip']
                        final_json['CashRestriction']["cashRestrictionAmount"] = row['cashRestriction__cashRestrictionAmount']
                    else:
                        final_json['CashRestriction'] = None
                    
                    final_json['SecurityRestrictions'][0]['Cusip'] = str(row['securityRestrictions__cusip']).replace(' ','').split('.')[0]
                    final_json['SecurityRestrictions'][0]['Ticker'] = row['securityRestrictions__ticker']
                    final_json['SecurityRestrictions'][0]['Description'] = row['securityRestrictions__description']
                    final_json['SecurityRestrictions'][0]['SecurityRestrictionType'] = row['securityRestrictions__securityRestrictionType']
                    final_json['SectorRestrictions'][0]['GicsSubIndustryCode'] = str(int(row['sectorRestrictions__gicsSubIndustryCode']))
                    final_json['SectorRestrictions'][0]['GicsSubIndustryDescription'] = row['sectorRestrictions__gicsSubIndustryDescription']
                    if(str(row['shortTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['ShortTermRealizedGainBudgetAmount'] = row['shortTermRealizedGainBudgetAmount']
                    else:
                        final_json['ShortTermRealizedGainBudgetAmount'] = None
                    if(str(row['longTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['LongTermRealizedGainBudgetAmount'] = row['longTermRealizedGainBudgetAmount']
                    else:
                        final_json['LongTermRealizedGainBudgetAmount'] = None
                    if(str(row['yearToDateShortTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateShortTermRealizedGainLoss'] = row['yearToDateShortTermRealizedGainLoss']
                    else:
                        final_json['YearToDateShortTermRealizedGainLoss'] = None
                    if(str(row['yearToDateLongTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateLongTermRealizedGainLoss'] = row['yearToDateLongTermRealizedGainLoss']
                    else:
                        final_json['YearToDateLongTermRealizedGainLoss'] = None
                    
                elif(str(row['securityRestrictions__cusip']) == 'nan' and str(row['sectorRestrictions__gicsSubIndustryCode']) != 'nan'):
                    if(str(row['taxSensitivity']) != 'nan'):
                        final_json['TaxSensitivity'] = TAX_SENSITIVITY_DICT[row['taxSensitivity'].lower()]
                    else:
                        final_json['TaxSensitivity'] = None
                    if(str(row['federalLongTermTaxRate'])!='nan'):
                        final_json['FederalLongTermTaxRate'] = float(row['federalLongTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalLongTermTaxRate'] = None
                    if(str(row['federalShortTermTaxRate'])!='nan'):
                        final_json['FederalShortTermTaxRate'] = float(row['federalShortTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalShortTermTaxRate'] = None
                    if(str(row['stateTaxRate'])!='nan'):
                        final_json['StateTaxRate'] = float(row['stateTaxRate'].split('%')[0])

                    else:
                        final_json['StateTaxRate'] = None
                    # final_json['CashRestriction'] = row['cashRestriction']
                    if(str(row['cashRestriction__cusip']) != 'nan'):
                        final_json['CashRestriction']["cusip"] = row['cashRestriction__cusip']
                        final_json['CashRestriction']["cashRestrictionAmount"] = row['cashRestriction__cashRestrictionAmount']
                    else:
                        final_json['CashRestriction'] = None
                    final_json['SecurityRestrictions'] = []
                    final_json['SectorRestrictions'][0]['GicsSubIndustryCode'] = str(int(row['sectorRestrictions__gicsSubIndustryCode']))
                    final_json['SectorRestrictions'][0]['GicsSubIndustryDescription'] = row['sectorRestrictions__gicsSubIndustryDescription']
                    if(str(row['shortTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['ShortTermRealizedGainBudgetAmount'] = row['shortTermRealizedGainBudgetAmount']
                    else:
                        final_json['ShortTermRealizedGainBudgetAmount'] = None
                    if(str(row['longTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['LongTermRealizedGainBudgetAmount'] = row['longTermRealizedGainBudgetAmount']
                    else:
                        final_json['LongTermRealizedGainBudgetAmount'] = None
                    if(str(row['yearToDateShortTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateShortTermRealizedGainLoss'] = row['yearToDateShortTermRealizedGainLoss']
                    else:
                        final_json['YearToDateShortTermRealizedGainLoss'] = None
                    if(str(row['yearToDateLongTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateLongTermRealizedGainLoss'] = row['yearToDateLongTermRealizedGainLoss']
                    else:
                        final_json['YearToDateLongTermRealizedGainLoss'] = None
                    
                elif(str(row['securityRestrictions__cusip']) != 'nan' and str(row['sectorRestrictions__gicsSubIndustryCode']) == 'nan'):
                    if(str(row['taxSensitivity']) != 'nan'):
                        final_json['TaxSensitivity'] = TAX_SENSITIVITY_DICT[row['taxSensitivity'].lower()]
                    else:
                        final_json['TaxSensitivity'] = None
                    if(str(row['federalLongTermTaxRate'])!='nan'):
                        final_json['FederalLongTermTaxRate'] = float(row['federalLongTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalLongTermTaxRate'] = None
                    if(str(row['federalShortTermTaxRate'])!='nan'):
                        final_json['FederalShortTermTaxRate'] = float(row['federalShortTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalShortTermTaxRate'] = None
                    if(str(row['stateTaxRate'])!='nan'):
                        final_json['StateTaxRate'] = float(row['stateTaxRate'].split('%')[0])
                    else:
                        final_json['StateTaxRate'] = None
                    # final_json['CashRestriction'] = row['cashRestriction']
                    if(str(row['cashRestriction__cusip']) != 'nan'):
                        final_json['CashRestriction']["cusip"] = row['cashRestriction__cusip']
                        final_json['CashRestriction']["cashRestrictionAmount"] = row['cashRestriction__cashRestrictionAmount']
                    else:
                        final_json['CashRestriction'] = None
                    final_json['SecurityRestrictions'][0]['Cusip'] = str(row['securityRestrictions__cusip']).replace(' ','').split('.')[0]
                    final_json['SecurityRestrictions'][0]['Ticker'] = row['securityRestrictions__ticker']
                    final_json['SecurityRestrictions'][0]['Description'] = row['securityRestrictions__description']
                    final_json['SecurityRestrictions'][0]['SecurityRestrictionType'] = row['securityRestrictions__securityRestrictionType']
                    final_json['SectorRestrictions'] = []
                    if(str(row['shortTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['ShortTermRealizedGainBudgetAmount'] = row['shortTermRealizedGainBudgetAmount']
                    else:
                        final_json['ShortTermRealizedGainBudgetAmount'] = None
                    if(str(row['longTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['LongTermRealizedGainBudgetAmount'] = row['longTermRealizedGainBudgetAmount']
                    else:
                        final_json['LongTermRealizedGainBudgetAmount'] = None
                    if(str(row['yearToDateShortTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateShortTermRealizedGainLoss'] = row['yearToDateShortTermRealizedGainLoss']
                    else:
                        final_json['YearToDateShortTermRealizedGainLoss'] = None
                    if(str(row['yearToDateLongTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateLongTermRealizedGainLoss'] = row['yearToDateLongTermRealizedGainLoss']
                    else:
                        final_json['YearToDateLongTermRealizedGainLoss'] = None
                
                elif(str(row['securityRestrictions__cusip']) == 'nan' and str(row['sectorRestrictions__gicsSubIndustryCode']) == 'nan'):
                    if(str(row['taxSensitivity']) != 'nan'):
                        final_json['TaxSensitivity'] = TAX_SENSITIVITY_DICT[row['taxSensitivity'].lower()]
                    else:
                        final_json['TaxSensitivity'] = None
                    if(str(row['federalLongTermTaxRate'])!='nan'):
                        final_json['FederalLongTermTaxRate'] = float(row['federalLongTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalLongTermTaxRate'] = None
                    if(str(row['federalShortTermTaxRate'])!='nan'):
                        final_json['FederalShortTermTaxRate'] = float(row['federalShortTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalShortTermTaxRate'] = None
                    if(str(row['stateTaxRate'])!='nan'):
                        final_json['StateTaxRate'] = float(row['stateTaxRate'].split('%')[0])
                    else:
                        final_json['StateTaxRate'] = None
                    # final_json['CashRestriction'] = row['cashRestriction']
                    if(str(row['cashRestriction__cusip']) != 'nan'):
                        final_json['CashRestriction']["cusip"] = row['cashRestriction__cusip']
                        final_json['CashRestriction']["cashRestrictionAmount"] = row['cashRestriction__cashRestrictionAmount']
                    else:
                        final_json['CashRestriction'] = None
                    final_json['SecurityRestrictions'] = []
                    final_json['SectorRestrictions'] = []
                    if(str(row['shortTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['ShortTermRealizedGainBudgetAmount'] = row['shortTermRealizedGainBudgetAmount']
                    else:
                        final_json['ShortTermRealizedGainBudgetAmount'] = None
                    if(str(row['longTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['LongTermRealizedGainBudgetAmount'] = row['longTermRealizedGainBudgetAmount']
                    else:
                        final_json['LongTermRealizedGainBudgetAmount'] = None
                    if(str(row['yearToDateShortTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateShortTermRealizedGainLoss'] = row['yearToDateShortTermRealizedGainLoss']
                    else:
                        final_json['YearToDateShortTermRealizedGainLoss'] = None
                    if(str(row['yearToDateLongTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateLongTermRealizedGainLoss'] = row['yearToDateLongTermRealizedGainLoss']
                    else:
                        final_json['YearToDateLongTermRealizedGainLoss'] = None
                
            result.append(final_json)

            
        else:
            each_df_1 = each_df.iloc[:1,:]
            for index,row in each_df_1.iterrows():
                if(str(row['securityRestrictions__cusip']) != 'nan' and str(row['sectorRestrictions__gicsSubIndustryCode']) != 'nan'):
                    if(str(row['taxSensitivity']) != 'nan'):
                        final_json['TaxSensitivity'] = TAX_SENSITIVITY_DICT[row['taxSensitivity'].lower()]
                    else:
                        final_json['TaxSensitivity'] = None
                    if(str(row['federalLongTermTaxRate'])!='nan'):
                        final_json['FederalLongTermTaxRate'] = float(row['federalLongTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalLongTermTaxRate'] = None
                    if(str(row['federalShortTermTaxRate'])!='nan'):
                        final_json['FederalShortTermTaxRate'] = float(row['federalShortTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalShortTermTaxRate'] = None
                    if(str(row['stateTaxRate'])!='nan'):
                        final_json['StateTaxRate'] = float(row['stateTaxRate'].split('%')[0])
                    else:
                        final_json['StateTaxRate'] = None
                    # final_json['CashRestriction'] = row['cashRestriction']
                    if(str(row['cashRestriction__cusip']) != 'nan'):
                        final_json['CashRestriction']["cusip"] = row['cashRestriction__cusip']
                        final_json['CashRestriction']["cashRestrictionAmount"] = row['cashRestriction__cashRestrictionAmount']
                    else:
                        final_json['CashRestriction'] = None
                    final_json['SecurityRestrictions'][0]['Cusip'] = str(row['securityRestrictions__cusip']).replace(' ','').split('.')[0]
                    final_json['SecurityRestrictions'][0]['Ticker'] = row['securityRestrictions__ticker']
                    final_json['SecurityRestrictions'][0]['Description'] = row['securityRestrictions__description']
                    final_json['SecurityRestrictions'][0]['SecurityRestrictionType'] = row['securityRestrictions__securityRestrictionType']
                    final_json['SectorRestrictions'][0]['GicsSubIndustryCode'] = str(int(row['sectorRestrictions__gicsSubIndustryCode']))
                    final_json['SectorRestrictions'][0]['GicsSubIndustryDescription'] = row['sectorRestrictions__gicsSubIndustryDescription']
                    if(str(row['shortTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['ShortTermRealizedGainBudgetAmount'] = row['shortTermRealizedGainBudgetAmount']
                    else:
                        final_json['ShortTermRealizedGainBudgetAmount'] = None
                    if(str(row['longTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['LongTermRealizedGainBudgetAmount'] = row['longTermRealizedGainBudgetAmount']
                    else:
                        final_json['LongTermRealizedGainBudgetAmount'] = None
                    if(str(row['yearToDateShortTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateShortTermRealizedGainLoss'] = row['yearToDateShortTermRealizedGainLoss']
                    else:
                        final_json['YearToDateShortTermRealizedGainLoss'] = None
                    if(str(row['yearToDateLongTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateLongTermRealizedGainLoss'] = row['yearToDateLongTermRealizedGainLoss']
                    else:
                        final_json['YearToDateLongTermRealizedGainLoss'] = None
                    
                elif(str(row['securityRestrictions__cusip']) != 'nan' and str(row['sectorRestrictions__gicsSubIndustryCode']) == 'nan'):
                    if(str(row['taxSensitivity']) != 'nan'):
                        final_json['TaxSensitivity'] = TAX_SENSITIVITY_DICT[row['taxSensitivity'].lower()]
                    else:
                        final_json['TaxSensitivity'] = None
                    if(str(row['federalLongTermTaxRate'])!='nan'):
                        final_json['FederalLongTermTaxRate'] = float(row['federalLongTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalLongTermTaxRate'] = None
                    if(str(row['federalShortTermTaxRate'])!='nan'):
                        final_json['FederalShortTermTaxRate'] = float(row['federalShortTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalShortTermTaxRate'] = None
                    if(str(row['stateTaxRate'])!='nan'):
                        final_json['StateTaxRate'] = float(row['stateTaxRate'].split('%')[0])
                    else:
                        final_json['StateTaxRate'] = None
                    # final_json['CashRestriction'] = row['cashRestriction']
                    if(str(row['cashRestriction__cusip']) != 'nan'):
                        final_json['CashRestriction']["cusip"] = row['cashRestriction__cusip']
                        final_json['CashRestriction']["cashRestrictionAmount"] = row['cashRestriction__cashRestrictionAmount']
                    else:
                        final_json['CashRestriction'] = None
                    final_json['SecurityRestrictions'][0]['Cusip'] = str(row['securityRestrictions__cusip']).replace(' ','').split('.')[0]
                    final_json['SecurityRestrictions'][0]['Ticker'] = row['securityRestrictions__ticker']
                    final_json['SecurityRestrictions'][0]['Description'] = row['securityRestrictions__description']
                    final_json['SecurityRestrictions'][0]['SecurityRestrictionType'] = row['securityRestrictions__securityRestrictionType']
                    final_json['SectorRestrictions'] = []
                    if(str(row['shortTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['ShortTermRealizedGainBudgetAmount'] = row['shortTermRealizedGainBudgetAmount']
                    else:
                        final_json['ShortTermRealizedGainBudgetAmount'] = None
                    if(str(row['longTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['LongTermRealizedGainBudgetAmount'] = row['longTermRealizedGainBudgetAmount']
                    else:
                        final_json['LongTermRealizedGainBudgetAmount'] = None
                    if(str(row['yearToDateShortTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateShortTermRealizedGainLoss'] = row['yearToDateShortTermRealizedGainLoss']
                    else:
                        final_json['YearToDateShortTermRealizedGainLoss'] = None
                    if(str(row['yearToDateLongTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateLongTermRealizedGainLoss'] = row['yearToDateLongTermRealizedGainLoss']
                    else:
                        final_json['YearToDateLongTermRealizedGainLoss'] = None
                
                elif(str(row['securityRestrictions__cusip']) == 'nan' and str(row['sectorRestrictions__gicsSubIndustryCode']) != 'nan'):
                    if(str(row['taxSensitivity']) != 'nan'):
                        final_json['TaxSensitivity'] = TAX_SENSITIVITY_DICT[row['taxSensitivity'].lower()]
                    else:
                        final_json['TaxSensitivity'] = None
                    if(str(row['federalLongTermTaxRate'])!='nan'):
                        final_json['FederalLongTermTaxRate'] = float(row['federalLongTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalLongTermTaxRate'] = None
                    if(str(row['federalShortTermTaxRate'])!='nan'):
                        final_json['FederalShortTermTaxRate'] = float(row['federalShortTermTaxRate'].split('%')[0])
                    else:
                        final_json['FederalShortTermTaxRate'] = None
                    if(str(row['stateTaxRate'])!='nan'):
                        final_json['StateTaxRate'] = float(row['stateTaxRate'].split('%')[0])
                    else:
                        final_json['StateTaxRate'] = None
                    # final_json['CashRestriction'] = row['cashRestriction']
                    if(str(row['cashRestriction__cusip']) != 'nan'):
                        final_json['CashRestriction']["cusip"] = row['cashRestriction__cusip']
                        final_json['CashRestriction']["cashRestrictionAmount"] = row['cashRestriction__cashRestrictionAmount']
                    else:
                        final_json['CashRestriction'] = None
                    final_json['SecurityRestrictions'] = []
                    final_json['SectorRestrictions'][0]['GicsSubIndustryCode'] = str(int(row['sectorRestrictions__gicsSubIndustryCode']))
                    final_json['SectorRestrictions'][0]['GicsSubIndustryDescription'] = row['sectorRestrictions__gicsSubIndustryDescription']
                    if(str(row['shortTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['ShortTermRealizedGainBudgetAmount'] = row['shortTermRealizedGainBudgetAmount']
                    else:
                        final_json['ShortTermRealizedGainBudgetAmount'] = None
                    if(str(row['longTermRealizedGainBudgetAmount'])!='nan'):
                        final_json['LongTermRealizedGainBudgetAmount'] = row['longTermRealizedGainBudgetAmount']
                    else:
                        final_json['LongTermRealizedGainBudgetAmount'] = None
                    if(str(row['yearToDateShortTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateShortTermRealizedGainLoss'] = row['yearToDateShortTermRealizedGainLoss']
                    else:
                        final_json['YearToDateShortTermRealizedGainLoss'] = None
                    if(str(row['yearToDateLongTermRealizedGainLoss'])!='nan'):
                        final_json['YearToDateLongTermRealizedGainLoss'] = row['yearToDateLongTermRealizedGainLoss']
                    else:
                        final_json['YearToDateLongTermRealizedGainLoss'] = None
                
            each_df_rest = each_df.iloc[1:,:]
            for index,row in each_df_rest.iterrows():
                if(str(row['securityRestrictions__cusip'])!= 'nan'):
                    security_json = {"Cusip":"","Ticker":"","Description":"","SecurityRestrictionType":""}
                    security_json["Cusip"] = str(row['securityRestrictions__cusip']).replace(' ','').split('.')[0]
                    security_json["Ticker"] = row['securityRestrictions__ticker']
                    security_json["Description"] = row['securityRestrictions__description']
                    security_json["SecurityRestrictionType"] = row['securityRestrictions__securityRestrictionType']
                    final_json['SecurityRestrictions'].append(security_json)
                if(str(row['sectorRestrictions__gicsSubIndustryCode'])!= 'nan'):
                    sector_json = {"GicsSubIndustryCode":"","GicsSubIndustryDescription":""}
                    sector_json["GicsSubIndustryCode"] = str(int(row['sectorRestrictions__gicsSubIndustryCode']))
                    sector_json["GicsSubIndustryDescription"] = row['sectorRestrictions__gicsSubIndustryDescription']
                    final_json['SectorRestrictions'].append(sector_json)
                    
            result.append(final_json)
    return result


def Create_Settings(accounts,full_list):
    invalid_accounts = []
    result = Create_Add_Settings_Api_Body(full_list=full_list)
    for i in range(len(result)):
        try:
            token = _API.Okta_Token_Call(
                        url=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'url'"],
                        username=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'username'"],
                        password=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'password'"],
                        header=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'header'"],
                        payload=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'payload'"]
                    )
            create_tms_payload = result[i]
            temp = json.dumps(create_tms_payload)
            _APIConfig.Api_variables[_Configirations.env]["'add_setting'"]["'header'"]['Authorization'] = token
            create_tms_response=_API.Post_Call(
                                    url=_APIConfig.Api_variables[_Configirations.env]["'add_setting'"]["'url'"].format('IN'+accounts[i]),
                                    payload=json.dumps(create_tms_payload),
                                    header=_APIConfig.Api_variables[_Configirations.env]["'add_setting'"]["'header'"]
                                )
            status_code = create_tms_response.status_code
            setting_id = create_tms_response.text[1:-1]
            setting_ids.append(setting_id)
            if(str(create_tms_response.status_code) == '201'):
                # db_response = pd.read_sql_query(
                #                                 sql=f"select * from [dbo].[overlay_setting_audit] where overlay_setting_id = '{setting_id}' and status = 'Proposed'",
                #                                 con=_Db.Azure_Db_connection()
                #                 )
                # deep_diff_result = DeepDiff(create_tms_payload,json.loads(db_response['data'].to_dict()[0]))
                # print(deep_diff_result)
                # if(len(deep_diff_result) != 0):
                #     invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':deep_diff_result})
                print("pass")
                    
            elif(str(create_tms_response.status_code) == '422'):
                invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':json.loads(create_tms_response.text)['errors']})
            
            elif(str(create_tms_response.status_code) == '400'):
                invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':'Bad Request Error'})
            
            else:
                invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':""})
        except Exception as e:
            print(e)
    return invalid_accounts


def Approve_Settings():
    # create_settings_invalid_accounts = Create_Settings()
    approve_settings_invalid_ids = []
    for _id in setting_ids:
        token = _API.Okta_Token_Call(
                    url=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'url'"],
                    username=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'username'"],
                    password=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'password'"],
                    header=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'header'"],
                    payload=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'payload'"]
                )
        _APIConfig.Api_variables[_Configirations.env]["'approve_setting'"]["'header'"]['Authorization'] = token
        approve_setting_response = _API.Post_Call(
            url=_APIConfig.Api_variables[_Configirations.env]["'approve_setting'"]["'url'"].format(_id),
            header=_APIConfig.Api_variables[_Configirations.env]["'approve_setting'"]["'header'"]
        )

        print(approve_setting_response.text)
        status_code = approve_setting_response.status_code
        if(str(status_code) =="200"):
            print('approved')
        if(str(status_code) =="404"):
            approve_settings_invalid_ids.append({'id':_id,'status_code':status_code,'reason':'Not Found'})
            # miss_list.append(id)
        elif(str(status_code) =="405"):
            approve_settings_invalid_ids.append({'id':_id,'status_code':status_code,'reason':'Method not allowed'})
            # miss_list.append(id)
        elif(str(status_code) !="200"):
            approve_settings_invalid_ids.append({'id':_id,'status_code':status_code,'reason':'Not known'})
            
    return approve_settings_invalid_ids


def Expire_Settings(accounts):
    expire_settings_invalid_ids = []
    for account in accounts:
        token = _API.Okta_Token_Call(
                    url=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'url'"],
                    username=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'username'"],
                    password=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'password'"],
                    header=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'header'"],
                    payload=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'payload'"]
                )
        _APIConfig.Api_variables[_Configirations.env]["'expire_setting'"]["'header'"]['Authorization'] = token
        expire_setting_response = _API.Post_Call(
            url=_APIConfig.Api_variables[_Configirations.env]["'expire_setting'"]["'url'"].format(account),
            header=_APIConfig.Api_variables[_Configirations.env]["'expire_setting'"]["'header'"]
        )
        print(expire_setting_response.text)
        status_code = expire_setting_response.status_code
        if(str(status_code) =="200"):
            print('approved')
        elif(str(status_code) =="404"):
            expire_settings_invalid_ids.append({'id':account,'status_code':status_code,'reason':'Not Found'})
            # miss_list.append(id)
        elif(str(status_code) =="405"):
            expire_settings_invalid_ids.append({'id':account,'status_code':status_code,'reason':'Method not allowed'})
            # miss_list.append(id)
        elif(str(status_code) !="200"):
            expire_settings_invalid_ids.append({'id':account,'status_code':status_code,'reason':'Not known'})

    return expire_settings_invalid_ids

