import pandas as pd
import json
import requests as req
from deepdiff import DeepDiff
import pyodbc

from ConfigScripts import _APIConfig
from Framework.Utils import _API
from Framework.Utils import _Db
from ConfigScripts import _Configirations




def Create_Holdings_Body(full_list):
    result = []
    for each_tuple in full_list:
        each_df = each_tuple[1]
        each_body = []
        for index,row in each_df.iterrows():
            final_json = {
            "SecurityIdentifier": "",
            "Quantity": "",
            "CostBasis": "",
            "PurchaseDate": "",
            "term":"",
            "CurrentMarketValue":"" ,
            "ProxySecurityIdentifier": "",
            "isCash":"",
            "other":{}
            }
            
            final_json["SecurityIdentifier"] = str(row['securityIdentifier']).replace(" ","")
            final_json["Quantity"] = row['quantity']
            final_json['CostBasis'] = row['costBasis']
            if(str(row['purchaseDate'])) == "NaT":
                del final_json['PurchaseDate']
            else:
                final_json['PurchaseDate'] = str(row['purchaseDate']).split(' ')[0]+'T00:00:00'
            if(str(row['term'])) == "nan":
                del final_json['term']
            else:
                final_json['term'] = str(row['term'])
            final_json['CurrentMarketValue'] = row['currentMarketValue']
            final_json['ProxySecurityIdentifier'] = str(row['proxySecurityIdentifier']).replace(" ","")
            if(str(row['isCash'])!='nan'):
                final_json["isCash"] = row['isCash']
            else:
                del final_json["isCash"]
            temp = str(row["other"])
            t2 = '{'+str(row["other"])+'}'
            if(str(row["other"])!='nan'):
                final_json['other'] = json.loads('{'+str(row["other"])+'}')

            
            each_body.append(final_json)
        
        result.append(each_body)
    return result


def Create_Holdings(accounts,full_list):
    invalid_accounts = []
    result = Create_Holdings_Body(full_list=full_list)
    for i in range(len(result)):
        token = _API.Okta_Token_Call(
                url=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'url'"],
                username=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'username'"],
                password=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'password'"],
                header=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'header'"],
                payload=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'payload'"]
            )
        add_holdings_payload = result[i]

        _APIConfig.Api_variables[_Configirations.env]["'add_holding'"]["'header'"]['Authorization'] = token
        add_holding_response=_API.Post_Call(
                                url=_APIConfig.Api_variables[_Configirations.env]["'add_holding'"]["'url'"].format('TE'+accounts[i]),
                                payload=json.dumps(add_holdings_payload),
                                header=_APIConfig.Api_variables[_Configirations.env]["'add_holding'"]["'header'"]
                            )
        status_code = add_holding_response.status_code
        if(str(add_holding_response.status_code) == '201'):
            # db_response = pd.read_sql_query(f"SELECT * FROM [dbo].[external_holding_audit] where [account_id] = '{'DEMO'+accounts[i]}' and audit_time_end IS NULL",con=_Db.Azure_Db_connection())
            
            # deep_diff_result = DeepDiff(add_holdings_payload,json.loads(db_response['data'].to_dict()[0]))
            # print(deep_diff_result)
            # if(len(deep_diff_result) != 0):
            #     invalid_accounts.append({'account':accounts[i],'payload':result[i],'reason':deep_diff_result})
            print('pass')
                
        elif(str(add_holding_response.status_code) == '422'):
            invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':json.loads(add_holding_response.text)['errors']})

        elif(str(add_holding_response.status_code) == '400'):
            invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':'Bad Request Error'})
        
        elif(str(add_holding_response.status_code) == '500'):
            invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':'Internal Server Error'})
        
        else:
            invalid_accounts.append({'account':accounts[i],'status_code':status_code,'payload':result[i],'reason':""})
    
    return invalid_accounts