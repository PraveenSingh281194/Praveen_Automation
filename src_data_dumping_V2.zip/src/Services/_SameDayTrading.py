import pandas as pd
import json
import requests as req
from deepdiff import DeepDiff
import pyodbc
import os
from datetime import datetime

from ConfigScripts import _APIConfig
from Framework.Utils import _API
from Framework.Utils import _Db
from ConfigScripts import _Configirations
from Framework.Utils._PublishFile import Publish_File


def Same_Day_Trading(df:pd.DataFrame):   
    status_report=[]
    invalid_accounts=[]
    payloads=[]

    status_report_path= os.path.join(os.getcwd(),"src","OutputArtifacts","SDT",f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}")
    os.makedirs(status_report_path,exist_ok=True)

    status_report_artifact_json_file=os.path.join(status_report_path,"status_report.json")
    invalid_accounts_artifact_json_file= os.path.join(status_report_path,"invalid_accounts.json")
    payloads_artifacts_json_file= os.path.join(status_report_path,"payloads.json")

    status_report_artifact_csv_file=os.path.join(status_report_path,"status_report.csv")
    invalid_accounts_artifact_csv_file= os.path.join(status_report_path,"invalid_accounts.csv")
    payloads_artifacts_csv_file= os.path.join(status_report_path,"payloads.csv")

    for index,row in df.iterrows():
        same_day_trading_payload_structure={"accountId":"",
                                            "amount":"",
                                            "cashIdentifier":""}
        
        same_day_trading_payload_structure['accountId']= str(row['accountId'])
        same_day_trading_payload_structure['amount']= float(row['amount'])
        same_day_trading_payload_structure['cashIdentifier']= str(row['cashIdentifier'])
        
        ## hit the API
        token = _API.Okta_Token_Call(
                url=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'url'"],
                username=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'username'"],
                password=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'password'"],
                header=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'header'"],
                payload=_APIConfig.Api_variables[_Configirations.env]["'okta_token'"]["'payload'"]
            )


        _APIConfig.Api_variables[_Configirations.env]["'same_day_trading'"]["'header'"]['Authorization'] = token
        same_day_trading_response=_API.Post_Call(
                                url=_APIConfig.Api_variables[_Configirations.env]["'same_day_trading'"]["'url'"],
                                payload=json.dumps(same_day_trading_payload_structure),
                                header=_APIConfig.Api_variables[_Configirations.env]["'same_day_trading'"]["'header'"]
                            )

        status_code = same_day_trading_response.status_code
        time_elapsed= same_day_trading_response.elapsed.total_seconds()
        payloads.append(same_day_trading_payload_structure)

        if(str(same_day_trading_response.status_code) == '201'):
            print('pass')
            status_report.append({
                "accountId":same_day_trading_payload_structure['accountId'],
                "amount":same_day_trading_payload_structure['amount'],
                "cashIdentifier":same_day_trading_payload_structure['cashIdentifier'],
                "status code":status_code,
                "GUID":same_day_trading_response.text[1:-1],
                "Time Elapsed":time_elapsed,
                "Reason":"Success"
            })            
        elif(str(same_day_trading_response.status_code) == '422'):
            invalid_accounts.append({
                'account':"",
                'status_code':status_code
                ,'payload':same_day_trading_payload_structure,
                'reason':json.loads(same_day_trading_response.text)['errors']
            })
            
            status_report.append({
                "accountId":same_day_trading_payload_structure['accountId'],
                "amount":same_day_trading_payload_structure['amount'],
                "cashIdentifier":same_day_trading_payload_structure['cashIdentifier'],
                "status code":status_code,
                "GUID":same_day_trading_response.text[1:-1],
                "Time Elapsed":time_elapsed,
                "Reason":"Success"
            })
        elif(str(same_day_trading_response.status_code) == '400'):
            invalid_accounts.append({
                'account':"",
                'status_code':status_code,
                'payload':same_day_trading_payload_structure,
                'reason':'Bad Request Error'
            })
            status_report.append({
                "accountId":same_day_trading_payload_structure['accountId'],
                "amount":same_day_trading_payload_structure['amount'],
                "cashIdentifier":same_day_trading_payload_structure['cashIdentifier'],
                "status code":status_code,
                "GUID":"will not be generated",
                "Time Elapsed":time_elapsed,
                "Reason":"To be decided for 400"
            })
        elif(str(same_day_trading_response.status_code) == '500'):
            invalid_accounts.append({
                'account':"",
                'status_code':status_code,
                'payload':same_day_trading_payload_structure,
                'reason':'Internal Server Error'
            })
            status_report.append({
                "accountId":same_day_trading_payload_structure['accountId'],
                "amount":same_day_trading_payload_structure['amount'],
                "cashIdentifier":same_day_trading_payload_structure['cashIdentifier'],
                "status code":status_code,
                "GUID":"will not be generated",
                "Time Elapsed":time_elapsed,
                "Reason":"To be decided for 500"
            })
        else:
            invalid_accounts.append({
                'account':"",
                'status_code':status_code,
                'payload':same_day_trading_payload_structure,
                'reason':""
            })
            status_report.append({
                "accountId":same_day_trading_payload_structure['accountId'],
                "amount":same_day_trading_payload_structure['amount'],
                "cashIdentifier":same_day_trading_payload_structure['cashIdentifier'],
                "status code":status_code,
                "GUID":"will not be generated",
                "Time Elapsed":time_elapsed,
                "Reason":"To be decided for in general"
            })

    publish_file=  Publish_File()
    publish_file.Publish_Json_File(content = invalid_accounts,filename=invalid_accounts_artifact_json_file)
    publish_file.Publish_Json_File(content = status_report,filename=status_report_artifact_json_file)    
    publish_file.Publish_Json_File(content = payloads,filename=payloads_artifacts_json_file)    

    invalid_accounts_df = pd.DataFrame(invalid_accounts)
    status_report_df = pd.DataFrame(status_report)
    payloads_df = pd.DataFrame(payloads)

    invalid_accounts_df.to_csv(invalid_accounts_artifact_csv_file)
    status_report_df.to_csv(status_report_artifact_csv_file)
    payloads_df.to_csv(payloads_artifacts_csv_file)
