import json,os

cur_path = os.path.dirname(__file__)
file_path = "src\Config\_DbConfig.json"

with open(file_path, 'r' ) as f:
    data = f.read()
    properties = json.loads(data)
    db_variables = {
        "Test10":{
           "server":properties['Test10']['SERVER'],
           "database":properties['Test10']['DATABASE'],
           "port":properties['Test10']['PORT'],
           "username":properties['Test10']['USERNAME'],
           "password":properties['Test10']['PASSWORD']
        },

        "Test11":{
           "server":properties['Test11']['SERVER'],
           "database":properties['Test11']['DATABASE'],
           "port":properties['Test11']['PORT'],
           "username":properties['Test11']['USERNAME'],
           "password":properties['Test11']['PASSWORD']
        },

        "Test12":{
           "server":properties['Test12']['SERVER'],
           "database":properties['Test12']['DATABASE'],
           "port":properties['Test12']['PORT'],
           "username":properties['Test12']['USERNAME'],
           "password":properties['Test12']['PASSWORD']
        },

        "Dev11":{
           "server":properties['Dev11']['SERVER'],
           "database":properties['Dev11']['DATABASE'],
           "port":properties['Dev11']['PORT'],
           "username":properties['Dev11']['USERNAME'],
           "password":properties['Dev11']['PASSWORD']
        },
        
        "Dev12":{
           "server":properties['Dev12']['SERVER'],
           "database":properties['Dev12']['DATABASE'],
           "port":properties['Dev12']['PORT'],
           "username":properties['Dev12']['USERNAME'],
           "password":properties['Dev12']['PASSWORD']
        },
        
        "Dev13":{
           "server":properties['Dev13']['SERVER'],
           "database":properties['Dev13']['DATABASE'],
           "port":properties['Dev13']['PORT'],
           "username":properties['Dev13']['USERNAME'],
           "password":properties['Dev13']['PASSWORD']
        }
    }