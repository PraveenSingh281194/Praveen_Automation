import requests as req
import json

# class Api():


def Okta_Token_Call(url:str,username:str,password:str,payload:dict,header:dict)->str:
    """
    post_api_url : the post api url to make a hit
    api_username : api usename for the verified user
    api_password : api_paswword for that particular username
    payload : api body
    header : head parameters
    
    return : returns the okta token
    """
    response = req.post(str(url),data=payload,auth=(str(username),str(password)),headers=header,verify = False)
    token = "Bearer " + json.loads(response.text)['access_token']
    return token
    

def Post_Call(url:str,payload:dict=None,header:dict=None)->req.models.Response:
    """
    post_api_url : the post api url to make a hit
    api_username : api usename for the verified user
    api_password : api_paswword for that particular username
    payload : api body
    header : head parameters
    
    return : returns the api response object
    """
    response = req.post(url,data=payload,headers=header,verify=False)
    return response


def Status_Verify(response:req.models.Response, status_code)->str:
    """
    will verify the status_code of the response with the required one

    parameters:
        response : response of the api
        status : the required status code to be compared

    return:
        will return Pass(string) if the status code matches else return Fail(string)
    """
    if(int(response.status_code) == int(status_code)):
        return 'Pass'
    else:
        return 'Fail'


def Get_Status(response:req.models.Response)->int:
    """
    given a response object will return the status code of the response

    parameters:
        response : response object of the api

    return:
        will return the status_code(int) of the response 
    """
    return response.status_code


def Get_Call(get_api_url,header:dict)->req.models.Response:
    """
    will hit the get api url given header parameters of the API
    
    parameters:
        get_api_url : the get api url to make a hit
        header : head parameters of the API
    
    return:
        will return the response of the API
    """
    response = req.get(str(get_api_url),headers=header,verify=False)
    return response


def Flush_Token():
    print()