# from Utils._Logs import testLog
import time,pyodbc,sqlalchemy,pandas as pd


# def SQL_Create_Engine(server,db,username:str=None,password:str=None):
#     """
#     Engine to be created for bulk insertion into database 
#     """
#     # testLog("Database Engine Initiated")
#     if(username !=None and password !=None):
#         print()
#     else:
#         con_string = 'mssql+pyodbc://@' + server + '/'+ db + '?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'
#     # try:
#     engine = sqlalchemy.create_engine(con_string,pool_pre_ping=True)
#         # testLog("Database Engine Created")
#     # except Exception as e:
#         # testLog(str(e))
#     return engine

# def SQL_Create_Connection():                        
#     """
#     For establishing connection to database
#     """
#     # server_name = config.server_name
#     # db_name = config.db_name
#     # db_conn = pyodbc.connect('Driver={SQL Server};'
#     # 'Server={};'
#     # 'Database={};'
#     # 'Trusted_Connection=yes;').format(str(server_name),str(db_name))
#     testLog("Database Connection  Intiated")
#     start_time = time.time()
#     try:
#         # server = '10.23.212.77,1433'
#         self.server = Config.json_variables['db_params']['server_name']
#         self.database = Config.json_variables['db_params']['database_name']
#         # username = 'DevUser'
#         # password = '9SfzgS7Q4k'
#         # # fpkt12amdb1
#         db_conn = pyodbc.connect('Driver={SQL Server};'
#         'Server=%s;'
#         'Database=%s;'
#         'Trusted_Connection=yes;'% (self.server,self.database))

#         # db_conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
#         # db_conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};''Server=t12ewmdba;''Database=TaxHarvest;''UID=DevUser';'PWD= 9SfzgS7Q4k')
#         connection_duration = start_time - time.time()
#         testLog("Database Connection established in {} seconds".format(connection_duration))
#     except Exception as e:
#         testLog("Error in Database Connection : {}".format(e))
#     return db_conn

def Azure_Db_connection():
    conn = pyodbc.connect(Driver='{ODBC Driver 17 for SQL Server}',
                Server='sqlinvestmentsdev.database.windows.net',
                Port='1433',
                Database='TaxManagement',
                AUTHENTICATION='ActiveDirectoryPassword',
                User ='Paritosh.Sharma@assetmark.com',
                Password='Welcome208319!',
                MARS_Connection='Yes' 
                )
    return conn
    


# def Compare_Db(self,ideal_db:pd.DataFrame, input_db:pd.DataFrame,extent):
#     print()

