import pandas as pd
from Services import _CreateSetting,_AddHolding, _SameDayTrading
from Framework.Utils._PublishFile import Publish_File

accounts = []
# result = []
# invalid_accounts = []
# tax_sensitivity_dict = {'veryhigh':'VeryHigh','medium':'Medium','high':'High','low':'Low'}


def Create_Setting():
    
    df = pd.read_csv(r'C:\Users\Paritosh.Sharma\Downloads\TMS Settings_2k_Failed Account.csv')
    full_list = list(df[:20].groupby('accountId'))
    for account in full_list:
        accounts.append(account[0])

    # _CreateSetting.Create_Add_Settings_Api_Body(full_list)

    invalid_accounts = _CreateSetting.Create_Settings(accounts = accounts,full_list=full_list)
    publish_file=  Publish_File()
    publish_file.Publish_Json_File(content = invalid_accounts,filename='Output_after.json')

    invalid_accounts_df = pd.DataFrame(columns = ['account','status code','reason'])
    for invalid_entry in invalid_accounts:
        invalid_accounts_df = invalid_accounts_df.append({'account':invalid_entry['account'],'status code':invalid_entry['status_code'],'reason':str(invalid_entry['reason'])},ignore_index=True)
    invalid_accounts_df.to_csv('Output_after.csv')

def Approve_Settings():
    Create_Setting()
    approve_response = _CreateSetting.Approve_Settings()
    publish_file=  Publish_File()
    # publish_file.Publish_Json_File(content = approve_response[1],filename='create_settings_invalid_accounts.json')
    publish_file.Publish_Json_File(content = approve_response,filename='approve_settings_invalid_ids.json')

def Expire_Settings():
    # Approve_Settings()
    # df = pd.read_csv(r'C:\Users\Paritosh.Sharma\Downloads\TMS Settings_2k_Failed Account.csv')
    # full_list = list(df[:20].groupby('accountId'))
    # for account in full_list:
    #     accounts.append(account[0])
    df = pd.read_csv(r'C:\Users\Paritosh.Sharma\Downloads\expire_dry_run.csv')
    accounts = list(df['accounts'])
    expire_setting_invalid_accounts = _CreateSetting.Expire_Settings(accounts)
    publish_file=  Publish_File()
    publish_file.Publish_Json_File(content = expire_setting_invalid_accounts,filename='expire_setting_invalid_accounts.json')


def Add_Holding():
    accounts = []
    df = pd.read_excel(r'C:\Users\Paritosh.Sharma\OneDrive - AssetMark, Inc\Documents\TMSExtHoldings_v2enhancement_UAT_CR_20230505 (with isCash).xlsx',sheet_name = 'Sheet1')
    df['purchaseDate'] = pd.to_datetime(df['purchaseDate'], unit='s')

    full_list = list(df.groupby('accountId'))
    for account in full_list:
        accounts.append(account[0])
    add_holding_response =_AddHolding.Create_Holdings(accounts=accounts,full_list=full_list)
    publish_file=  Publish_File()
    publish_file.Publish_Json_File(content = add_holding_response,filename='add_holdings_invalid_accounts.json')


def Same_Day_Trading():
    df = pd.read_csv(r"C:\Users\Paritosh.Sharma\Downloads\SDT Sample Test Data Template_06122023.csv")
    _SameDayTrading.Same_Day_Trading(df)




if __name__=="__main__":
    # Create_Setting()       #if only creating
    # Approve_Settings()            # if both creating and then approving
    # Add_Holding()           # if add holding
    # Expire_Settings()
    Same_Day_Trading()