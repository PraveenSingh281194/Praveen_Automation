import requests,json
import configpy as configfile
session=requests.session()
cookies_jar={}

#change below 3 attributes as per execution requirement
env='test12'
standard_model_name='B'
type='standard_model'

#sorting and extraction columns
cols_list=['SleeveAPLID','xrefCusip','SleeveWeights']
sort_cols=['sleeve','cusip','weight']
modelversionid=configfile.modelversionid
asofdate=configfile.asofdate

def df_extract_cols(df):
    df=df[cols_list]
    df=df.rename(columns={cols_list[0]:sort_cols[0],cols_list[1]: sort_cols[1],cols_list[2]:sort_cols[2]})
    df=df.sort_values(by=sort_cols)
    return df


def compare(swagger_df,db_df):
    cusip_list,weight_list,sleeve_list=([] for i in range(3))

    # result list values append based on scenarios
    expected_sleeve=db_df['sleeve'].values.tolist()
    actual_sleeve=swagger_df['sleeve'].values.tolist()

    expected_cusip=db_df['cusip'].values.tolist()
    actual_cusip=swagger_df['cusip'].values.tolist()

    expected_weight=db_df['weight'].values.tolist()
    actual_weight=swagger_df['weight'].values.tolist()

    cusip_list=zip_func(expected_cusip,actual_cusip,cusip_list)
    sleeve_list=zip_func(expected_sleeve,actual_sleeve,sleeve_list)
    weight_list=zip_func(expected_weight,actual_weight,weight_list)

    return cusip_list,weight_list,sleeve_list

def zip_func(list1,list2,result_list):
    try:
        for a,b in zip(list1,list2):
            result_list.append('Pass') if a==b else result_list.append('Fail')
    except Exception as e:
        print(f'error occured is {e}')
        raise e
    return result_list
    
if type=='standard_model':
    if standard_model_name=='B':

        sql_query_b= f"""set nocount on
                    select
            Max(SMH.Weight) as ModelWeight,
            M2.APLID as SleeveAPLID,
            
            max(x2.modelversionid) as SleeveModelVersionId
            into #test
        FROM [SMI].[dbo].[Model] m
                JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
                JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
                JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
                JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
                JOIN SMI..model m2 on SMH.XRefID = m2.ModelId

            JOIN SMI..ModelVersion v2 on m2.modelid = v2.modelID
            JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x2 on v2.ModelVersionID = x2.ModelVersionID
            JOIN [SMI].[dbo].[APB] a2 on x2.APBID = a2.APBID
            JOIN SMI..SMI_Holding SMH2 on x2.modelversionid = SMH2.modelVersionID

            WHERE m.APLID = '{modelversionid}' 
            and a.effdt <= '{asofdate}'
            and a2.EffDT <= '{asofdate}'
                AND a.StatusCD = 65004 -- approved apb
                And x.ModelVersionID in (select max(x.ModelVersionID) from [SMI].[dbo].[Model] m
                JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
                JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
                JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
                JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
                JOIN SMI..model m2 on SMH.XRefID = m2.ModelId
            WHERE m.APLID = '{modelversionid}' 
            and a.effdt <= '{asofdate}'
                AND a.StatusCD = 65004)
                group by M2.APLID
        -- order by a.apbid desc, a.effdt desc, x.modelversionid desc, a2.apbid desc, a2.EffDT desc, x2.ModelVersionID desc, M2.APLID asc--, SleeveWeights


    --3. Final query for standard model B to find the holdings for sleeve models
        select 
            ModelWeight,
            SMH.Weight,
            SleeveAPLID,
            SMH.xrefCusip,
            Convert(decimal(12,8),(Convert(decimal(7,3), SMH.Weight) * Convert(decimal(7,3), ModelWeight))/100) as SleeveWeights
            --cast((SMH.Weight * ModelWeight) as decimal(8,4))/100 as SleeveWeights
        from #test as t
        JOIN SMI..SMI_Holding SMH on t.SleeveModelVersionId = SMH.modelVersionID
        order by SleeveAPLID asc, SleeveWeights asc, SMH.xrefCusip asc
                """
        

    elif standard_model_name=='A':
        sql_query_a=f'''select m.APLID,a.effdt,x.modelversionid,XRefID,SMH.XrefCusip as xrefCusip,SMH.Weight as SleeveWeights  FROM [SMI].[dbo].[Model] m JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID WHERE m.APLID = '{modelversionid}' and a.effDt <= '{asofdate}' AND a.StatusCD = 65004  and x.ModelVersionID in (select max(x.modelversionid) FROM [SMI].[dbo].[Model] m JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID WHERE m.APLID = '{modelversionid}' and a.effDt <= '{asofdate}' AND a.StatusCD = 65004) order by a.apbid desc, a.effdt desc, x.modelversionid desc, Weight asc'''

    else:
        sql_query1= f"""set nocount on
               select 
		m.APLID, 
		a.effdt, 
		x.modelversionid, 
		SMH.HoldingID, 
		SMH.Weight as SleeveWeights, 
		SMH.XRefTypeCD, 
		SMH.XRefID, 
		SMH.XrefCusip as xrefCusip
    FROM [SMI].[dbo].[Model] m
		JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
        JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
        JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
		JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
    WHERE m.APLID = '{modelversionid}' 
		and a.effdt <= '{asofdate}'
        AND a.StatusCD = 65004 -- approved apb
		And SMH.XRefID = '-1'
		and x.ModelVersionID in (select max(x.ModelVersionID) from [SMI].[dbo].[Model] m
            JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
            JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
            JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
			JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
			WHERE m.APLID = '{modelversionid}' 
			and a.effdt <= '{asofdate}'
            AND a.StatusCD = 65004) -- approved apb
	order by a.apbid desc, a.effdt desc, x.modelversionid desc, SMH.XRefID, SMH.Weight

            """
        
        sql_query2=f"""
        set nocount on
        select
		Max(SMH.Weight) as ModelWeight,
		M2.APLID as SleeveAPLID,
		max(x2.modelversionid) as SleeveModelVersionId
	    into #StandardModelC_SleeveHoldings
        FROM [SMI].[dbo].[Model] m
        JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
        JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
        JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
		JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
		JOIN SMI..model m2 on SMH.XRefID = m2.ModelId
		JOIN SMI..ModelVersion v2 on m2.modelid = v2.modelID
		JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x2 on v2.ModelVersionID = x2.ModelVersionID
        JOIN [SMI].[dbo].[APB] a2 on x2.APBID = a2.APBID
		JOIN SMI..SMI_Holding SMH2 on x2.modelversionid = SMH2.modelVersionID
        WHERE m.APLID = '{modelversionid}' 
		and a.effdt <= '{asofdate}'
		and a2.EffDT <= '{asofdate}'
        AND a.StatusCD = 65004 -- approved apb
		And x.ModelVersionID in (select max(x.ModelVersionID) from [SMI].[dbo].[Model] m
		JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
		JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
		JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
		JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
		JOIN SMI..model m2 on SMH.XRefID = m2.ModelId
		WHERE m.APLID = '{modelversionid}' 
		and a.effdt <= '{asofdate}'
		AND a.StatusCD = 65004)
		group by M2.APLID
       -- order by a.apbid desc, a.effdt desc, x.modelversionid desc, a2.apbid desc, a2.EffDT desc, x2.ModelVersionID desc, M2.APLID asc--, SleeveWeights


    --3. Final query for standard model C to find the holdings
	    select 
		ModelWeight,
		SMH.Weight,
		SleeveAPLID,
		SMH.XrefCusip as xrefCusip,
		Convert(decimal(12,8),(Convert(decimal(7,3), SMH.Weight) * Convert(decimal(7,3), ModelWeight))/100) as SleeveWeights
	    from #StandardModelC_SleeveHoldings as sleeve
		JOIN SMI..SMI_Holding SMH on sleeve.SleeveModelVersionId = SMH.modelVersionID
	    order by SleeveAPLID asc, SleeveWeights asc, SMH.xrefCusip asc
        """