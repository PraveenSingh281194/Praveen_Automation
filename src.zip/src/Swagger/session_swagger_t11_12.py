import requests
import json

session=requests.session()
cookies_jar={}
env='test10'

def session_get(url,header=None,payload=None):
    session.get(url=url,verify=False)
    response=requests.get(url=url,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

def session_post(url,header,payload):
    session.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    response=requests.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

url1=f"https://{env}.ewealthmanager.com/eWMLogin/account/login/"
response1,cookies_jar=session_get(url1)
print('url1')
print(response1)
print(cookies_jar)

url2=f"https://{env}.ewealthmanager.com/authorization/callback"
response2,cookies_jar =session_get(url2)
url=str(response2.url)
state=url.split('=')[-1]
print('url2')
print(cookies_jar)
print(response2)

url3="https://test-login.ewealthmanager.com/login/signout"
response3,cookies_jar=session_get(url3)
print('url3')
print(response3)
print(cookies_jar)

payload={
  "password": "Test1234t",
  "username": "SampleAgent2",
  "options": {
    "warnBeforePasswordExpired": True,
    "multiOptionalFactorEnroll": True
  }
}
header={'Accept': 'application/json','Content-Type': 'application/json'}

url4="https://test-login.ewealthmanager.com/api/v1/authn"
response4,cookies_jar=session_post(url4,header,payload)
session_token=json.loads(response4.text)['sessionToken']
print('url4')
print(response4)
print(cookies_jar)

#url5 = f"https://test-login.ewealthmanager.com/oauth2/aus14jen3mw5T6Wls0h8/v1/authorize?client_id=0oa154fp86m2Ji1jh0h8&nonce=5_rOxSSeFxAgd5o5Uiuy-RQ&redirect_uri=https://test11.ewealthmanager.com/oauth/client/redirect&response_type=code&sessionToken=20111ENtg9r4HngJr994A3OZCn9nHFOGDHf9WnUIyk-pTvPenfh7GyH&state=5qtteIpeb0JPH1IgA6TRw9g&scope=openid"

url5 = f"https://test-login.ewealthmanager.com/oauth2/aus14jen3mw5T6Wls0h8/v1/authorize?client_id=0oa154fiuvyMrn3Ij0h8&nonce=DNaxXGBkgxr5NbgokIKWCRQh2JMjRbM4yoP9Afh41FQHYVQWkcpvFdQa3OhdiDBp&redirect_uri=https://test10.ewealthmanager.com/authorization/callback&response_type=code&sessionToken={session_token}&state={state}&scope=openid"
response5,cookies_jar=session_get(url5)
print('url5')
print(response5)
print(cookies_jar)
print(response5.url)


#model api hit

# header={'Cookie':'FSSESSION='+cookies_jar['FSSESSION']+'; TargetURL=' + cookies_jar['TargetURL'] +'; ASP.NET_SessionId=' + cookies_jar['ASP.NET_SessionId']+'; GFWMSessionId=' + cookies_jar['GFWMSessionId'] +'; ewm_ns='+ cookies_jar['ewm_ns'] + '; website#lang=' + cookies_jar['website#lang'] +'; DT=' + cookies_jar['DT'] +'; t='+ cookies_jar['t'] + '; JSESSIONID=' + cookies_jar['JSESSIONID']}

# url6=f"https://{env}.ewealthmanager.com/api/strategies/v2/models/AWMCT2/asofdate/2023-02-02/holdings"
# response6 = requests.request("GET", url6,headers=header,verify=False)
# print('url6')
# print(response6.text)
# print(response6.status_code)
# print(response6.url)
#print(response.cookies)