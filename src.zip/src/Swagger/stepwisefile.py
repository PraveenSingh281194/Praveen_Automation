import requests
import json

url1="https://test12.ewealthmanager.com/eWMLogin/account/login/"

response = requests.request("GET", url1,verify=False)
print('url1')
print(response.cookies)


url2="https://test12.ewealthmanager.com/authorization/callback"
response = requests.request("GET", url2,verify=False)
print('url2')
url=str(response.url)
state=url.split('=')[-1]
print(state)
print(response.url)

url3="https://test-login.ewealthmanager.com/login/signout"
response = requests.request("GET", url3,verify=False)
#step3_ewm=response.cookies['ewm_ns']
#print(step3_ewm)
print('url3')
print(response.cookies)
#print(response.text)
payload={
  "password": "Test1234t",
  "username": "SampleAgent2",
  "options": {
    "warnBeforePasswordExpired": True,
    "multiOptionalFactorEnroll": True
  }
}
header={'Accept': 'application/json',

'Content-Type': 'application/json'}
url4="https://test-login.ewealthmanager.com/api/v1/authn"
response = requests.request("POST", url4, data=json.dumps(payload),headers=header,verify=False)
print('url4')
print(response.url)
session_token=json.loads(response.text)['sessionToken']
print(response.cookies)


url5 = f"https://test-login.ewealthmanager.com/oauth2/aus14jen3mw5T6Wls0h8/v1/authorize?client_id=0oa154h4vxthGbCau0h8&nonce=kdlNKI3sM9FWwhdPq16xF5UTdA6XuropPs3Tf2sdW1NvwjCGfb7OUqLZRUQkDNKr&redirect_uri=https://test12.ewealthmanager.com/authorization/callback&response_type=code&sessionToken={session_token}&state={state}&scope=openid"

response1 = requests.request("GET", url5,verify=False)
print('url5')
#print(response1.text)
print(response1.status_code)
print(response1.url)
print(response1.cookies)

