import requests,pandas as pd
import json,pyodbc

s=requests.session()
#extracting session_token
url = "https://test-login.ewealthmanager.com/api/v1/authn"

payload = json.dumps({"password": "Test1234t","username": "SampleAgent2","options": {"warnBeforePasswordExpired": True,"multiOptionalFactorEnroll": True}})
headers = {'Accept': 'application/json','Content-Type': 'application/json'}
response = requests.request("POST", url, headers=headers, data=payload)
response_dict = json.loads(response.text)

sessionToken=response_dict['sessionToken']

#ewmlogin
url = f"https://test-login.ewealthmanager.com/oauth2/aus14jen3mw5T6Wls0h8/v1/authorize?client_id=0oa154h4vxthGbCau0h8&nonce=kdlNKI3sM9FWwhdPq16xF5UTdA6XuropPs3Tf2sdW1NvwjCGfb7OUqLZRUQkDNKr&redirect_uri=https://test12.ewealthmanager.com/authorization/callback&response_type=code&sessionToken={sessionToken}&state=z7KRMLp0X3f5kbsBwh38FA&scope=openid "

payload={}
headers = {
  'Accept': 'application/json'}
  
response = requests.request("GET", url, headers=headers, data=payload,verify=False)
res=s.get(url=url)
print(res.cookies)
c=response.cookies.list_domains()
a=response.cookies #.get_dict('test12.ewealthmanager.com')

print(response.status_code)
print(response.cookies)
ewm_ns=response.cookies['ewm_ns']
lang=response.cookies['website#lang']
#d=response.cookies['FSSESSION']
for cookie in response.cookies:
  print('cookie domain = ' + cookie.domain)
  print('cookie name = ' + cookie.name)
  print('cookie value = ' + cookie.value)
  print('*************************************')

#smi_model
#<RequestsCookieJar[Cookie(version=0, name='ewm_ns', value='!Jv6bDesMfgKmxuOuuTaypbaBGMa9zhvnAI6Uu5FKaHDidG9lE86zwORqTabAX8rRDTfu6C36CyHT6g==', port=None, port_specified=False, domain='test12.ewealthmanager.com', domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=True, expires=None, discard=True, comment=None, comment_url=None, rest={'Httponly': None}, rfc2109=False), Cookie(version=0, name='website#lang', value='en', port=None, port_specified=False, domain='test12.ewealthmanager.com', domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={}, rfc2109=False)]>

#'Cookie': 'FSSESSION=bbae73fc5bc6b43f6c30df0293f4f1a65ed5422933ad5b0864614196243fe39c3f8c7481175be898; TargetURL=; ASP.NET_SessionId=e1a4y5mepsrkacyi1pzlriiz; GFWMSessionId=5ca22f1b-1b94-480c-a1f9-17ca60ada6d0; UserId=; ewm_ns=!4MtF4+DgCampJKCuuTaypbaBGMa9zs6U95MMgzr4/4OkFgOyBJH1Odt6g+dl86d9roxIJr54T/Tlbg==; website#lang=en'

sql_query="""
select 
              m.APLID, 
              a.effdt, 
              x.modelversionid,
              XRefID,
              SMH.XrefCusip, 
              SMH.Weight
    FROM [SMI].[dbo].[Model] m
        JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
        JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
        JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
              JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
    WHERE m.APLID = 'AWMCT2' 
       and a.effDt <= '2017-02-02'
        AND a.StatusCD = 65004 -- approved apb and 
        and x.ModelVersionID in (select max(x.modelversionid) FROM [SMI].[dbo].[Model] m
        JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
        JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
        JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
              JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
    WHERE m.APLID = 'AWMCT2' 
       and a.effDt <= '2017-02-02'
        AND a.StatusCD = 65004)
    order by a.apbid desc, a.effdt desc, x.modelversionid desc, Weight asc
"""

def t12ewmbda_conn():
    server_name='t12ewmdba'
    database_name='SMI'
    conn=pyodbc.connect('Driver={SQL Server};'
                        f'Server={server_name};'
                        f'Database={database_name};'
                        'Trusted_Connection=yes;')
    query =sql_query
    df=pd.read_sql_query(query,con=conn)
    # print(len(df))
    # print(df)

t12ewmbda_conn()

#swaggerAPIhit
modelversionid='AWMCT2'
asofdate='2017-02-02'

url = f"https://test12.ewealthmanager.com/api/strategies/v2/models/{modelversionid}/asofdate/{asofdate}/holdings"

#payload={}
# headers = {'Cookie': 'FSSESSION=c3a8949a36e89029748208a2ecd7c48b9ba02531c8292dd6ff9c9588a2b55427c6a36996662008f3; TargetURL=; ASP.NET_SessionId=xjvddf3tj0q52ud1f5s0aqhp; GFWMSessionId=da1b3d5c-ff62-4bee-a862-0cdd1c4a520c; UserId=; ewm_ns=!+SM+BhLBRIYYxA2uuTaypbaBGMa9zgyK7piz2ibbwvv3LfHjS03WSbIPbOoyc3fTBN4efeHiyfqPAQ==; website#lang=en'}
headers={'Cookie': f'ewm_ns={ewm_ns}; website#lang={lang}'}
#headers={}
response = requests.request("GET", url, headers=headers,verify=False)
s.get(url=url)
print(response.text)
print(s.cookies)





