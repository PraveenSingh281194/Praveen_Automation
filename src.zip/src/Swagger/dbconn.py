import pyodbc
import pandas as pd
def t12ewmbda_conn(query,db):
    server_name='t12ewmdba'
    #database_name='SMI'
    conn=pyodbc.connect('Driver={SQL Server};'
                        f'Server={server_name};'
                        f'Database={db};'
                        'Trusted_Connection=yes;')
    
    df=pd.read_sql_query(query,con=conn)
    return df

def t11ewmbda_conn(query,db):
    server_name='t11ewmdba'
    #database_name='SMI'
    conn=pyodbc.connect('Driver={SQL Server};'
                        f'Server={server_name};'
                        f'Database={db};'
                        'Trusted_Connection=yes;')
    
    df=pd.read_sql_query(query,con=conn)
    return df

def to_excel(reporting_dict,report_path):
    reporting_df=pd.DataFrame(reporting_dict)
    reporting_df.to_excel(report_path,index=False)
