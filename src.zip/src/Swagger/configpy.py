import requests,json

session=requests.session()
cookies_jar={}

#change below 3 attributes as per execution requirement
env='test12'
standard_model_name='B'
type='standard_model'

#sorting and extraction columns
cols_list=['SleeveAPLID','xrefCusip','SleeveWeights']
sort_cols=['sleeve','cusip','weight']

def session_get(url,header=None,payload=None):
    session.get(url=url,verify=False)
    response=requests.get(url=url,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

def session_post(url,header,payload):
    session.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    response=requests.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

def df_extract_cols(df):
    df=df[cols_list]
    df=df.rename(columns={cols_list[0]:sort_cols[0],cols_list[1]: sort_cols[1],cols_list[2]:sort_cols[2]})
    df=df.sort_values(by=sort_cols)
    return df

with open(r'C:\Users\Praveen.Singh\Documents\Data_Automation\src\Swagger\swagger_config.json','r') as context:
    data=context.read()
    properties=json.loads(data)
    if env=='test12':
        env=properties["env_12_details"]["env"]
        clientid=properties["env_12_details"]["clientid"]
        nonce=properties["env_12_details"]["nonce"]
        redirect_uri=properties["env_12_details"]["redirect_uri"]
    elif env=='test10':
        env=properties["env_10_details"]["env"]
        clientid=properties["env_10_details"]["clientid"]
        nonce=properties["env_10_details"]["nonce"]
        redirect_uri=properties["env_10_details"]["redirect_uri"]
    elif env=='test11':
        env=properties["env_11_details"]["env"]
        clientid=properties["env_11_details"]["clientid"]
        nonce=properties["env_11_details"]["nonce"]
        redirect_uri=properties["env_11_details"]["redirect_uri"]
    username=properties["credentials"]["username"]
    password=properties["credentials"]["password"]
    options=properties["credentials"]["options"]
    header=properties["header"]
    url1=properties["urls"]["url1"]
    url2=properties["urls"]["url2"]
    url3=properties["urls"]["url3"]
    url4=properties["urls"]["url4"]
    url5=properties["urls"]["url5"]
    if standard_model_name=='A':
        modelversionid=properties["standard_model"]["Model_A"]["modelversionid"]
        asofdate=properties["standard_model"]["Model_A"]["asofdate"]
    elif standard_model_name=='B':
        modelversionid=properties["standard_model"]["Model_B"]["modelversionid"]
        asofdate=properties["standard_model"]["Model_B"]["asofdate"]
    else:
        modelversionid=properties["standard_model"]["Model_C"]["modelversionid"]
        asofdate=properties["standard_model"]["Model_C"]["asofdate"]

options['warnBeforePasswordExpired']=True
options['multiOptionalFactorEnroll']=True


def payload_creation():
    payload={
       "password":password,
       "username":username,
       "options":options 
    }
 
    return payload
payload=payload_creation()

def url_split(url:str,env:str):
    url_list=url.split("{env}")
    url = url_list[0] + env + url_list[1]
    return url

def url5_split(url:str,clientid:str,nonce:str,redirect_uri:str,session_token:str,state:str):
    url_list=url.split("{clientid}")
    url_list=url_list[0] + clientid + url_list[1]
    url_list=url_list.split('{nonce}')
    url_list=url_list[0] + nonce + url_list[1]
    url_list=url_list.split('{redirect_uri}')
    url_list=url_list[0] + redirect_uri + url_list[1]
    url_list=url_list.split('{session_token}')
    url_list=url_list[0] + session_token + url_list[1]
    url_list=url_list.split('{state}')
    url_list=url_list[0] + state + url_list[1]
    return url_list


    
if env=='test12':
    clientid='0oa154h4vxthGbCau0h8'
    nonce='gQtMyTRwB4rFcAlYnZcPs7CzgzfgoBh4u44T13qGYWXlz5x1hx5ZWVwVoxXOffzP'
    redirect_uri='https://test12.ewealthmanager.com/authorization/callback'

url1=url_split(url1,'test12')
url2=url_split(url2,'test12')

response2 = requests.request("GET", url2,verify=False)
url=str(response2.url)
state=url.split('=')[-1]
response4 = requests.request("POST", url4, data=json.dumps(payload),headers=header,verify=False)
session_token=json.loads(response4.text)['sessionToken']
url5=url5_split(url5,clientid,nonce,redirect_uri,session_token,state)


def compare(swagger_df,db_df):
    cusip_list,weight_list,sleeve_list=([] for i in range(3))

    # result list values append based on scenarios
    expected_sleeve=db_df['sleeve'].values.tolist()
    actual_sleeve=swagger_df['sleeve'].values.tolist()

    expected_cusip=db_df['cusip'].values.tolist()
    actual_cusip=swagger_df['cusip'].values.tolist()

    expected_weight=db_df['weight'].values.tolist()
    actual_weight=swagger_df['weight'].values.tolist()

    # for a,b in zip(expected_cusip,actual_cusip):
    #     cusip_list.append('Pass') if a==b else cusip_list.append('Fail')

    # for a,b in zip(expected_weight,actual_weight):
    #     weight_list.append('Pass') if a==b else weight_list.append('Fail')

    # for a,b in zip(expected_sleeve,actual_sleeve):
    #     sleeve_list.append('Pass') if a==b else sleeve_list.append('Fail')

    cusip_list=zip_func(expected_cusip,actual_cusip,cusip_list)
    sleeve_list=zip_func(expected_sleeve,actual_sleeve,sleeve_list)
    weight_list=zip_func(expected_weight,actual_weight,weight_list)

    return cusip_list,weight_list,sleeve_list

def zip_func(list1,list2,result_list):
    try:
        for a,b in zip(list1,list2):
            result_list.append('Pass') if a==b else result_list.append('Fail')
    except Exception as e:
        print(f'error occured is {e}')
        raise e
    return result_list
    
if type=='standard_model':
    if standard_model_name=='B':

        sql_query= f"""set nocount on
                    select
            Max(SMH.Weight) as ModelWeight,
            M2.APLID as SleeveAPLID,
            
            max(x2.modelversionid) as SleeveModelVersionId
            into #test
        FROM [SMI].[dbo].[Model] m
                JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
                JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
                JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
                JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
                JOIN SMI..model m2 on SMH.XRefID = m2.ModelId

            JOIN SMI..ModelVersion v2 on m2.modelid = v2.modelID
            JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x2 on v2.ModelVersionID = x2.ModelVersionID
            JOIN [SMI].[dbo].[APB] a2 on x2.APBID = a2.APBID
            JOIN SMI..SMI_Holding SMH2 on x2.modelversionid = SMH2.modelVersionID

            WHERE m.APLID = '{modelversionid}' 
            and a.effdt <= '{asofdate}'
            and a2.EffDT <= '{asofdate}'
                AND a.StatusCD = 65004 -- approved apb
                And x.ModelVersionID in (select max(x.ModelVersionID) from [SMI].[dbo].[Model] m
                JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
                JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
                JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
                JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
                JOIN SMI..model m2 on SMH.XRefID = m2.ModelId
            WHERE m.APLID = '{modelversionid}' 
            and a.effdt <= '{asofdate}'
                AND a.StatusCD = 65004)
                group by M2.APLID
        -- order by a.apbid desc, a.effdt desc, x.modelversionid desc, a2.apbid desc, a2.EffDT desc, x2.ModelVersionID desc, M2.APLID asc--, SleeveWeights


    --3. Final query for standard model B to find the holdings for sleeve models
        select 
            ModelWeight,
            SMH.Weight,
            SleeveAPLID,
            SMH.xrefCusip,
            Convert(decimal(12,8),(Convert(decimal(7,3), SMH.Weight) * Convert(decimal(7,3), ModelWeight))/100) as SleeveWeights
            --cast((SMH.Weight * ModelWeight) as decimal(8,4))/100 as SleeveWeights
        from #test as t
        JOIN SMI..SMI_Holding SMH on t.SleeveModelVersionId = SMH.modelVersionID
        order by SleeveAPLID asc, SleeveWeights asc, SMH.xrefCusip asc
                """
        

    elif standard_model_name=='A':
        sql_query=f'''select m.APLID,a.effdt,x.modelversionid,XRefID,SMH.XrefCusip as xrefCusip,SMH.Weight as SleeveWeights  FROM [SMI].[dbo].[Model] m JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID WHERE m.APLID = '{modelversionid}' and a.effDt <= '{asofdate}' AND a.StatusCD = 65004  and x.ModelVersionID in (select max(x.modelversionid) FROM [SMI].[dbo].[Model] m JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID WHERE m.APLID = '{modelversionid}' and a.effDt <= '{asofdate}' AND a.StatusCD = 65004) order by a.apbid desc, a.effdt desc, x.modelversionid desc, Weight asc'''

    else:
        sql_query1= f"""set nocount on
               select 
		m.APLID, 
		a.effdt, 
		x.modelversionid, 
		SMH.HoldingID, 
		SMH.Weight as SleeveWeights, 
		SMH.XRefTypeCD, 
		SMH.XRefID, 
		SMH.XrefCusip as xrefCusip
    FROM [SMI].[dbo].[Model] m
		JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
        JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
        JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
		JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
    WHERE m.APLID = '{modelversionid}' 
		and a.effdt <= '{asofdate}'
        AND a.StatusCD = 65004 -- approved apb
		And SMH.XRefID = '-1'
		and x.ModelVersionID in (select max(x.ModelVersionID) from [SMI].[dbo].[Model] m
            JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
            JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
            JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
			JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
			WHERE m.APLID = '{modelversionid}' 
			and a.effdt <= '{asofdate}'
            AND a.StatusCD = 65004) -- approved apb
	order by a.apbid desc, a.effdt desc, x.modelversionid desc, SMH.XRefID, SMH.Weight

            """
        
        sql_query2=f"""
        set nocount on
        select
		Max(SMH.Weight) as ModelWeight,
		M2.APLID as SleeveAPLID,
		max(x2.modelversionid) as SleeveModelVersionId
	    into #StandardModelC_SleeveHoldings
        FROM [SMI].[dbo].[Model] m
        JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
        JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
        JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
		JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
		JOIN SMI..model m2 on SMH.XRefID = m2.ModelId
		JOIN SMI..ModelVersion v2 on m2.modelid = v2.modelID
		JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x2 on v2.ModelVersionID = x2.ModelVersionID
        JOIN [SMI].[dbo].[APB] a2 on x2.APBID = a2.APBID
		JOIN SMI..SMI_Holding SMH2 on x2.modelversionid = SMH2.modelVersionID
        WHERE m.APLID = '{modelversionid}' 
		and a.effdt <= '{asofdate}'
		and a2.EffDT <= '{asofdate}'
        AND a.StatusCD = 65004 -- approved apb
		And x.ModelVersionID in (select max(x.ModelVersionID) from [SMI].[dbo].[Model] m
		JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID
		JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID
		JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID
		JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID
		JOIN SMI..model m2 on SMH.XRefID = m2.ModelId
		WHERE m.APLID = '{modelversionid}' 
		and a.effdt <= '{asofdate}'
		AND a.StatusCD = 65004)
		group by M2.APLID
       -- order by a.apbid desc, a.effdt desc, x.modelversionid desc, a2.apbid desc, a2.EffDT desc, x2.ModelVersionID desc, M2.APLID asc--, SleeveWeights


    --3. Final query for standard model C to find the holdings
	    select 
		ModelWeight,
		SMH.Weight,
		SleeveAPLID,
		SMH.XrefCusip as xrefCusip,
		Convert(decimal(12,8),(Convert(decimal(7,3), SMH.Weight) * Convert(decimal(7,3), ModelWeight))/100) as SleeveWeights
	    from #StandardModelC_SleeveHoldings as sleeve
		JOIN SMI..SMI_Holding SMH on sleeve.SleeveModelVersionId = SMH.modelVersionID
	    order by SleeveAPLID asc, SleeveWeights asc, SMH.xrefCusip asc
        """