import requests
import json,pyodbc
import pandas as pd
from pathlib import Path 
import configpy as configfile
from configpy import session_get,session_post
import dbconn,smi_model_inputfile

response,cookies_jar=session_get(configfile.url5)
header={'Cookie':'FSSESSION='+cookies_jar['FSSESSION']+'; TargetURL=; ASP.NET_SessionId=' + cookies_jar['ASP.NET_SessionId']+'; GFWMSessionId=' + cookies_jar['GFWMSessionId'] +'; ewm_ns='+ cookies_jar['ewm_ns'] + '; website#lang=' + cookies_jar['website#lang']  }
swagger_url=f"https://{configfile.env}.ewealthmanager.com/api/strategies/v2/models/{configfile.modelversionid}/asofdate/{configfile.asofdate}/holdings"
swagger_response = requests.request("GET", swagger_url,headers=header,verify=False)

swagger_data=json.loads(swagger_response.text)
swagger_df = pd.DataFrame.from_records(swagger_data)        
swagger_df=swagger_df.sort_values(by=configfile.sort_cols)   

if configfile.standard_model_name=='B':
    db_df=dbconn.t12ewmbda_conn(configfile.sql_query,db='SMI')
elif configfile.standard_model_name=='A':
    db_df=dbconn.t12ewmbda_conn(configfile.sql_query,db='SMI')
    db_df.insert(0, "SleeveAPLID", [None]*len(db_df.index),True)
else:
    db_df1=dbconn.t12ewmbda_conn(configfile.sql_query1,db='SMI')
    db_df1.insert(0, "SleeveAPLID", [None]*len(db_df1.index),True)
    db_df2=dbconn.t12ewmbda_conn(configfile.sql_query2,db='SMI')
    db_df = pd.concat([db_df1, db_df2], ignore_index=True)


db_df=configfile.df_extract_cols(db_df)

reporting_dict=dict()
cusip_list,weight_list,sleeve_list=configfile.compare(swagger_df,db_df)

# if smi_model_inputfile.standard_model_name=='A':
#     db_df=dbconn.t12ewmbda_conn(smi_model_inputfile.sql_query_a,db='SMI')
#     db_df.insert(0, "SleeveAPLID", [None]*len(db_df.index),True)
# elif smi_model_inputfile.standard_model_name=='B':
#     db_df=dbconn.t12ewmbda_conn(smi_model_inputfile.sql_query_b,db='SMI')
# else:
#     db_df1=dbconn.t12ewmbda_conn(smi_model_inputfile.sql_query1,db='SMI')
#     db_df1.insert(0, "SleeveAPLID", [None]*len(db_df1.index),True)
#     db_df2=dbconn.t12ewmbda_conn(smi_model_inputfile.sql_query2,db='SMI')
#     db_df = pd.concat([db_df1, db_df2], ignore_index=True)


# db_df=smi_model_inputfile.df_extract_cols(db_df)

# reporting_dict=dict()
# cusip_list,weight_list,sleeve_list=smi_model_inputfile.compare(swagger_df,db_df)

reporting_dict.update({'Sleeve':swagger_df['sleeve'].values.tolist(),'Cusip':swagger_df['cusip'].values.tolist(),'swagger_cusip_weight':swagger_df['weight'].values.tolist(),'DB_cusip_weight':db_df['weight'].values.tolist(),'Sleeve_result':sleeve_list,'Cusip_result':cusip_list,'Weight_result':weight_list})
dbconn.to_excel(reporting_dict,f'src/Swagger/Model_{configfile.standard_model_name}_Result.xlsx')





