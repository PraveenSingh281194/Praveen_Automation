import sys
import json
sys.path.insert(1, r'Framework\Utils')
import deepdiff
import os
from _Logger import logging
from _Exception import CustomException
import _PublishFile
import _API
import _BusinessObject

from ConfigScripts import _Config, _Configurations, _Input, _ModelTypeInput
from _Proposal import ProposalStructure, Create_Proposal
from datetime import datetime
import copy
import pandas as pd
import warnings


if __name__ == '__main__':
    try:    
        warnings.filterwarnings("ignore")
        Api = _API.Api()
        publish_file = _PublishFile.Publish_File()
        # guid = 1

        env = _Configurations.env
        temp = []
        proposal_structure = ProposalStructure()
        # proposal_bodies = [_Input.Get_Proposal_Body_From_Excel(row_index=3)]           # if row in excel is 20, then index = 18, means we have to passs (row number- 2)
        status_report= []
        status_report_path= os.path.join(os.getcwd(),"src","status_report","NAW",f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}")
        os.makedirs(status_report_path,exist_ok=True)

        artifacts_paths = os.path.join(os.getcwd(),"src","Output_Artifacts","NAW",f"RUN_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}")
        os.makedirs(artifacts_paths,exist_ok=True)
        
        time_elapsed_report_df = pd.DataFrame(columns=['account','status','payload','time elapsed(s)'])

        proposal_body_df = pd.read_excel(
                r'src\Artifacts\naw_account_validation.xlsx', sheet_name='Sheet1')
        
        ##comment the below line to trigger code for all the given records
        # proposal_body_df=proposal_body_df.iloc[1:2,:]               ## param_1->row_num-2   and param_2->param_1 + number of records to be executed(atlease add 1 for 1 record)
        
        
        for index, proposal_row in proposal_body_df.iterrows():
            proposal_body, proposal_body_errors=_Input.Get_Transformed_Proposal_Body(proposal_row)
            okta_token = Api.Okta_Token_Call(url=_Config.json_variables[env]["'okta_token'"]["'url'"],
                                    username=_Config.json_variables[env]["'okta_token'"]["'username'"],
                                    password=_Config.json_variables[env]["'okta_token'"]["'password'"],
                                    payload=_Config.json_variables[env]["'okta_token'"]["'payload'"],
                                    header=_Config.json_variables[env]["'okta_token'"]["'header'"])
            
            _Config.json_variables[env]["'generate_business_object'"]["'header'"]['Authorization'] = okta_token
            response_actual = Api.Post_Call(url=_Config.json_variables[env]["'generate_business_object'"]["'url'"], ##her we have to include logging into the code 
                                        payload=json.dumps(proposal_body),
                                        header=_Config.json_variables[env]["'generate_business_object'"]["'header'"])

            payload_artifact_file = f"payloads-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            expected_business_object_artifact_file= f"expected_business_object-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            actual_business_object_artifact_file= f"actual_business_object-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            business_object_differences_file= f"business_object_differences-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            error_list_file= f"error_list.json"

            if('customModelId' in list(proposal_body.keys())):
                artifacts_path = os.path.join(artifacts_paths,f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')} for-{proposal_row['accountId']}__{proposal_body['targetModelId']}__{proposal_body['customModelId']}")
            else:
                artifacts_path = os.path.join(artifacts_paths,f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')} for-{proposal_row['accountId']}__{proposal_body['targetModelId']}")
                
            os.makedirs(artifacts_path,exist_ok=True)

            payload_artifact_file_path = os.path.join(artifacts_path,payload_artifact_file)
            expected_business_object_artifact_file_path = os.path.join(artifacts_path,expected_business_object_artifact_file)
            actual_business_object_artifact_file_path = os.path.join(artifacts_path,actual_business_object_artifact_file)
            business_object_differences_artifact_file_path = os.path.join(artifacts_path,business_object_differences_file)
            error_list_file_path = os.path.join(artifacts_path,error_list_file)


            publish_file.Publish_Json_File(
                proposal_body, filename=payload_artifact_file_path)
            
            time_elapsed_report_df=time_elapsed_report_df.append({'account':proposal_row['accountId'],'status':response_actual.status_code,"payload":proposal_body,'time elapsed(s)':response_actual.elapsed.total_seconds()},ignore_index=True)
            error_list=[]

            if(response_actual.status_code==500):
                error_list.append({
                    "status_code":response_actual.status_code,
                    "account":proposal_row['accountId'],
                    "payload":proposal_body,
                    "reason":json.loads(response_actual.text)['detail']
                })
                status_report.append({
                    "status":response_actual.status_code,
                    "account":proposal_row['accountId'],
                    "payload":proposal_body,
                    "reason":json.loads(response_actual.text)['detail']
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)
            
            elif(response_actual.status_code==400):
                temp_400_errors=[]
                for error in proposal_body_errors:
                    if(error['key']=="overlaySettingId"):
                        temp_400_errors.append(error['reason'])

                    if(error['key']=="taxSensitivity"):
                        temp_400_errors.append(error['reason'])

                    if(error['key']=="mutualFundDisposalMethod"):
                        temp_400_errors.append(error['reason'])
                error_list={
                    "status_code":response_actual.status_code,
                    "account":proposal_row['accountId'],
                    "payload":proposal_body,
                    "reason":temp_400_errors
                }
                status_report.append(error_list)
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)
            
            elif(response_actual.status_code==422):
                error_list.append({
                    "status_code":response_actual.status_code,
                    "account":proposal_row['accountId'],
                    "payload":proposal_body,
                    "reason":json.loads(response_actual.text)['errors']
                })
                status_report.append({
                    "status":response_actual.status_code,
                    "account":proposal_row['accountId'],
                    "payload":proposal_body,
                    "reason":json.loads(response_actual.text)['errors']
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)

            elif(response_actual.status_code==200):
                status_report.append({"status":response_actual.status_code,"account":proposal_row['accountId'],"payload":proposal_body,"reason":"Success!"})
                if('customModelId' in list(proposal_body.keys())):
                    publish_file.Publish_Json_File(
                        {"model_type":"custom_model","model_id":str(proposal_body['customModelId'])}, filename="src\Config\_ModelTypeInput.json")
                else:
                    publish_file.Publish_Json_File(
                        {"model_type":"standard_model","model_id":str(proposal_body['targetModelId'])}, filename="src\Config\_ModelTypeInput.json")
                
                
                logging.info(
                    f"Okta token received for overlaySettingId -> {proposal_body['overlaySettingId']}")
                
                # update token to header
                _Config.json_variables[env]["'get_setting_by_setting_id'"]["'header'"]['Authorization'] = okta_token
                
                # update token to header
                _Config.json_variables[env]["'get_holding_by_account_id'"]["'header'"]['Authorization'] = okta_token
                
                # update url and hit get setting by setting id API
                setting_response = Api.Get_Call(url=_Config.json_variables[env]["'get_setting_by_setting_id'"]["'url'"].format(proposal_body['overlaySettingId']),
                                                header=_Config.json_variables[env]["'get_setting_by_setting_id'"]["'header'"])
                # get setting
                settings = json.loads(setting_response.text)

                # get account id
                account_id = settings['accountId']
                
                logging.info(f'The account id we are using-> {account_id}')

                # update url and hit get setting by account id API
                holding_response = Api.Get_Call(url=_Config.json_variables[env]["'get_holding_by_account_id'"]["'url'"].format(account_id),
                                                header=_Config.json_variables[env]["'get_holding_by_account_id'"]["'header'"])

                # get holding
                holdings = json.loads(holding_response.text)
    
                for index, tax_sensitivity in enumerate(proposal_body['taxSensitivities']):
                    if(tax_sensitivity =="VeryHigh"):
                        tax_sensitivity= "Very_High"
                    if(tax_sensitivity=="TradeToModel"):
                        tax_sensitivity="TRADE_TO_MODEL"

                    result = Create_Proposal(account_id=account_id, settings=settings,
                                            holdings=holdings, tax_sensitivity=tax_sensitivity,input_proposal_body= proposal_body)
                    
                    if(tax_sensitivity =="Very_High"):
                        tax_sensitivity= "VeryHigh"
                    if(tax_sensitivity=="TRADE_TO_MODEL"):
                        tax_sensitivity="TradeToModel"

                    request_mapping_artifact_file= f"request_mapping for__{tax_sensitivity}__{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
                    request_mapping_artifact_file_path = os.path.join(artifacts_path,request_mapping_artifact_file)

                    publish_file.Publish_Json_File(
                        result, filename=request_mapping_artifact_file_path)
                    
                    logging.info(
                        f'Published Proposal to json file in -> {request_mapping_artifact_file_path}')
                    
                    _Config.json_variables[env]["'proxy_generate_proposal'"]["'header'"]['Authorization'] = okta_token
                    
                    blk_response_obj = Api.Post_Call(url=_Config.json_variables[_Configurations.env]["'proxy_generate_proposal'"]["'url'"],
                                                    payload=json.dumps(result),
                                                    header=_Config.json_variables[_Configurations.env]["'proxy_generate_proposal'"]["'header'"])
                    
                    logging.info('Make a hit to Blackrock Generate Ptoposal API')
                    
                    blk_response = json.loads(blk_response_obj.text)
                    
                    if(index == 0):
                        businessObject = _BusinessObject.Create_businessObject(
                            blk_response=blk_response, struct=_BusinessObject.BusinessObjectStructure.businessObject, taxSensitivity=tax_sensitivity)
                    
                    else:
                        businessObject['proposedFutureStates'].append(_BusinessObject.Create_proposedFutureStates(
                            blk_response=blk_response, struct=_BusinessObject.BusinessObjectStructure.proposedFutureStates, taxSensitivity=tax_sensitivity))
                
                logging.info(
                    'Created Business Object out of Generate Proposal API Response')
                    # proposedFutureStateObject = _BusinessObject.Create_proposedFutureStates()
                
                publish_file.Publish_Json_File(
                    businessObject, filename=expected_business_object_artifact_file_path)
                
                logging.info(
                    f'Published Business Object to json file in -> {expected_business_object_artifact_file_path}')

                publish_file.Publish_Json_File(
                    json.loads(response_actual.text), filename=actual_business_object_artifact_file_path)

                publish_file.Publish_Json_File(deepdiff.DeepDiff(
                    businessObject, json.loads(response_actual.text)),filename=business_object_differences_artifact_file_path)

        publish_file.Publish_Json_File(
                    status_report, filename=os.path.join(status_report_path,"status_report.json"))
        publish_file.Publish_Json_File(
                    time_elapsed_report_df.to_dict('index'), filename=os.path.join(status_report_path,"time_elapsed_report.json"))
        time_elapsed_report_df.to_csv(
                    os.path.join(status_report_path,"time_elapsed_report.csv"))
    except Exception as e:
        publish_file.Publish_Json_File(
                    status_report, filename=os.path.join(status_report_path,"status_report.json"))
        publish_file.Publish_Json_File(
                    time_elapsed_report_df.to_dict('index'), filename=os.path.join(status_report_path,"time_elapsed_report.json"))
        time_elapsed_report_df.to_csv(
                    os.path.join(status_report_path,"time_elapsed_report.csv"))
        raise CustomException(e,sys)