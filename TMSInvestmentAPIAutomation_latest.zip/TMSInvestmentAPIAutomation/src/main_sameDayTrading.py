import sys
import json
sys.path.insert(1, r'Framework\Utils')
import deepdiff
import os
from _Logger import logging
from _Exception import CustomException
import _PublishFile
import _API
from _SameDayTrading import Create_sameDayTrading
import _BusinessObject
from ConfigScripts import _Config, _Configurations, _Input
from datetime import datetime
import copy
import pandas as pd
import warnings

warnings.filterwarnings('ignore')

if __name__ == '__main__':
    try:    
        Api = _API.Api()
        publish_file=_PublishFile.Publish_File()
        env = _Configurations.env
        SDT_body_df = pd.read_csv(
            r'src\Artifacts\SDT Sample Test Data Template_06122023.csv')
        artifacts_paths = os.path.join(os.getcwd(),"src","Output_Artifacts","SDT",f"RUN_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}")
        os.makedirs(artifacts_paths,exist_ok=True)

        status_report= []
        status_report_path= os.path.join(os.getcwd(),"src","status_report","SDT",f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}")
        os.makedirs(status_report_path,exist_ok=True)

        time_elapsed_report_df = pd.DataFrame(columns=['account','status','payload','time elapsed(s)'])

        SDT_body_df=SDT_body_df.iloc[:1,:]               ## param_1->row_num-2   and param_2->param_1 + number of records to be executed(atlease add 1 for 1 record)




        for index, STD_row in SDT_body_df.iterrows():

            okta_token = Api.Okta_Token_Call(url=_Config.json_variables[env]["'okta_token'"]["'url'"],
                                    username=_Config.json_variables[env]["'okta_token'"]["'username'"],
                                    password=_Config.json_variables[env]["'okta_token'"]["'password'"],
                                    payload=_Config.json_variables[env]["'okta_token'"]["'payload'"],
                                    header=_Config.json_variables[env]["'okta_token'"]["'header'"])
                    
            SDT_body=_Input.Get_Transformed_SDT_Body(STD_row)


            payload_artifact_file = f"payloads-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            expected_business_object_artifact_file= f"expected_business_object-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            actual_business_object_artifact_file= f"actual_business_object-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            business_object_differences_file= f"business_object_differences-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            expected_GUID_artifact_file= f"expected_GUID-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            actual_GUID_artifact_file= f"actual_GUID-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            error_list_file= f"error_list-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json.json"
            request_mapping_artifact_file= f"request_mapping__{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            portfolio_artifact_file= f"portfolio-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            benchmarks_artifact_file= f"benchmarks-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            
            artifacts_path = os.path.join(artifacts_paths,f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')} for-{SDT_body['accountId']}")
            os.makedirs(artifacts_path,exist_ok=True)
            

            payload_artifact_file_path = os.path.join(artifacts_path,payload_artifact_file)
            expected_business_object_artifact_file_path = os.path.join(artifacts_path,expected_business_object_artifact_file)
            actual_business_object_artifact_file_path = os.path.join(artifacts_path,actual_business_object_artifact_file)
            business_object_differences_artifact_file_path = os.path.join(artifacts_path,business_object_differences_file)
            expected_GUID_artifact_file_path= os.path.join(artifacts_path,expected_GUID_artifact_file)
            actual_GUID_artifact_file_path= os.path.join(artifacts_path,actual_GUID_artifact_file)
            error_list_file_path = os.path.join(artifacts_path,error_list_file)
            request_mapping_artifact_file_path = os.path.join(artifacts_path,request_mapping_artifact_file)
            portfolio_artifact_file_path= os.path.join(artifacts_path,portfolio_artifact_file)
            benchmarks_artifact_file_path= os.path.join(artifacts_path,benchmarks_artifact_file)
            
            publish_file.Publish_Json_File(
                    SDT_body, filename=payload_artifact_file_path)

            ## Hit the SDT actual endpoint
            
            _Config.json_variables[env]["'create_withdrawl_trade'"]["'header'"]['Authorization'] = okta_token
            actual_response = Api.Post_Call(url=_Config.json_variables[_Configurations.env]["'create_withdrawl_trade'"]["'url'"],
                    payload=json.dumps(SDT_body),
                    header=_Config.json_variables[_Configurations.env]["'create_withdrawl_trade'"]["'header'"])
            
            
            status_code=actual_response.status_code
            
            time_elapsed_report_df=time_elapsed_report_df.append({'account':SDT_body['accountId'],'status':actual_response.status_code,"payload":SDT_body,'time elapsed(s)':actual_response.elapsed.total_seconds()},ignore_index=True)
            

            error_list=[]
            if(actual_response.status_code==422):
                error_list.append({
                    "status_code":actual_response.status_code,
                    "account":SDT_body['accountId'],
                    "payload":SDT_body,
                    "reason":json.loads(actual_response.text)['errors']
                })
                status_report.append({
                    "status":actual_response.status_code,
                    "account":SDT_body['accountId'],
                    "payload":SDT_body,
                    "reason":json.loads(actual_response.text)['errors']
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)
            elif(actual_response.status_code==400):
                error_list.append({
                    "status_code":actual_response.status_code,
                    "account":SDT_body['accountId'],
                    "payload":SDT_body,
                    "reason":actual_response.text
                })
                status_report.append({
                        "status":actual_response.status_code,
                        "account":SDT_body['accountId'],
                        "payload":SDT_body,
                        "reason":actual_response.text 
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)
            elif(actual_response.status_code==500):
                error_list.append({
                    "status_code":actual_response.status_code,
                    "account":SDT_body['accountId'],
                    "payload":SDT_body,
                    "reason":json.loads(actual_response.text)['detail']
                })
                status_report.append({
                        "status":actual_response.status_code,
                        "account":SDT_body['accountId'],
                        "payload":SDT_body,
                        "reason":json.loads(actual_response.text)['detail']
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)

            if(status_code==201):

                status_report.append({
                            "status":actual_response.status_code,
                            "account":SDT_body['accountId'],
                            "payload":SDT_body,
                            "reason":""
                    })
                
                ## retreive actual GUID
                actual_GUID=actual_response.text[1:-1]

                publish_file.Publish_Json_File(
                    {"GUID":actual_GUID}, filename=actual_GUID_artifact_file_path)

                ## hit get_portfolio_by_account_id 
                _Config.json_variables[env]["'get_portfolio_by_account_id'"]["'header'"]['Authorization'] = okta_token
                portfolio_response=Api.Get_Call(
                    url=_Config.json_variables[env]["'get_portfolio_by_account_id'"]["'url'"].format(SDT_body['accountId']),
                    header=_Config.json_variables[env]["'get_portfolio_by_account_id'"]["'header'"])
                
                ## retreive the portfolio for the given account
                portfolio=json.loads(portfolio_response.text)


                publish_file.Publish_Json_File(
                    portfolio, filename=portfolio_artifact_file_path)

                ##retreive benchmark reference id from portfolio
                benchmark_ref_id=portfolio['benchmarkRef']['id']

                ## hit get banchmarks_by_reference_if to get benchmarks
                _Config.json_variables[env]["'get_benchmarks_by_reference_id'"]["'header'"]['Authorization'] = okta_token
                benchamrks_response=Api.Get_Call(
                    url=_Config.json_variables[env]["'get_benchmarks_by_reference_id'"]["'url'"].format(benchmark_ref_id),
                    header=_Config.json_variables[env]["'get_benchmarks_by_reference_id'"]["'header'"])
                
                ## retreive the benchmarks for the extarcted reference id
                benchmarks=json.loads(benchamrks_response.text)

                publish_file.Publish_Json_File(
                    benchmarks, filename=benchmarks_artifact_file_path)

                ## construct the SDT request mapping
                SDT_request_mapping=Create_sameDayTrading(portfolio=portfolio,benchmarks=benchmarks,SDT_body=SDT_body)

                publish_file.Publish_Json_File(
                    SDT_request_mapping, filename=request_mapping_artifact_file_path)

                _Config.json_variables[env]["'proxy_generate_proposal_stateful'"]["'header'"]['Authorization'] = okta_token
                expected_response = Api.Post_Call(url=_Config.json_variables[_Configurations.env]["'proxy_generate_proposal_stateful'"]["'url'"],
                        payload=json.dumps(SDT_request_mapping),
                        header=_Config.json_variables[_Configurations.env]["'proxy_generate_proposal_stateful'"]["'header'"])
                
                expected_GUID=json.loads(expected_response.text)['id']

                publish_file.Publish_Json_File(
                    {"GUID":expected_GUID}, filename=expected_GUID_artifact_file_path)

                _Config.json_variables[env]["'get_trade_by_GUID'"]["'header'"]['Authorization'] = okta_token
                actual_trade_response=Api.Get_Call(
                    url=_Config.json_variables[_Configurations.env]["'get_trade_by_GUID'"]["'url'"].format(actual_GUID),
                    header=_Config.json_variables[_Configurations.env]["'get_trade_by_GUID'"]["'header'"])
                print(_Config.json_variables[_Configurations.env]["'get_trade_by_GUID'"]["'url'"].format(str(actual_GUID)))
                print(actual_trade_response)

                ## pass expected GUID in Get proposal APi
                _Config.json_variables[_Configurations.env]["'get_proxy_proposal_by_GUID'"]["'header'"]['Authorization'] = okta_token
                proxy_proposal_response=Api.Get_Call(
                    url=_Config.json_variables[_Configurations.env]["'get_proxy_proposal_by_GUID'"]["'url'"].format(expected_GUID),
                    header=_Config.json_variables[_Configurations.env]["'get_proxy_proposal_by_GUID'"]["'header'"])
                print(proxy_proposal_response)

                ## then transform this blk_response to business Object
                businessObject = _BusinessObject.Create_businessObject(
                                                blk_response=json.loads(proxy_proposal_response.text), struct=_BusinessObject.BusinessObjectStructure.businessObject, taxSensitivity=portfolio['metadata']['TAX_SENSITIVITY'])

                ## Comapre actual_business_obejct and expected business Object
                
                publish_file.Publish_Json_File(deepdiff.DeepDiff(
                        businessObject, json.loads(actual_trade_response.text)),filename=business_object_differences_artifact_file_path)
    
        publish_file.Publish_Json_File(
                        status_report, filename=os.path.join(status_report_path,"status_report.json"))
        publish_file.Publish_Json_File(
                    time_elapsed_report_df.to_dict('index'), filename=os.path.join(status_report_path,"time_elapsed_report.json"))
        time_elapsed_report_df.to_csv(
                    os.path.join(status_report_path,"time_elapsed_report.csv"))
    except Exception as e:
        publish_file.Publish_Json_File(
                        status_report, filename=os.path.join(status_report_path,"status_report.json"))
        publish_file.Publish_Json_File(
                    time_elapsed_report_df.to_dict('index'), filename=os.path.join(status_report_path,"time_elapsed_report.json"))
        time_elapsed_report_df.to_csv(
                    os.path.join(status_report_path,"time_elapsed_report.csv"))
        raise CustomException(e,sys)