import sys
import json
sys.path.insert(1, r'Framework\Utils')

import deepdiff
import os
from _Logger import logging
from _Exception import CustomException
import _PublishFile
import _API
import _BusinessObject,_OAM

from ConfigScripts import _Config, _Configurations, _Input, _ModelTypeInput
# from _Proposal import ProposalStructure, Create_Proposal
from datetime import datetime
import copy
import pandas as pd

if __name__=='__main__':
    try:
        env=_Configurations.env
        Api=_API.Api()
        publish_file=_PublishFile.Publish_File()

        OAM_body_df = pd.read_excel(r'src\Artifacts\TMS OAM Removal Proposal Test cases_Test Data_06142023.xlsx',sheet_name='Sheet1')

        artifacts_paths = os.path.join(os.getcwd(),"src","Output_Artifacts","OAM",f"RUN_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}")
        os.makedirs(artifacts_paths,exist_ok=True)

        status_report= []
        status_report_path= os.path.join(os.getcwd(),"src","status_report","OAM",f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}")
        os.makedirs(status_report_path,exist_ok=True)

        time_elapsed_report_df = pd.DataFrame(columns=['account','status','payload','time elapsed(s)'])

        OAM_body_df=OAM_body_df.iloc[:5,:]               ## param_1->row_num-2   and param_2->param_1 + number of records to be executed(atlease add 1 for 1 record)

        for index, OAM_row in OAM_body_df.iterrows():
            
            OAM_body= _Input.Get_Transformed_OAM_Body(OAM_row)

            payload_artifact_file = f"payloads-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            expected_business_object_artifact_file= f"expected_business_object-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            actual_business_object_artifact_file= f"actual_business_object-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            business_object_differences_file= f"business_object_differences-{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"
            error_list_file= f"error_list.json"
            request_mapping_artifact_file= f"request_mapping__{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.json"

            if('customModelId' in list(OAM_body.keys())):
                artifacts_path = os.path.join(artifacts_paths,f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')} for-{OAM_body['accountId']}__{OAM_body['targetModelId']}__{OAM_body['customModelId']}")
            else:
                artifacts_path = os.path.join(artifacts_paths,f"{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')} for-{OAM_body['accountId']}__{OAM_body['targetModelId']}")
            os.makedirs(artifacts_path,exist_ok=True)

            payload_artifact_file_path = os.path.join(artifacts_path,payload_artifact_file)
            expected_business_object_artifact_file_path = os.path.join(artifacts_path,expected_business_object_artifact_file)
            actual_business_object_artifact_file_path = os.path.join(artifacts_path,actual_business_object_artifact_file)
            business_object_differences_artifact_file_path = os.path.join(artifacts_path,business_object_differences_file)
            error_list_file_path = os.path.join(artifacts_path,error_list_file)
            request_mapping_artifact_file_path = os.path.join(artifacts_path,request_mapping_artifact_file)

            if('customModelId' in list(OAM_body.keys())):
                publish_file.Publish_Json_File(
                    {"model_type":"custom_model","model_id":str(OAM_body['customModelId'])}, filename="src\Config\_ModelTypeInput.json")
            else:
                publish_file.Publish_Json_File(
                    {"model_type":"standard_model","model_id":str(OAM_body['targetModelId'])}, filename="src\Config\_ModelTypeInput.json")
            
            publish_file.Publish_Json_File(
                OAM_body, filename=payload_artifact_file_path)


            okta_token = Api.Okta_Token_Call(url=_Config.json_variables[env]["'okta_token'"]["'url'"],
                                 username=_Config.json_variables[env]["'okta_token'"]["'username'"],
                                 password=_Config.json_variables[env]["'okta_token'"]["'password'"],
                                 payload=_Config.json_variables[env]["'okta_token'"]["'payload'"],
                                 header=_Config.json_variables[env]["'okta_token'"]["'header'"])
            
            ##  Call the final endpoint here
            _Config.json_variables[env]["'removal_impact'"]["'header'"]['Authorization'] = okta_token
            response_actual= Api.Post_Call(url=_Config.json_variables[_Configurations.env]["'removal_impact'"]["'url'"],
                                           payload=json.dumps(OAM_body),
                                            header=_Config.json_variables[_Configurations.env]["'removal_impact'"]["'header'"])
            
            time_elapsed_report_df=time_elapsed_report_df.append({'account':OAM_body['accountId'],'status':response_actual.status_code,"payload":OAM_body,'time elapsed(s)':response_actual.elapsed.total_seconds()},ignore_index=True)
        

            error_list=[]
            if(response_actual.status_code==422):
                error_list.append({
                    "status_code":response_actual.status_code,
                    "account":OAM_body['accountId'],
                    "payload":OAM_body,
                    "reason":json.loads(response_actual.text)['errors']
                })
                status_report.append({
                    "status":response_actual.status_code,
                    "account":OAM_body['accountId'],
                    "payload":OAM_body,
                    "reason":json.loads(response_actual.text)['errors']
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)
            elif(response_actual.status_code==400):
                error_list.append({
                    "status_code":response_actual.status_code,
                    "account":OAM_body['accountId'],
                    "payload":OAM_body,
                    "reason":""
                })
                status_report.append({
                        "status":response_actual.status_code,
                        "account":OAM_body['accountId'],
                        "payload":OAM_body,
                        "reason":""
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)
            elif(response_actual.status_code==500):
                error_list.append({
                    "status_code":response_actual.status_code,
                    "account":OAM_body['accountId'],
                    "payload":OAM_body,
                    "reason":json.loads(response_actual.text)['detail']
                })
                status_report.append({
                        "status":response_actual.status_code,
                        "account":OAM_body['accountId'],
                        "payload":OAM_body,
                        "reason":json.loads(response_actual.text)['detail']
                })
                publish_file.Publish_Json_File(
                    error_list, filename=error_list_file_path)
            elif(response_actual.status_code==200):
                status_report.append({
                        "status":response_actual.status_code,
                        "account":OAM_body['accountId'],
                        "payload":OAM_body,
                        "reason":""
                })

                #update token to header
                _Config.json_variables[env]["'generate_oam_proxy_url'"]["'header'"]['Authorization'] = okta_token

                #update url and hit get setting by setting id API
                portfolio_response = Api.Get_Call(url=_Config.json_variables[env]["'generate_oam_proxy_url'"]["'url'"].format(OAM_body["accountId"]),
                                                header=_Config.json_variables[env]["'generate_oam_proxy_url'"]["'header'"])

                portfolio_data = json.loads(portfolio_response.text)

                logging.info("Swagger DataFrame has been Created succesfully")

                oam_request_mapping= _OAM.create_oam_json_structure(account_id=OAM_body['accountId'],portfolio_data=portfolio_data)

                logging.info('OAM request has been created succesfully')
                publish_file.Publish_Json_File(oam_request_mapping,filename=request_mapping_artifact_file_path)
                logging.info("A File with name OAM_BLK_Mapping.json has been created succesfully")
                # publish_file.Publish_Json_File(
                #     businessObject, filename=request_mapping_artifact_file_path)

                okta_token = Api.Okta_Token_Call(url=_Config.json_variables[env]["'okta_token'"]["'url'"],
                                            username=_Config.json_variables[env]["'okta_token'"]["'username'"],
                                            password=_Config.json_variables[env]["'okta_token'"]["'password'"],
                                            payload=_Config.json_variables[env]["'okta_token'"]["'payload'"],
                                            header=_Config.json_variables[env]["'okta_token'"]["'header'"])

                _Config.json_variables[env]["'proxy_generate_proposal'"]["'header'"]['Authorization'] = okta_token
                logging.info("Okta Token has been generated successfully")
                blk_response_obj = Api.Post_Call(url=_Config.json_variables[_Configurations.env]["'proxy_generate_proposal'"]["'url'"],
                                                                payload=json.dumps(oam_request_mapping),
                                                                header=_Config.json_variables[_Configurations.env]["'proxy_generate_proposal'"]["'header'"])
                
                businessObject = _BusinessObject.Create_businessObject(
                                        blk_response=json.loads(blk_response_obj.text), struct=_BusinessObject.BusinessObjectStructure.businessObject, taxSensitivity='TradeToModel')

                logging.info("Business Object has been created Succesfully")

                publish_file.Publish_Json_File(
                    businessObject, filename=expected_business_object_artifact_file_path)
                
                logging.info(
                    f'Published Business Object to json file in -> {expected_business_object_artifact_file_path}')
                


                publish_file.Publish_Json_File(
                    json.loads(response_actual.text), filename=actual_business_object_artifact_file_path)

                publish_file.Publish_Json_File(deepdiff.DeepDiff(
                    businessObject, json.loads(response_actual.text)),filename=business_object_differences_artifact_file_path)
        publish_file.Publish_Json_File(
                    status_report, filename=os.path.join(status_report_path,"status_report.json"))
        publish_file.Publish_Json_File(
                    time_elapsed_report_df.to_dict('index'), filename=os.path.join(status_report_path,"time_elapsed_report.json"))
        time_elapsed_report_df.to_csv(
                    os.path.join(status_report_path,"time_elapsed_report.csv"))

    except Exception as e:
        publish_file.Publish_Json_File(
                    status_report, filename=os.path.join(status_report_path,"status_report.json"))
        publish_file.Publish_Json_File(
                    time_elapsed_report_df.to_dict('index'), filename=os.path.join(status_report_path,"time_elapsed_report.json"))
        time_elapsed_report_df.to_csv(
                    os.path.join(status_report_path,"time_elapsed_report.csv"))
        raise CustomException(e,sys)

