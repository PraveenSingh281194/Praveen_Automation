import sys
sys.path.insert(1, r'Framework\Utils')
sys.path.insert(1, r'Framework\Utils')
from datetime import datetime, timedelta, timezone
from _Exception import CustomException
from _Logger import logging
import json
import copy
import pandas as pd
import uuid


class sameDayTradingStructure:

    SAMEDAYTRADING={
        "id":"string",
        "expiryTimestamp":"string",
        "reason":"string",
        "aggregate":{}
    }

    SAMEDAYTRADING_AGGREGATE={
        "id":"string",
        "tag":"string",
        "currency":"USD",
        "benchmark":{},
        "portfolios":[]
    }

    SAMEDAYTRADING_AGGREGATE_BENCHMARK={
        "id":"string",
        "currency":"USD",
        "components":[],
        # "metadata":{
        #     "Name":"string"
        # }
    }

    SAMEDAYTRADING_AGGREGATE_PORTFOLIOS={
        "id":"string",
        "currency":"string",
        "positions":[],
        "openLots":[],
        "closedLots":[],
        "benchmark":{},
        "metadata":{}
    }

    SAMEDAYTRADING_AGGREGATE_BENCHMARK_COMPONENTS={
        "id":"string",
        "identifiers":{
            "clientId":"string"
        },
        "weight":"double",
        "posInfo":{
            "SLEEVE_ID":"string"
        }
    }

    SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_POSITIONS={
        "id":"string",
        "identifiers":{
            "clientId":"string"
        },
        "quantity":"double",
        "marketValue":"double",
        "notionalMarketValue":"double",
        "posInfo":{
            "POSITION_LOCK":"string",
            "POSITION_FORCE_SELL":"string",
            "SLEEVE_ID":"BLANK(string)"
        }
    }

    SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_OPENLOTS={
        "id":"string",
        "positionId":"string",
        "purchaseDate":"string",
        "quantity":"double",
        "costBasis":"double",
        "lotInfo":{
            "CUSTODIAN_LOT_ID":"string"
        }
    }

    SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_CLOSEDLOTS={
        "identifiers":{
            "clientId":"string"
        },
        "purchaseDate":"string",
        "closedDate":"string",
        "realizedGainOrLoss":"double"
    }

    SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_BENCHMARK={
        "id":"string",
        "currency":"USD",
        "components":[],
        # "metadata":{
        #     "Name":"string"
        # }
    }

    SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_METADATA={
        "TAX_SENSITIVITY": "string",
        "DISPOSAL_METHOD_MF": "string",
        "DISPOSAL_METHOD_OTHER": "string",
        "ACCOUNT_TYPE": "string",
        "LONG_TERM_TAX_RATE": "double",
        "SHORT_TERM_TAX_RATE": "double",
        "STATE_TAX_RATE": "double",
        "SHORT_TERM_GAIN_BUDGET":"double",
        "LONG_TERM_GAIN_BUDGET": "double",
        "ACCOUNT_ID": "string",
        "REALIZED_YTD_STG": "double",
        "REALIZED_YTD_LTG": "double",
        "REALIZED_YTD_STL": "double",
        "REALIZED_YTD_LTL": "double",
        "SECURITY_NO_BUY":"need to discuss datatype",
        "GICS_NO_HOLD":"string",
        "GICS_NO_TRADE":"string",
        "CUSTODIAN_CODE": "string",
        "CUSTODIAN_ACCOUNT": "string",
        "MODEL_TYPE": "string",
        "AGENT_CODE": "string",
        "AGENT_NAME": "string",
        "BD_NAME": "string",
        "REGIONAL_CONSULTANT": "string",
        "ACCOUNT_REGISTRATION": "string",
        "SHELL_MODEL_ID":"string",
        "SETTLED_CASH_ONLY": "string",
        "SETTLED_CASH_BALANCE":"string",
        "NAME":"string"
    }

    SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_BENCHMARK_COMPONENTS={
        "id":"string",
        "identifiers":{
            "clientId":""
        },
        "weight":"double",
        "posInfo":{
            "SLEEVE_ID":"string"
        }
    }

#########################################################################################################################################################

sameDayTrading_structure=sameDayTradingStructure()

#########################################################################################################################################################

def Create_sameDayTrading(portfolio:dict,benchmarks:dict,SDT_body:dict)->dict:
    try:
        sameDayTrading_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING)
        sameDayTrading_structure_copy['id']=str(uuid.uuid4())
        sameDayTrading_structure_copy['expiryTimestamp']= datetime.now(timezone.utc).strftime("%Y-%m-%d") +'T18:55:00Z'          ## date time in the format fo UTC
        sameDayTrading_structure_copy['reason']="WITHDRAWAL"
        sameDayTrading_structure_copy['aggregate']=Create_sameDayTrading_aggregate(portfolio=portfolio,benchmarks=benchmarks,SDT_body=SDT_body)
        return sameDayTrading_structure_copy
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate(portfolio:dict,benchmarks:dict,SDT_body:dict)->dict:
    try:
        sameDayTrading_aggregate_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE)
        sameDayTrading_aggregate_structure_copy['id']=portfolio['id']
        sameDayTrading_aggregate_structure_copy['tag']="AGGREGATE"
        sameDayTrading_aggregate_structure_copy['currency']="USD"
        sameDayTrading_aggregate_structure_copy['benchmark']=Create_sameDayTrading_aggregate_benchmark(portfolio=portfolio,benchmarks=benchmarks)
        sameDayTrading_aggregate_structure_copy['portfolios'].append(Create_sameDayTrading_aggregate_portfolios(portfolio=portfolio,benchmarks=benchmarks,SDT_body=SDT_body))
        return sameDayTrading_aggregate_structure_copy
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_benchmark(portfolio:dict,benchmarks:dict)->dict:
    try:
        sameDayTrading_aggregate_benchmark_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_BENCHMARK)
        sameDayTrading_aggregate_benchmark_structure_copy['id']=portfolio['benchmarkRef']['id']
        sameDayTrading_aggregate_benchmark_structure_copy['currency']=benchmarks['currency']
        sameDayTrading_aggregate_benchmark_structure_copy['components']=Create_sameDayTrading_aggregate_benchmark_components(components=benchmarks['components'])
        # sameDayTrading_aggregate_benchmark_structure_copy['metadata']["Name"]= benchmarks['metadata']['NAME']
        return sameDayTrading_aggregate_benchmark_structure_copy
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_portfolios(portfolio:dict,benchmarks:dict,SDT_body:dict)->dict:
    try:
        sameDayTrading_aggregate_portfolios_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS)
        sameDayTrading_aggregate_portfolios_structure_copy['id']=SDT_body['accountId']
        sameDayTrading_aggregate_portfolios_structure_copy['currency']="USD"
        sameDayTrading_aggregate_portfolios_structure_copy['positions']=Create_sameDayTrading_aggregate_portfolios_positions(positions=portfolio['positions'],SDT_body=SDT_body)
        sameDayTrading_aggregate_portfolios_structure_copy['openLots']=Create_sameDayTrading_aggregate_portfolios_openLots(openLots=portfolio['openLots'])
        if('closedLots' in list(portfolio.keys())):
            sameDayTrading_aggregate_portfolios_structure_copy['closedLots']=Create_sameDayTrading_aggregate_portfolios_closedLots(closedLots=portfolio['closedLots'])
        else:
            del sameDayTrading_aggregate_portfolios_structure_copy['closedLots']
        sameDayTrading_aggregate_portfolios_structure_copy['benchmark']=Create_sameDayTrading_aggregate_portfolios_benchmark(portfolio=portfolio,benchmarks=benchmarks)
        sameDayTrading_aggregate_portfolios_structure_copy['metadata']=Create_sameDayTrading_aggregate_portfolios_metadata(metadata=portfolio['metadata'])
        return sameDayTrading_aggregate_portfolios_structure_copy
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_benchmark_components(components:list)->list:
    try:
        temp_components=[]
        for component in components:
            sameDayTrading_aggregate_benchmark_components_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_BENCHMARK_COMPONENTS)
            sameDayTrading_aggregate_benchmark_components_structure_copy['id']=component['id']
            sameDayTrading_aggregate_benchmark_components_structure_copy['identifiers']['clientId']=component['identifiers']['clientId']
            sameDayTrading_aggregate_benchmark_components_structure_copy['weight']=float(component['weight'])
            if('posInfo' in list(component.keys())):
                if(component['posInfo']==None):
                    del sameDayTrading_aggregate_benchmark_components_structure_copy['posInfo']
                else:
                    sameDayTrading_aggregate_benchmark_components_structure_copy['posInfo']=component['posInfo']['sleeveId']
            else:
                del sameDayTrading_aggregate_benchmark_components_structure_copy['posInfo']
            temp_components.append(sameDayTrading_aggregate_benchmark_components_structure_copy)
        return temp_components
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_portfolios_positions(positions:list,SDT_body:dict)->list:
    try:
        temp_positions=[]
        for position in positions:
            sameDayTrading_aggregate_portfolios_positions_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_POSITIONS)
            sameDayTrading_aggregate_portfolios_positions_structure_copy['id']=position['id']
            sameDayTrading_aggregate_portfolios_positions_structure_copy['identifiers']['clientId']=position['identifiers']['clientId']
            sameDayTrading_aggregate_portfolios_positions_structure_copy['quantity']=float(position['quantity'])
            sameDayTrading_aggregate_portfolios_positions_structure_copy['marketValue']=float(position['marketValue'])
            sameDayTrading_aggregate_portfolios_positions_structure_copy['notionalMarketValue']=float(position['notionalMarketValue'])
            if('posInfo' in list(position.keys())):
                if('SLEEVE_ID'in list(position['posInfo'].keys())):
                    sameDayTrading_aggregate_portfolios_positions_structure_copy['posInfo']['SLEEVE_ID']=position["posInfo"]["SLEEVE_ID"]
                else:
                    del sameDayTrading_aggregate_portfolios_positions_structure_copy['posInfo']['SLEEVE_ID']
                if('POSITION_LOCK'in list(position['posInfo'].keys())):
                    sameDayTrading_aggregate_portfolios_positions_structure_copy['posInfo']['POSITION_LOCK']=position["posInfo"]["POSITION_LOCK"]
                else:
                    del sameDayTrading_aggregate_portfolios_positions_structure_copy['posInfo']['POSITION_LOCK']
                if('POSITION_FORCE_SELL'in list(position['posInfo'].keys())):
                    sameDayTrading_aggregate_portfolios_positions_structure_copy['posInfo']['POSITION_FORCE_SELL']=position["posInfo"]["POSITION_FORCE_SELL"]
                else:
                    del sameDayTrading_aggregate_portfolios_positions_structure_copy['posInfo']['POSITION_FORCE_SELL']
            else:
                del position['posInfo']
            temp_positions.append(sameDayTrading_aggregate_portfolios_positions_structure_copy)
        temp_positions.append(Create_cash_position(SDT_body=SDT_body))
        
        return temp_positions
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_cash_position(SDT_body:dict)->dict:
    try:
        sameDayTrading_aggregate_portfolios_positions_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_POSITIONS)
        sameDayTrading_aggregate_portfolios_positions_structure_copy['id']=SDT_body['cashIdentifier']
        sameDayTrading_aggregate_portfolios_positions_structure_copy['identifiers']['clientId']=SDT_body['cashIdentifier']
        sameDayTrading_aggregate_portfolios_positions_structure_copy['quantity']=float(SDT_body['amount'])
        sameDayTrading_aggregate_portfolios_positions_structure_copy['marketValue']=float(SDT_body['amount'])
        sameDayTrading_aggregate_portfolios_positions_structure_copy['notionalMarketValue']=float(SDT_body['amount'])
        del sameDayTrading_aggregate_portfolios_positions_structure_copy['posInfo']
        return sameDayTrading_aggregate_portfolios_positions_structure_copy
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_portfolios_openLots(openLots:list)->list:
    try:
        temp_openLots=[]
        for openLot in openLots:
            sameDayTrading_aggregate_portfolios_openLots_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_OPENLOTS)
            sameDayTrading_aggregate_portfolios_openLots_structure_copy['id']=openLot['id']
            sameDayTrading_aggregate_portfolios_openLots_structure_copy['positionId']=openLot['positionId']
            sameDayTrading_aggregate_portfolios_openLots_structure_copy["purchaseDate"]=openLot['purchaseDate']
            sameDayTrading_aggregate_portfolios_openLots_structure_copy['quantity']=float(openLot['quantity'])
            sameDayTrading_aggregate_portfolios_openLots_structure_copy['costBasis']=float(openLot['costBasis'])
            if('CUSTODIAN_LOT_ID' in list(openLot['lotInfo'].keys())):
                sameDayTrading_aggregate_portfolios_openLots_structure_copy['lotInfo']['CUSTODIAN_LOT_ID']=openLot['lotInfo']['CUSTODIAN_LOT_ID']
            else:
                del sameDayTrading_aggregate_portfolios_openLots_structure_copy['lotInfo']
            temp_openLots.append(sameDayTrading_aggregate_portfolios_openLots_structure_copy)
        return temp_openLots
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_portfolios_closedLots(closedLots:list)->list:
    try:
        temp_closedLots=[]
        for closedLot in closedLots:
            sameDayTrading_aggregate_portfolios_closedLots_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_CLOSEDLOTS)
            sameDayTrading_aggregate_portfolios_closedLots_structure_copy['identifiers']['clientId']=closedLot['identifiers']['clientId']
            sameDayTrading_aggregate_portfolios_closedLots_structure_copy['purchaseDate']=closedLot['purchaseDate']
            sameDayTrading_aggregate_portfolios_closedLots_structure_copy['closedDate']=closedLot['closedDate']
            sameDayTrading_aggregate_portfolios_closedLots_structure_copy['realizedGainOrLoss']=float(closedLot['realizedGainOrLoss'])
            temp_closedLots.append(sameDayTrading_aggregate_portfolios_closedLots_structure_copy)
        return temp_closedLots
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_portfolios_benchmark(portfolio:dict,benchmarks:dict)->dict:
    try:
        sameDayTrading_aggregate_portfolios_benchmark_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_BENCHMARK)
        sameDayTrading_aggregate_portfolios_benchmark_structure_copy['id']=portfolio['benchmarkRef']['id']
        sameDayTrading_aggregate_portfolios_benchmark_structure_copy['currency']=benchmarks['currency']
        sameDayTrading_aggregate_portfolios_benchmark_structure_copy['components']=Create_sameDayTrading_aggregate_portfolios_benchmark_components(components=benchmarks['components'])
        # sameDayTrading_aggregate_portfolios_benchmark_structure_copy['metadata']['Name']=""
        return sameDayTrading_aggregate_portfolios_benchmark_structure_copy
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_portfolios_metadata(metadata:dict)->dict:
    try:
        sameDayTrading_aggregate_portfolios_metadata_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_METADATA)
        metadata_keys=list(metadata.keys())
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['TAX_SENSITIVITY']=metadata['TAX_SENSITIVITY']
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['DISPOSAL_METHOD_MF']=metadata['DISPOSAL_METHOD_MF']
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['DISPOSAL_METHOD_OTHER']=metadata['DISPOSAL_METHOD_OTHER']
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['ACCOUNT_TYPE']=metadata['ACCOUNT_TYPE']
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['LONG_TERM_TAX_RATE']=float(metadata['LONG_TERM_TAX_RATE'])
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['SHORT_TERM_TAX_RATE']=float(metadata['SHORT_TERM_TAX_RATE'])
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['STATE_TAX_RATE']=float(metadata['STATE_TAX_RATE'])
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['ACCOUNT_ID']=metadata['ACCOUNT_ID']
        if('SHORT_TERM_GAIN_BUDGET' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['SHORT_TERM_GAIN_BUDGET']=float(metadata['SHORT_TERM_GAIN_BUDGET'])
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['SHORT_TERM_GAIN_BUDGET']
        if('LONG_TERM_GAIN_BUDGET' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['LONG_TERM_GAIN_BUDGET']=float(metadata['LONG_TERM_GAIN_BUDGET'])
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['LONG_TERM_GAIN_BUDGET']
        if('REALIZED_YTD_STG' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_STG']=float(metadata['REALIZED_YTD_STG'])
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_STG']
        if('REALIZED_YTD_LTG' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_LTG']=float(metadata['REALIZED_YTD_LTG'])
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_LTG']
        if('REALIZED_YTD_STL' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_STL']=float(metadata['REALIZED_YTD_STL'])
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_STL']
        if('REALIZED_YTD_LTL' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_LTL']=float(metadata['REALIZED_YTD_LTL'])
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['REALIZED_YTD_LTL']
        if('SECURITY_NO_BUY' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['SECURITY_NO_BUY']=metadata['SECURITY_NO_BUY']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['SECURITY_NO_BUY']
        if('GICS_NO_HOLD' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['GICS_NO_HOLD']=metadata['GICS_NO_HOLD']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['GICS_NO_HOLD']
        if('GICS_NO_TRADE' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['GICS_NO_TRADE']=metadata['GICS_NO_TRADE']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['GICS_NO_TRADE']
        if('CUSTODIAN_CODE' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['CUSTODIAN_CODE']=metadata['CUSTODIAN_CODE']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['CUSTODIAN_CODE']
        if('CUSTODIAN_ACCOUNT' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['CUSTODIAN_ACCOUNT']=metadata['CUSTODIAN_ACCOUNT']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['CUSTODIAN_ACCOUNT']
        if('MODEL_TYPE' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['MODEL_TYPE']=metadata['MODEL_TYPE']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['MODEL_TYPE']
        if('AGENT_CODE' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['AGENT_CODE']=metadata['AGENT_CODE']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['AGENT_CODE']
        if('AGENT_NAME' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['AGENT_NAME']=metadata['AGENT_NAME']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['AGENT_NAME']
        if('BD_NAME' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['BD_NAME']=metadata['BD_NAME']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['BD_NAME']
        if('REGIONAL_CONSULTANT' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['REGIONAL_CONSULTANT']=metadata['REGIONAL_CONSULTANT']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['REGIONAL_CONSULTANT']
        if('ACCOUNT_REGISTRATION' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['ACCOUNT_REGISTRATION']=metadata['ACCOUNT_REGISTRATION']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['ACCOUNT_REGISTRATION']
        if('SHELL_MODEL_ID' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['SHELL_MODEL_ID']=metadata['SHELL_MODEL_ID']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['SHELL_MODEL_ID']
        if('SETTLED_CASH_BALANCE' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['SETTLED_CASH_BALANCE']=metadata['SETTLED_CASH_BALANCE']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['SETTLED_CASH_BALANCE']
        if('SETTLED_CASH_ONLY' in metadata_keys):
            sameDayTrading_aggregate_portfolios_metadata_structure_copy['SETTLED_CASH_ONLY']=metadata['SETTLED_CASH_ONLY']
        else:
            del sameDayTrading_aggregate_portfolios_metadata_structure_copy['SETTLED_CASH_ONLY']
        sameDayTrading_aggregate_portfolios_metadata_structure_copy['NAME']=metadata['NAME']
        return sameDayTrading_aggregate_portfolios_metadata_structure_copy
    except Exception as e:
        raise CustomException(e,sys)
    
def Create_sameDayTrading_aggregate_portfolios_benchmark_components(components:list)->list:
    try:
        temp_components=[]
        for component in components:
            sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy=copy.deepcopy(sameDayTrading_structure.SAMEDAYTRADING_AGGREGATE_PORTFOLIOS_BENCHMARK_COMPONENTS)
            sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy['id']=component['id']
            sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy['identifiers']['clientId']=component['identifiers']['clientId']
            sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy['weight']=float(component['weight'])
            if('posInfo' in list(component.keys())):
                if(component['posInfo']==None):
                    del sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy['posInfo']
                else:
                    sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy['posInfo']=component['posInfo']['sleeveId']
            else:
                del sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy['posInfo']
            temp_components.append(sameDayTrading_aggregate_portfolios_benchmark_components_structure_copy)
        return temp_components
    except Exception as e:
        raise CustomException(e,sys)