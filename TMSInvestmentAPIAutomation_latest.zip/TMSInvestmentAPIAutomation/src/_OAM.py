# from .._Portfolios import 
import sys,copy
sys.path.insert(1, r'Framework\Utils')
import copy
# from  import _API
from ConfigScripts import _Config,_Configurations,temp_input
from _Logger import logging
from _Exception import CustomException
import _API

# sys.path.insert(2, r'TMSInvestmentAPIAutomation\src\ConfigScripts')
# import _Config,_Configurations,temp_input
import json
import pandas as pd
from datetime import datetime, timedelta
from ConfigScripts import _SessionConfig as configfile
import requests
import json
import _BusinessObject,_Benchmark
import _API,_PublishFile
publish_file = _PublishFile.Publish_File()
#class objects
Api = _API.Api()


def create_oam_json_structure(account_id,portfolio_data):
    try:
        logging.info("Started OAM json structure")
        oam_json_dict = {}
        oam_json_dict['reason']=temp_input.oam_reason
        oam_json_dict['aggregate']=create_oam_aggregate(account_id,portfolio_data)
        return oam_json_dict
    except Exception as e:
        raise CustomException(e,sys)

def create_oam_aggregate(account_id,portfolio_data):
    try:
        logging.info("Started OAM aggregate function")
        aggregate_json = {}
        aggregate_json_portfolio_list = []
        aggregate_json['id']=portfolio_data['id']
        aggregate_json['tag']=temp_input.oam_tag
        aggregate_json['currency']=temp_input.oam_currency
        aggregate_json['benchmark']= _Benchmark.Benchmark_Json()
        aggregate_json['portfolios'] = []
        oam_dictt = create_oam_portfolios(account_id,portfolio_data,aggregate_json['benchmark'])
        # print(d)
        aggregate_json['portfolios'].append(oam_dictt)
        # aggregate_json['metadata']=create_oam_metadata(setting)
        return aggregate_json
    except Exception as e:
        raise CustomException(e,sys)


def create_oam_portfolios(account_id,portfolio_data,benchmark):
    try:
        logging.info("Started OAM portfolios function")
        portfolio_postions_list = []
        portfolio_openlots_list = []
        portfolio_json_list = []
        portfolio_json = {}
        metadata_json = {}
        portfolio_json['id'] = account_id
        portfolio_json['currency'] = temp_input.oam_currency
        portfolio_json['positions'] = portfolio_postions_list
        portfolio_json['openLots'] = portfolio_openlots_list
        portfolio_json['benchmark'] =benchmark
        portfolio_json['metadata'] = metadata_json
        
        metadata_json["DISPOSAL_METHOD_MF"]= portfolio_data['metadata']['DISPOSAL_METHOD_MF']
        metadata_json['ACCOUNT_TYPE']= portfolio_data['metadata']['ACCOUNT_TYPE']
        metadata_json['LONG_TERM_TAX_RATE']= float(portfolio_data['metadata']['LONG_TERM_TAX_RATE'])
        metadata_json['SHORT_TERM_TAX_RATE']= float(portfolio_data['metadata']['SHORT_TERM_TAX_RATE'])
        metadata_json['STATE_TAX_RATE']= float(portfolio_data['metadata']['STATE_TAX_RATE'])

        oam_portfolio_positions = portfolio_data['positions']
        oam_portfolio_openLots = portfolio_data['openLots']
    
        for single_position in oam_portfolio_positions:
            positions_dictt = {}
            positions_dictt['id'] = single_position['id']
            positions_dictt['identifiers']={}
            positions_dictt['posInfo'] = {}
            positions_dictt['identifiers']['clientId'] =  single_position['identifiers']['clientId']
            positions_dictt['identifiers']['cusip'] =  single_position['identifiers']['clientId']
            
            positions_dictt['quantity'] =  single_position['quantity']
            positions_dictt['marketValue'] =  single_position['marketValue']
            positions_dictt['posInfo']['SLEEVE_ID'] =  single_position['posInfo']['SLEEVE_ID']
            portfolio_postions_list.append(positions_dictt)

        for single_openlot in oam_portfolio_openLots:
            openlots_dictt = {}
            openlots_dictt['id'] = single_openlot['id']
            openlots_dictt['positionId'] =  single_openlot['positionId']
            openlots_dictt['purchaseDate'] =  single_openlot['purchaseDate']
            openlots_dictt['quantity'] =  single_openlot['quantity']
            openlots_dictt['costBasis'] =  single_openlot['costBasis']
            portfolio_openlots_list.append(openlots_dictt)
        # print(portfolio_json)
        return portfolio_json
    
    except Exception as e:
        print(e)
        raise CustomException(e,sys)


