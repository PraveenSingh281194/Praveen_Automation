import sys
sys.path.insert(1, r'Framework\Utils')
sys.path.insert(1, r'Framework\Utils')
from datetime import datetime, timedelta
from _Exception import CustomException
from _Logger import logging
import copy
import json
import pandas as pd
from ConfigScripts import _Config, _Configurations, _Input
import _Benchmark
import _BusinessObject
import _API
import _PublishFile
import warnings

warnings.filterwarnings("ignore")
Api = _API.Api()
publish_file = _PublishFile.Publish_File()

env = _Configurations.env


class ProposalStructure:

    PROPOSAL = {
        "reason": "",
        "aggregate": {},
        "parameters": {
            "IGNORE_CORPORATE_ACTION": True
        }
    }

    PROPOSAL_AGGREGATE = {
        "id": "",
        "tag": "AGGREGATE",
        "currency": "USD",
        "benchmark": {},
        "portfolios": []
    }

    PROPOSAL_AGGREGATE_PORTFOLIOS = {
        "id": "",
        "currency": "USD",
        "positions": [],
        "openLots": [],
        "benchmark": [],
        "metadata": {}
    }

    PROPOSAL_AGGREGATE_PORTFOLIOS_POSITIONS = {
        "id": "",
        "identifiers": {
            "cusip": "",
            "clientId": ""
        },
        "proxyIdentifiers": {
            "clientId": ""
        },
        "quantity": "",
        "marketValue": "",
        "posInfo": {
            "POSITION_LOCK": "",
            "POSITION_FORCE_SELL": ""
        }
    }

    PROPOSAL_AGGREGATE_PORTFOLIOS_OPENLOTS = {
        "id": "",
        "positionId": "",
        "purchaseDate": "",
        "quantity": "",
        "costBasis": ""
    }

    PROPOSAL_AGGREGATE_PORTFOLIOS_METADATA = {
        "TAX_SENSITIVITY": "",
        "DISPOSAL_METHOD_MF": "",
        "ACCOUNT_TYPE": "taxable",
        "LONG_TERM_TAX_RATE": "",
        "SHORT_TERM_TAX_RATE": "",
        "STATE_TAX_RATE": "",
        "SHORT_TERM_GAIN_BUDGET": "",
        "LONG_TERM_GAIN_BUDGET": "",
        "REALIZED_YTD_STG": "",
        "REALIZED_YTD_LTG": "",
        "REALIZED_YTD_STL": "",
        "REALIZED_YTD_LTL": "",
        "SECURITY_NO_BUY": "",
        "GICS_NO_HOLD": ""
    }

###############################################################################################################

proposal_structure = ProposalStructure()

####################################################################################################################

def Create_Proposal(account_id: str, settings: dict, holdings: dict, tax_sensitivity: str, input_proposal_body: dict) -> dict:    
    try:
        logging.info('started creating Proposal')
        proposal_copy: dict = copy.deepcopy(proposal_structure.PROPOSAL)
        tax_sensitivity_valid: list = ['very_high', 'high', 'medium', 'low', ]
        if(tax_sensitivity.lower() in tax_sensitivity_valid):
            proposal_copy["reason"] = "DAILY_OPTIMIZATION"
        elif(tax_sensitivity == 'TRADE_TO_MODEL'):
            proposal_copy["reason"] = "TRADE_TO_MODEL"
        proposal_copy["aggregate"]: dict = Create_Proposal_Aggregate(
            account_id=account_id,
            settings=settings,
            holdings=holdings,
            tax_sensitivity=tax_sensitivity,
            input_proposal_body= input_proposal_body
        )
        logging.info('Created Proposal')
        return proposal_copy
    except Exception as e:
        raise CustomException(e, sys)


def Create_Proposal_Aggregate(account_id: str, settings: dict, holdings: dict,tax_sensitivity:str, input_proposal_body: dict) -> dict:
    try:
        logging.info('started creating Proposal_Aggregate')
        proposal_aggregate_copy = copy.deepcopy(
            proposal_structure.PROPOSAL_AGGREGATE)
        proposal_aggregate_copy['id']: str = account_id
        proposal_aggregate_copy['benchmark']: dict = _Benchmark.Benchmark_Json(
        )
        logging.info('Created benchamrk inside Proposal_Aggregate')
        proposal_aggregate_copy['portfolios'].append(Create_Proposal_Aggregate_Portfolios(
            settings=settings,
            holdings=holdings,
            tax_sensitivity=tax_sensitivity,
            benchmark=proposal_aggregate_copy['benchmark'],
            input_proposal_body= input_proposal_body))
        logging.info('Created Proposal_Aggregate')
        return proposal_aggregate_copy
    except Exception as e:
        raise CustomException(e, sys)


def Create_Proposal_Aggregate_Portfolios(settings: dict, holdings: dict, benchmark: dict,tax_sensitivity:str, input_proposal_body:dict) -> dict:
    try:
        logging.info('Started creating Aggregate_Portfolios')
        account_id: str = settings['accountId']
        proposal_aggregate_portfolios_copy = copy.deepcopy(
            proposal_structure.PROPOSAL_AGGREGATE_PORTFOLIOS)
        proposal_aggregate_portfolios_copy['id']: str = account_id
        proposal_aggregate_portfolios_copy['currency']: str = "USD"
        proposal_aggregate_portfolios_copy['positions'] = Create_Proposal_Aggregate_Portfolios_Positions(
            holding=holdings,
            settings=settings,
            structure=proposal_structure.PROPOSAL_AGGREGATE_PORTFOLIOS_POSITIONS
        )
        proposal_aggregate_portfolios_copy["openLots"]: dict = Create_Proposal_Aggregate_Portfolios_OpenLots(
            holdings=holdings,
            structure=proposal_structure.PROPOSAL_AGGREGATE_PORTFOLIOS_OPENLOTS
        )
        proposal_aggregate_portfolios_copy["benchmark"]: dict = benchmark
        logging.info('Created benchamrk inside Proposal_Aggregate_Portfolios')
        proposal_aggregate_portfolios_copy["metadata"] = Create_Proposal_Aggregate_Portfolios_Metadata(
            settings=settings,
            holdings=holdings,
            tax_sensitivity=tax_sensitivity,
            input_proposal_body= input_proposal_body
        )
        logging.info('created Aggregate_Portfolios')
        return proposal_aggregate_portfolios_copy
    except Exception as e:
        raise CustomException(e, sys)

# create opentaxlots
def Create_Proposal_Aggregate_Portfolios_OpenLots(holdings: dict, structure: dict) -> dict:
    try:
        logging.info(
            'Started Creating Proposal_Aggregate_Portfolios_OpenTaxLots')
        portfolios_openlots = []
        for index, holding in enumerate(holdings):
            # if(holding['securityIdentifier'] != '678335ZR'):
            if(holding['isCash'] != True):
                portfolios_openlots_dict_copy = copy.deepcopy(structure)
                portfolios_openlots_dict_copy['id']: str = str(index+1)
                portfolios_openlots_dict_copy['positionId']: str = holding['securityIdentifier']
                if(holding['term'] == 'ShortTerm'):
                    portfolios_openlots_dict_copy['purchaseDate']: str = datetime.strftime(
                        datetime.now() - timedelta(1), '%Y-%m-%d')
                elif(holding['term'] == 'LongTerm'):
                    portfolios_openlots_dict_copy['purchaseDate']: str = datetime.strftime(
                        datetime.now() - timedelta(3660), '%Y-%m-%d')
                elif(holding['term'] == None):
                    portfolios_openlots_dict_copy['purchaseDate']: str = holding['purchaseDate'].split('T')[
                        0]
                portfolios_openlots_dict_copy['quantity']: float = float(holding['quantity'])
                portfolios_openlots_dict_copy['costBasis']: float = float(holding['costBasis'])

                # portfolios_openlots_dict_copy['purchaseDate'] = datetime.strptime(ele['purchaseDate'].split('T')[0].replace('-','/'),'%Y/%m/%d')
                # temp = type(datetime.strptime(ele['purchaseDate'].split('T')[0].replace('-','/'),'%Y/%m/%d'))

                portfolios_openlots.append(portfolios_openlots_dict_copy)
        logging.info('created Proposal_Aggregate_Portfolios_OpenTaxLots')
        return portfolios_openlots
    except Exception as e:
        raise CustomException(e, sys)

# create positions
def Create_Proposal_Aggregate_Portfolios_Positions(holding: dict, settings: dict, structure: dict) -> dict:
    try:
        logging.info(
            'Started creating Proposal_Aggregate_Portfolios_Positions')
        portfolios_positions = []
        # create holding df
        holding_df = pd.DataFrame(holding)
        holdings_list = list(holding_df.groupby('securityIdentifier',sort=False))
        true_exisits = True in list(holding_df['isCash'])               ##True or False
        
        cash_restrcition =settings['data']['cashRestriction']               ##None or dictioary 

        if true_exisits ==False:
            if cash_restrcition ==None:
                for holding in  holdings_list:
                    portfolios_positions_dict_copy = copy.deepcopy(structure)
                    portfolios_positions_dict_copy['id'] = holding[0]
                    portfolios_positions_dict_copy['identifiers']['cusip'] = holding[0]
                    portfolios_positions_dict_copy['identifiers']['clientId'] = holding[0]
                    portfolios_positions_dict_copy['proxyIdentifiers']['clientId'] = holding[1]['proxySecurityIdentifier'].to_list()[
                0]
                    portfolios_positions_dict_copy['quantity'] = float(
                        holding[1]['quantity'].sum())
                    portfolios_positions_dict_copy['marketValue'] = float(
                        holding[1]['currentMarketValue'].sum())
                    if(len(settings['data']['securityRestrictions'])>0):
                        positions_posinfo = Create_Proposal_Aggregate_Portfolios_Positions_Posinfo(
                            settings=settings, securityIdentifier=holding[0])
                        if(positions_posinfo != 0):
                            portfolios_positions_dict_copy['posInfo'] = positions_posinfo
                        else:
                            del portfolios_positions_dict_copy['posInfo']
                    else:
                        del portfolios_positions_dict_copy['posInfo']
                    portfolios_positions.append(portfolios_positions_dict_copy)
            else:
                for holding in  holdings_list:
                    portfolios_positions_dict_copy = copy.deepcopy(structure)
                    portfolios_positions_dict_copy['id'] = holding[0]
                    portfolios_positions_dict_copy['identifiers']['cusip'] = holding[0]
                    portfolios_positions_dict_copy['identifiers']['clientId'] = holding[0]
                    portfolios_positions_dict_copy['proxyIdentifiers']['clientId'] = holding[1]['proxySecurityIdentifier'].to_list()[
                0]
                    portfolios_positions_dict_copy['quantity'] = float(
                        holding[1]['quantity'].sum())
                    portfolios_positions_dict_copy['marketValue'] = float(
                        holding[1]['currentMarketValue'].sum())
                    if(len(settings['data']['securityRestrictions'])>0):
                        positions_posinfo = Create_Proposal_Aggregate_Portfolios_Positions_Posinfo(
                            settings=settings, securityIdentifier=holding[0])
                        if(positions_posinfo != 0):
                            portfolios_positions_dict_copy['posInfo'] = positions_posinfo
                        else:
                            del portfolios_positions_dict_copy['posInfo']
                    else:
                        del portfolios_positions_dict_copy['posInfo']
                    portfolios_positions.append(portfolios_positions_dict_copy)
                portfolios_positions.append(Create_Cash_Position(
                            holding=holding, settings=settings, structure=structure))
        else:
            if cash_restrcition==None:
                for holding in  holdings_list:
                    portfolios_positions_dict_copy = copy.deepcopy(structure)
                    portfolios_positions_dict_copy['id'] = holding[0]
                    portfolios_positions_dict_copy['identifiers']['cusip'] = holding[0]
                    portfolios_positions_dict_copy['identifiers']['clientId'] = holding[0]
                    portfolios_positions_dict_copy['proxyIdentifiers']['clientId'] = holding[1]['proxySecurityIdentifier'].to_list()[
                0]
                    portfolios_positions_dict_copy['quantity'] = float(
                        holding[1]['quantity'].sum())
                    portfolios_positions_dict_copy['marketValue'] = float(
                        holding[1]['currentMarketValue'].sum())
                    if(len(settings['data']['securityRestrictions'])>0):
                        positions_posinfo = Create_Proposal_Aggregate_Portfolios_Positions_Posinfo(
                            settings=settings, securityIdentifier=holding[0])
                        if(positions_posinfo != 0):
                            portfolios_positions_dict_copy['posInfo'] = positions_posinfo
                        else:
                            del portfolios_positions_dict_copy['posInfo']
                    else:
                        del portfolios_positions_dict_copy['posInfo']
                    portfolios_positions.append(portfolios_positions_dict_copy)
            else:
                for holding in  holdings_list:
                    portfolios_positions_dict_copy = copy.deepcopy(structure)
                    dummy_df = pd.DataFrame(holding[1]['isCash'])
                    dummy_df = dummy_df['isCash'].reset_index(drop=True)

                    if(False in list(holding[1]['isCash'])):
                        portfolios_positions_dict_copy['id'] = holding[0]
                        portfolios_positions_dict_copy['identifiers']['cusip'] = holding[0]
                        portfolios_positions_dict_copy['identifiers']['clientId'] = holding[0]
                        portfolios_positions_dict_copy['proxyIdentifiers']['clientId'] = holding[1]['proxySecurityIdentifier'].to_list()[
                0]
                        portfolios_positions_dict_copy['quantity'] = float(
                            holding[1]['quantity'].sum())
                        portfolios_positions_dict_copy['marketValue'] = float(
                            holding[1]['currentMarketValue'].sum())
                    else:
                        portfolios_positions_dict_copy['id'] = holding[0]
                        portfolios_positions_dict_copy['identifiers']['cusip'] = holding[0]
                        portfolios_positions_dict_copy['identifiers']['clientId'] = holding[0]
                        portfolios_positions_dict_copy['proxyIdentifiers']['clientId'] = holding[1]['proxySecurityIdentifier'].to_list()[
                0]
                        cashRestrictionAmount = float(settings["data"]['cashRestriction']['cashRestrictionAmount'])
                        portfolios_positions_dict_copy['quantity'] = float(
                            holding[1]['quantity'].sum())-cashRestrictionAmount
                        portfolios_positions_dict_copy['marketValue'] = float(
                            holding[1]['currentMarketValue'].sum())-cashRestrictionAmount
                    if(len(settings['data']['securityRestrictions'])>0):
                        positions_posinfo = Create_Proposal_Aggregate_Portfolios_Positions_Posinfo(
                            settings=settings, securityIdentifier=holding[0])
                        if(positions_posinfo != 0):
                            portfolios_positions_dict_copy['posInfo'] = positions_posinfo
                        else:
                            del portfolios_positions_dict_copy['posInfo']
                    else:
                        del portfolios_positions_dict_copy['posInfo']
                    portfolios_positions.append(portfolios_positions_dict_copy)

        logging.info('Created Proposal_Aggregate_Portfolios_Positions')
        return portfolios_positions  # This will return the value of the portfolios
    except Exception as e:
        raise CustomException(e, sys)


def Create_Cash_Position(holding: tuple, settings: dict, structure: dict) -> dict:
    try:
        logging.info(
            'Started creating Non-Cash Postion inside Proposal_Aggregate_Portfolios_Positions')
        cash_position_structure = copy.deepcopy(structure)
        cash_position_structure['id'] = settings['data']['cashRestriction']['cusip']
        # if(holding[0] == '678335ZR'):
        #     non_cash_position_structure['identifiers']['cusip'] = holding[0]
        #     non_cash_position_structure['identifiers']['clientId'] = 'CASH-1'
        # elif(holding[0] != '678335ZR'):
        cash_position_structure['identifiers']['cusip'] = settings['data']['cashRestriction']['cusip']
        cash_position_structure['identifiers']['clientId'] = settings['data']['cashRestriction']['cusip']
        cash_position_structure['proxyIdentifiers']['clientId'] = settings['data']['cashRestriction']['cusip']
        cashRestrictionAmount = settings["data"]['cashRestriction']['cashRestrictionAmount']
        cash_position_structure['quantity'] = 0-cashRestrictionAmount
        cash_position_structure['marketValue'] = 0-cashRestrictionAmount
        # positions_posinfo = Create_Proposal_Aggregate_Portfolios_Positions_Posinfo(
        #     settings=settings, securityIdentifier=holding[0])
        # if(positions_posinfo != 0):
        #     cash_position_structure['posInfo'] = positions_posinfo
        # else:
        del cash_position_structure['posInfo']
        logging.info(
            'Created Non-Cash Postion inside Proposal_Aggregate_Portfolios_Positions')
        return cash_position_structure
    except Exception as e:
        raise CustomException(e, sys)


def Create_Proposal_Aggregate_Portfolios_Metadata(settings: dict, holdings: dict, tax_sensitivity: str, input_proposal_body: dict) -> dict:
    try:
        logging.info('Started Creating Proposal_Aggregate_Portfolios_Metadata')
        metadata_copy = copy.deepcopy(
            proposal_structure.PROPOSAL_AGGREGATE_PORTFOLIOS_METADATA)
        # for now taking input from
        mfDisposalMethod_valid_values = {
            'SpecificLot': 'specific_lot', 'AverageCost': 'average_cost', 'Fifo': 'fifo'}
        if(tax_sensitivity == 'TRADE_TO_MODEL'):
            del metadata_copy["TAX_SENSITIVITY"]
        else:
            metadata_copy["TAX_SENSITIVITY"] = tax_sensitivity
        metadata_copy['DISPOSAL_METHOD_MF'] = mfDisposalMethod_valid_values[input_proposal_body['mutualFundDisposalMethod']]
        metadata_copy["LONG_TERM_TAX_RATE"] = float(settings['data']['federalLongTermTaxRate'])
        metadata_copy["SHORT_TERM_TAX_RATE"] = float(settings['data']['federalShortTermTaxRate'])
        metadata_copy["STATE_TAX_RATE"] = float(settings['data']['stateTaxRate'])
        if(settings['data']["shortTermRealizedGainBudgetAmount"]==None):
            del metadata_copy["SHORT_TERM_GAIN_BUDGET"]
        else:
            metadata_copy["SHORT_TERM_GAIN_BUDGET"] = float(settings['data']['shortTermRealizedGainBudgetAmount'])
        if(settings['data']['longTermRealizedGainBudgetAmount'] ==None):
            del metadata_copy["LONG_TERM_GAIN_BUDGET"]
        else:
            metadata_copy["LONG_TERM_GAIN_BUDGET"] = float(settings['data']['longTermRealizedGainBudgetAmount'])
        if(settings['data']['yearToDateShortTermRealizedGainLoss']==None):
            del metadata_copy["REALIZED_YTD_STG"]
            del metadata_copy["REALIZED_YTD_STL"]
        else:
            if(settings['data']['yearToDateShortTermRealizedGainLoss'] > 0):
                metadata_copy["REALIZED_YTD_STG"] = float(settings['data']['yearToDateShortTermRealizedGainLoss'])
                metadata_copy["REALIZED_YTD_STL"] = float(0)
            if(settings['data']['yearToDateShortTermRealizedGainLoss'] < 0):
                metadata_copy["REALIZED_YTD_STL"] = float(settings['data']['yearToDateShortTermRealizedGainLoss'])
                metadata_copy["REALIZED_YTD_STG"] = float(0)
        if(settings['data']['yearToDateLongTermRealizedGainLoss'] ==None):
            del metadata_copy["REALIZED_YTD_LTL"]
            del metadata_copy["REALIZED_YTD_LTG"]
        else:
            if(settings['data']['yearToDateLongTermRealizedGainLoss'] > 0):
                metadata_copy["REALIZED_YTD_LTG"] = float(settings['data']['yearToDateLongTermRealizedGainLoss'])
                metadata_copy["REALIZED_YTD_LTL"] = float(0)
            if(settings['data']['yearToDateLongTermRealizedGainLoss'] < 0):
                metadata_copy["REALIZED_YTD_LTL"] = float(settings['data']['yearToDateLongTermRealizedGainLoss'])
                metadata_copy["REALIZED_YTD_LTG"] = float(0)
        if(len(settings['data']['sectorRestrictions']) > 0):
            metadata_copy["GICS_NO_HOLD"] = Create_Proposal_Aggregate_Portfolios_Metadata_GicsNoHold(
                sector_restrictions=settings['data']['sectorRestrictions'])
        else:
            del metadata_copy["GICS_NO_HOLD"]
        if(len(settings['data']['securityRestrictions']) > 0):
            # if(holdings)
            metadata_copy["SECURITY_NO_BUY"] = Create_Proposal_Aggregate_Portfolios_Metadata_SecurityNoBuy(security_restrictions=settings['data']['securityRestrictions'],holdings=holdings)
            if(metadata_copy["SECURITY_NO_BUY"]==0):
                del metadata_copy["SECURITY_NO_BUY"]
        else:
            del metadata_copy["SECURITY_NO_BUY"]
        # return json.dumps(metadata_copy,indent=2)
        logging.info('Created Proposal_Aggregate_Portfolios_Metadata')
        return metadata_copy
    except Exception as e:
        raise CustomException(e, sys)


def Create_Proposal_Aggregate_Portfolios_Positions_Posinfo(settings: dict, securityIdentifier: str) -> dict:
    try:
        logging.info(
            'Started Creating Proposal_Aggregate_Portfolios_Positions_Posinfo')
        portfolios_positions_posinfo = {
            "POSITION_LOCK": "",
            "POSITION_FORCE_SELL": ""
        }
        if settings['data']['securityRestrictions'] != []:
            for ele in settings['data']['securityRestrictions']:
                portfolios_positions_posinfo_copy = copy.deepcopy(
                    portfolios_positions_posinfo)
                if(ele['cusip'] == securityIdentifier):
                    # if(ele['securityRestrictionType'] == 'DoNotBuy'):
                    #     portfolios_positions_posinfo_copy["POSITION_LOCK"] = 'do_not_buy'
                    #     portfolios_positions_posinfo_copy["POSITION_FORCE_SELL"] = 'force_sell'
                    # elif(ele['securityRestrictionType'] == 'DoNotSell'):
                    #     portfolios_positions_posinfo_copy["POSITION_LOCK"] = 'do_not_sell'
                    # elif(ele['securityRestrictionType'] == 'DoNotTrade'):
                    #     portfolios_positions_posinfo_copy["POSITION_LOCK"] = 'full'
                    # elif(ele['securityRestrictionType'] == 'DoNotHold'):
                    #     portfolios_positions_posinfo_copy["POSITION_LOCK"] = 'do_not_buy'
                    if(ele['securityRestrictionType'] == 'SellAllExisting'):
                        portfolios_positions_posinfo_copy["POSITION_LOCK"] = 'do_not_buy'
                        portfolios_positions_posinfo_copy["POSITION_FORCE_SELL"] = 'force_sell'
                    if(ele['securityRestrictionType'] == 'DoNotSell'):
                        portfolios_positions_posinfo_copy["POSITION_LOCK"] = 'full'
                        del portfolios_positions_posinfo_copy["POSITION_FORCE_SELL"]
                    break
                else:
                    portfolios_positions_posinfo_copy = 0           # 0-> not applicable
        else:
            portfolios_positions_posinfo_copy = 0           # 0-> not applicable
        logging.info('Created Proposal_Aggregate_Portfolios_Positions_Posinfo')
        return portfolios_positions_posinfo_copy
    except Exception as e:
        raise CustomException(e, sys)


def Create_Proposal_Aggregate_Portfolios_Metadata_SecurityNoBuy(security_restrictions: list,holdings) -> str:
    try:
        logging.info(
            'Started Creating Proposal_Aggregate_Portfolios_Metadata_SecurityNoBuy')
        security_no_buy = ''
        for securityRestriction in security_restrictions:
            if(securityRestriction['cusip'] not in pd.DataFrame(holdings)['securityIdentifier'].values.tolist()):
                if(securityRestriction['securityRestrictionType'] == 'SellAllExisting'):
                    security_no_buy = security_no_buy + \
                        securityRestriction['cusip']+'|'
        if(security_no_buy==''):
            return 0
        else:
            security_no_buy = security_no_buy[:-1]
            logging.info(
                'Created Proposal_Aggregate_Portfolios_Metadata_SecurityNoBuy')
            return security_no_buy
    except Exception as e:
        raise CustomException(e, sys)


def Create_Proposal_Aggregate_Portfolios_Metadata_GicsNoHold(sector_restrictions: list) -> str:
    try:
        logging.info(
            'Started Creating Proposal_Aggregate_Portfolios_Metadata_GicsNoHold')
        gics_no_hold = ''
        for sectorRestriction in sector_restrictions:
            gics_no_hold = gics_no_hold + \
                sectorRestriction['gicsSubIndustryCode']+'|'
        gics_no_hold = gics_no_hold[:-1]
        logging.info(
            'Created Proposal_Aggregate_Portfolios_Metadata_GicsNoHold')
        return gics_no_hold
    except Exception as e:
        raise CustomException(e, sys)

#########################################################################################################################################