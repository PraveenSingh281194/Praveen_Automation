import json,os
import warnings

warnings.filterwarnings("ignore")

cur_path = os.path.dirname(__file__)
file_path = "src\Config\_Config.json"

with open(file_path, 'r') as f:
    data = f.read()
    properties = json.loads(data)
    json_variables = {
        "Test10":{
            "'okta_token'" : {
                "'url'" : properties['API_COLLECTION']['Test10']['POST']['OKTA_TOKEN']['URL'],
                "'username'" : properties['API_COLLECTION']['Test10']['POST']['OKTA_TOKEN']['AUTH']['API_USERNAME'],
                "'password'" : properties['API_COLLECTION']['Test10']['POST']['OKTA_TOKEN']['AUTH']['API_PASSWORD'],
                "'header'" : properties['API_COLLECTION']['Test10']['POST']['OKTA_TOKEN']['HEADER'],
                "'payload'" : properties['API_COLLECTION']['Test10']['POST']['OKTA_TOKEN']['PAYLOAD']
            },

            "'add_setting'":{
                "'url'":properties['API_COLLECTION']['Test10']['POST']['ADD_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['POST']['ADD_SETTING']['HEADER'],
            },

            "'add_holding'":{
                "'url'":properties['API_COLLECTION']['Test10']['POST']['ADD_HOLDING']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['POST']['ADD_HOLDING']['HEADER'],
            },

            "'approve_setting'":{
                "'url'":properties['API_COLLECTION']['Test10']['POST']['APPROVE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['POST']['APPROVE_SETTING']['HEADER'],
            },

            "'expire_setting'":{
                "'url'":properties['API_COLLECTION']['Test10']['POST']['EXPIRE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['POST']['EXPIRE_SETTING']['HEADER'],
            },

            "'get_setting_by_setting_id'":{
                "'url'":properties['API_COLLECTION']['Test10']['GET']['GET_SETTING_BY_SETTING_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['GET']['GET_SETTING_BY_SETTING_ID']['HEADER']
            },

            "'get_setting_by_status'":{
                "'url'":properties['API_COLLECTION']['Test10']['GET']['GET_SETTING_BY_STATUS']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['GET']['GET_SETTING_BY_STATUS']['HEADER'],
            },

            "'get_setting_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Test10']['GET']['GET_SETTING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['GET']['GET_SETTING_BY_ACCOUNT_ID']['HEADER'],
            },

            "'get_holding_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Test10']['GET']['GET_HOLDING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['GET']['GET_HOLDING_BY_ACCOUNT_ID']['HEADER']
            },

            "'generate_proposal'":{
                "'url'":properties['API_COLLECTION']['Test10']['POST']['GENERATE_PROPOSAL']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['POST']['GENERATE_PROPOSAL']['HEADER']
            },

            "'get_trade_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Test10']['GET']['GET_TRADE_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['GET']['GET_TRADE_BY_GUID']['HEADER']
            },
            "'get_proxy_proposal_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Test10']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Test10']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['HEADER']
            }


        },

        "Test11":{
            "'okta_token'" : {
                "'url'" : properties['API_COLLECTION']['Test11']['POST']['OKTA_TOKEN']['URL'],
                "'username'" : properties['API_COLLECTION']['Test11']['POST']['OKTA_TOKEN']['AUTH']['API_USERNAME'],
                "'password'" : properties['API_COLLECTION']['Test11']['POST']['OKTA_TOKEN']['AUTH']['API_PASSWORD'],
                "'header'" : properties['API_COLLECTION']['Test11']['POST']['OKTA_TOKEN']['HEADER'],
                "'payload'" : properties['API_COLLECTION']['Test11']['POST']['OKTA_TOKEN']['PAYLOAD']
            },

            "'add_setting'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['ADD_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['ADD_SETTING']['HEADER'],
            },

            "'add_holding'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['ADD_HOLDING']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['ADD_HOLDING']['HEADER'],
            },

            "'approve_setting'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['APPROVE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['APPROVE_SETTING']['HEADER'],
            },

            "'expire_setting'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['EXPIRE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['EXPIRE_SETTING']['HEADER'],
            },

            "'get_setting_by_setting_id'":{
                "'url'":properties['API_COLLECTION']['Test11']['GET']['GET_SETTING_BY_SETTING_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['GET']['GET_SETTING_BY_SETTING_ID']['HEADER']
            },
            "'get_holding_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Test11']['GET']['GET_HOLDING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['GET']['GET_HOLDING_BY_ACCOUNT_ID']['HEADER']
            },

            "'get_setting_by_status'":{
                "'url'":properties['API_COLLECTION']['Test11']['GET']['GET_SETTING_BY_STATUS']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['GET']['GET_SETTING_BY_STATUS']['HEADER'],
            },

            "'get_setting_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Test11']['GET']['GET_SETTING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['GET']['GET_SETTING_BY_ACCOUNT_ID']['HEADER'],
            },

            "'generate_proposal'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['GENERATE_PROPOSAL']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['GENERATE_PROPOSAL']['HEADER']
            },

            "'generate_business_object'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['AMK_NAW_TAX_PROPOSAL']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['AMK_NAW_TAX_PROPOSAL']['HEADER']
            },

            "'proxy_generate_proposal'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['PROXY_GENERATE_PROPOSAL']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['PROXY_GENERATE_PROPOSAL']['HEADER']
            },

            "'generate_oam_proxy_url'":{
                "'url'":properties['API_COLLECTION']['Test11']['GET']['GET_OAM_BLACKROCK_PROXY']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['GET']['GET_OAM_BLACKROCK_PROXY']['HEADER']
            },

            "'removal_impact'":{
                "'url'":properties['API_COLLECTION']['Test11']['POST']['REMOVAL_IMPACT']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['POST']['REMOVAL_IMPACT']['HEADER']
            },

            "'get_trade_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Test11']['GET']['GET_TRADE_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Test11']['GET']['GET_TRADE_BY_GUID']['HEADER']
            },

            "'get_proxy_proposal_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Test12']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['HEADER']
            }



        },

        "Test12":{
            "'okta_token'" : {
                "'url'" : properties['API_COLLECTION']['Test12']['POST']['OKTA_TOKEN']['URL'],
                "'username'" : properties['API_COLLECTION']['Test12']['POST']['OKTA_TOKEN']['AUTH']['API_USERNAME'],
                "'password'" : properties['API_COLLECTION']['Test12']['POST']['OKTA_TOKEN']['AUTH']['API_PASSWORD'],
                "'header'" : properties['API_COLLECTION']['Test12']['POST']['OKTA_TOKEN']['HEADER'],
                "'payload'" : properties['API_COLLECTION']['Test12']['POST']['OKTA_TOKEN']['PAYLOAD']
            },

            "'add_setting'":{
                "'url'":properties['API_COLLECTION']['Test12']['POST']['ADD_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['POST']['ADD_SETTING']['HEADER'],
            },

            "'add_holding'":{
                "'url'":properties['API_COLLECTION']['Test12']['POST']['ADD_HOLDING']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['POST']['ADD_HOLDING']['HEADER'],
            },

            "'approve_setting'":{
                "'url'":properties['API_COLLECTION']['Test12']['POST']['APPROVE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['POST']['APPROVE_SETTING']['HEADER'],
            },

            "'expire_setting'":{
                "'url'":properties['API_COLLECTION']['Test12']['POST']['EXPIRE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['POST']['EXPIRE_SETTING']['HEADER'],
            },

            "'get_setting_by_setting_id'":{
                "'url'":properties['API_COLLECTION']['Test12']['GET']['GET_SETTING_BY_SETTING_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['GET']['GET_SETTING_BY_SETTING_ID']['HEADER']
            },

            "'get_setting_by_status'":{
                "'url'":properties['API_COLLECTION']['Test12']['GET']['GET_SETTING_BY_STATUS']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['GET']['GET_SETTING_BY_STATUS']['HEADER'],
            },

            "'get_setting_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Test12']['GET']['GET_SETTING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['GET']['GET_SETTING_BY_ACCOUNT_ID']['HEADER'],
            },

            "'get_trade_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Test12']['GET']['GET_TRADE_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['GET']['GET_TRADE_BY_GUID']['HEADER']
            },

            "'get_proxy_proposal_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Test12']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Test12']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['HEADER']
            }
            

        },

        "Dev11":{
            "'okta_token'" : {
                "'url'" : properties['API_COLLECTION']['Dev11']['POST']['OKTA_TOKEN']['URL'],
                "'username'" : properties['API_COLLECTION']['Dev11']['POST']['OKTA_TOKEN']['AUTH']['API_USERNAME'],
                "'password'" : properties['API_COLLECTION']['Dev11']['POST']['OKTA_TOKEN']['AUTH']['API_PASSWORD'],
                "'header'" : properties['API_COLLECTION']['Dev11']['POST']['OKTA_TOKEN']['HEADER'],
                "'payload'" : properties['API_COLLECTION']['Dev11']['POST']['OKTA_TOKEN']['PAYLOAD']
            },

            "'add_setting'":{
                "'url'":properties['API_COLLECTION']['Dev11']['POST']['ADD_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['POST']['ADD_SETTING']['HEADER'],
            },

            "'add_holding'":{
                "'url'":properties['API_COLLECTION']['Dev11']['POST']['ADD_HOLDING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['POST']['ADD_HOLDING']['HEADER'],
            },

            "'approve_setting'":{
                "'url'":properties['API_COLLECTION']['Dev11']['POST']['APPROVE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['POST']['APPROVE_SETTING']['HEADER'],
            },

            "'expire_setting'":{
                "'url'":properties['API_COLLECTION']['Dev11']['POST']['EXPIRE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['POST']['EXPIRE_SETTING']['HEADER'],
            },

            "'get_setting_by_setting_id'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_SETTING_BY_SETTING_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_SETTING_BY_SETTING_ID']['HEADER']
            },

            "'get_setting_by_status'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_SETTING_BY_STATUS']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_SETTING_BY_STATUS']['HEADER'],
            },

            "'get_setting_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_SETTING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_SETTING_BY_ACCOUNT_ID']['HEADER'],
            },

            "'get_holding_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_HOLDING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_HOLDING_BY_ACCOUNT_ID']['HEADER']
            },

            "'generate_proposal'":{
                "'url'":properties['API_COLLECTION']['Dev11']['POST']['GENERATE_PROPOSAL']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['POST']['GENERATE_PROPOSAL']['HEADER']
            },

            "'get_portfolio_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_PORTFOLIO_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_PORTFOLIO_BY_ACCOUNT_ID']['HEADER']
            },

            "'get_benchmarks_by_reference_id'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_BENCHMARKS_BY_REFERENCE_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_BENCHMARKS_BY_REFERENCE_ID']['HEADER']
            },

            "'proxy_generate_proposal_stateful'":{
                "'url'":properties['API_COLLECTION']['Dev11']['POST']['PROXY_GENERATE_PROPOSAL_STATEFUL']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['POST']['PROXY_GENERATE_PROPOSAL_STATEFUL']['HEADER']
            },

            "'create_withdrawl_trade'":{
                "'url'":properties['API_COLLECTION']['Dev11']['POST']['CREATE_WITHDRAWLTRADE']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['POST']['CREATE_WITHDRAWLTRADE']['HEADER']
            },

            "'get_trade_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_TRADE_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_TRADE_BY_GUID']['HEADER']
            },   

            "'get_proxy_proposal_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Dev11']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev11']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['HEADER']
            }     

        },

        "Dev12":{
            "'okta_token'" : {
                "'url'" : properties['API_COLLECTION']['Dev12']['POST']['OKTA_TOKEN']['URL'],
                "'username'" : properties['API_COLLECTION']['Dev12']['POST']['OKTA_TOKEN']['AUTH']['API_USERNAME'],
                "'password'" : properties['API_COLLECTION']['Dev12']['POST']['OKTA_TOKEN']['AUTH']['API_PASSWORD'],
                "'header'" : properties['API_COLLECTION']['Dev12']['POST']['OKTA_TOKEN']['HEADER'],
                "'payload'" : properties['API_COLLECTION']['Dev12']['POST']['OKTA_TOKEN']['PAYLOAD']
            },

            "'add_setting'":{
                "'url'":properties['API_COLLECTION']['Dev12']['POST']['ADD_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['POST']['ADD_SETTING']['HEADER'],
            },

            "'add_holding'":{
                "'url'":properties['API_COLLECTION']['Dev12']['POST']['ADD_HOLDING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['POST']['ADD_HOLDING']['HEADER'],
            },

            "'approve_setting'":{
                "'url'":properties['API_COLLECTION']['Dev12']['POST']['APPROVE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['POST']['APPROVE_SETTING']['HEADER'],
            },

            "'expire_setting'":{
                "'url'":properties['API_COLLECTION']['Dev12']['POST']['EXPIRE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['POST']['EXPIRE_SETTING']['HEADER'],
            },

            "'get_setting_by_setting_id'":{
                "'url'":properties['API_COLLECTION']['Dev12']['GET']['GET_SETTING_BY_SETTING_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['GET']['GET_SETTING_BY_SETTING_ID']['HEADER']
            },

            "'get_setting_by_status'":{
                "'url'":properties['API_COLLECTION']['Dev12']['GET']['GET_SETTING_BY_STATUS']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['GET']['GET_SETTING_BY_STATUS']['HEADER'],
            },

            "'get_setting_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Dev12']['GET']['GET_SETTING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['GET']['GET_SETTING_BY_ACCOUNT_ID']['HEADER'],
            },

            "'get_trade_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Dev12']['GET']['GET_TRADE_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['GET']['GET_TRADE_BY_GUID']['HEADER']
            },

             "'get_proxy_proposal_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Dev12']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev12']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['HEADER']
            }

        },

        "Dev13":{
            "'okta_token'" : {
                "'url'" : properties['API_COLLECTION']['Dev13']['POST']['OKTA_TOKEN']['URL'],
                "'username'" : properties['API_COLLECTION']['Dev13']['POST']['OKTA_TOKEN']['AUTH']['API_USERNAME'],
                "'password'" : properties['API_COLLECTION']['Dev13']['POST']['OKTA_TOKEN']['AUTH']['API_PASSWORD'],
                "'header'" : properties['API_COLLECTION']['Dev13']['POST']['OKTA_TOKEN']['HEADER'],
                "'payload'" : properties['API_COLLECTION']['Dev13']['POST']['OKTA_TOKEN']['PAYLOAD']
            },

            "'add_setting'":{
                "'url'":properties['API_COLLECTION']['Dev13']['POST']['ADD_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['POST']['ADD_SETTING']['HEADER'],
            },

            "'add_holding'":{
                "'url'":properties['API_COLLECTION']['Dev13']['POST']['ADD_HOLDING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['POST']['ADD_HOLDING']['HEADER'],
            },

            "'approve_setting'":{
                "'url'":properties['API_COLLECTION']['Dev13']['POST']['APPROVE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['POST']['APPROVE_SETTING']['HEADER'],
            },

            "'expire_setting'":{
                "'url'":properties['API_COLLECTION']['Dev13']['POST']['EXPIRE_SETTING']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['POST']['EXPIRE_SETTING']['HEADER'],
            },

            "'get_setting_by_setting_id'":{
                "'url'":properties['API_COLLECTION']['Dev13']['GET']['GET_SETTING_BY_SETTING_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['GET']['GET_SETTING_BY_SETTING_ID']['HEADER']
            },

            "'get_setting_by_status'":{
                "'url'":properties['API_COLLECTION']['Dev13']['GET']['GET_SETTING_BY_STATUS']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['GET']['GET_SETTING_BY_STATUS']['HEADER'],
            },

            "'get_setting_by_account_id'":{
                "'url'":properties['API_COLLECTION']['Dev13']['GET']['GET_SETTING_BY_ACCOUNT_ID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['GET']['GET_SETTING_BY_ACCOUNT_ID']['HEADER'],
            },

            "'get_trade_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Dev13']['GET']['GET_TRADE_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['GET']['GET_TRADE_BY_GUID']['HEADER']
            },

            "'get_proxy_proposal_by_GUID'":{
                "'url'":properties['API_COLLECTION']['Dev13']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['URL'],
                "'header'":properties['API_COLLECTION']['Dev13']['GET']['GET_PROXY_PROPOSAL_BY_GUID']['HEADER']
            }
        }
    }
