import requests,json
import warnings

warnings.filterwarnings("ignore")

session=requests.session()
cookies_jar={}

#change below 3 attributes as per execution requirement
env='test11'
standard_model_name='A'
model_type='standard_model' # 'custom_model'  #



def session_get(url,header=None,payload=None):
    session.get(url=url,verify=False)
    response=requests.get(url=url,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

def session_post(url,header,payload):
    session.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    response=requests.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar


import json,os

cur_path = os.path.dirname(__file__)
file_path = "src\Config\_SwaggerConfig.json"

with open(file_path,'r') as context:
    data=context.read()
    properties=json.loads(data)
    if env=='test12':
        env=properties["env_12_details"]["env"]
        clientid=properties["env_12_details"]["clientid"]
        nonce=properties["env_12_details"]["nonce"]
        redirect_uri=properties["env_12_details"]["redirect_uri"]
    elif env=='test10':
        env=properties["env_10_details"]["env"]
        clientid=properties["env_10_details"]["clientid"]
        nonce=properties["env_10_details"]["nonce"]
        redirect_uri=properties["env_10_details"]["redirect_uri"]
    elif env=='test11':
        env=properties["env_11_details"]["env"]
        clientid=properties["env_11_details"]["clientid"]
        nonce=properties["env_11_details"]["nonce"]
        redirect_uri=properties["env_11_details"]["redirect_uri"]
    username=properties["credentials"]["username"]
    password=properties["credentials"]["password"]
    options=properties["credentials"]["options"]
    header=properties["header"]
    url1=properties["urls"]["url1"]
    url2=properties["urls"]["url2"]
    url3=properties["urls"]["url3"]
    url4=properties["urls"]["url4"]
    url5=properties["urls"]["url5"]
    if standard_model_name=='A':
        modelversionid=properties[model_type]["Model_A"]["modelversionid"]
        asofdate=properties[model_type]["Model_A"]["asofdate"]
    elif standard_model_name=='B':
        modelversionid=properties[model_type]["Model_B"]["modelversionid"]
        asofdate=properties[model_type]["Model_B"]["asofdate"]
    else :
        modelversionid=properties[model_type]["Model_C"]["modelversionid"]
        asofdate=properties[model_type]["Model_C"]["asofdate"]

options['warnBeforePasswordExpired']=True
options['multiOptionalFactorEnroll']=True


def payload_creation():
    payload={
       "password":password,
       "username":username,
       "options":options 
    }
 
    return payload
payload=payload_creation()

def url_split(url:str,env:str):
    url_list=url.split("{env}")
    url = url_list[0] + env + url_list[1]
    return url

def url5_split(url:str,clientid:str,nonce:str,redirect_uri:str,session_token:str,state:str):
    url_list=url.split("{clientid}")
    url_list=url_list[0] + clientid + url_list[1]
    url_list=url_list.split('{nonce}')
    url_list=url_list[0] + nonce + url_list[1]
    url_list=url_list.split('{redirect_uri}')
    url_list=url_list[0] + redirect_uri + url_list[1]
    url_list=url_list.split('{session_token}')
    url_list=url_list[0] + session_token + url_list[1]
    url_list=url_list.split('{state}')
    url_list=url_list[0] + state + url_list[1]
    return url_list


    
if env=='test12':
    clientid='0oa154h4vxthGbCau0h8'
    nonce='gQtMyTRwB4rFcAlYnZcPs7CzgzfgoBh4u44T13qGYWXlz5x1hx5ZWVwVoxXOffzP'
    redirect_uri='https://test12.ewealthmanager.com/authorization/callback'

url1=url_split(url1,env)
url2=url_split(url2,env)

response2 = requests.request("GET", url2,verify=False)
url=str(response2.url)
state=url.split('=')[-1]
response4 = requests.request("POST", url4, data=json.dumps(payload),headers=header,verify=False)
session_token=json.loads(response4.text)['sessionToken']
url5=url5_split(url5,clientid,nonce,redirect_uri,session_token,state)


