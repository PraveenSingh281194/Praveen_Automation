import json,os
import warnings

warnings.filterwarnings("ignore")

cur_path = os.path.dirname(__file__)
file_path = "src\Config\_Input.json"

with open(file_path, 'r') as f:
    data = f.read()
    properties = json.loads(data)
    oam_accountid = properties['OAM_AccountId']
    oam_targetmodelid = properties['OAM_targetModelId']
    oam_reason = properties['OAM_reason']
    oam_tag = properties['OAM_tag']
    oam_currency = properties['OAM_cuurecny']
    oam_taxsenstivity_static = properties['OAM_taxsenstivity_static']