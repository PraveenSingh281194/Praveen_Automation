import json,os
import warnings

warnings.filterwarnings("ignore")

cur_path = os.path.dirname(__file__)
file_path = "src\Config\_Configurations.json"

with open(file_path, 'r' ) as f:
    data = f.read()
    properties = json.loads(data)
    env = properties['env']