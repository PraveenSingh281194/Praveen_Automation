import sys
sys.path.insert(1, r'Framework\Utils')
sys.path.insert(1, r'Framework\Utils')
import json
import os
import pandas as pd
import copy
from datetime import datetime
from _Logger import logging
from _Exception import CustomException

import _API,_PublishFile
from ConfigScripts import _Config, _Configurations
import warnings

warnings.filterwarnings("ignore")


def Get_Transformed_Proposal_Body(proposal_row)->list:
    errors=[]
    proposal_body_structure = {
        "overlaySettingId": "",
        "targetModelId": "",
        "mutualFundDisposalMethod": "",     
        "customModelId": "",                    #optional field
        "taxSensitivities": []                  #optional field
    }
    mutualFundDisposalMethod_valid_values=["fifo","specificlot"]
    taxSensitivities_valid_values=['veryhigh','medium','high','low','tradetomodel']
    env = _Configurations.env
    Api = _API.Api()
    proposal_tax_sensitivity_dict = {'veryhigh': 'VeryHigh', 'medium': 'Medium',
                            'high': 'High', 'low': 'Low', "tradetomodel": "TradeToModel"}
    proposal_mutualFundDisposalMethod_valid_values_dict = {'fifo':'Fifo','specificlot':'SpecificLot'}

    proposal_body_structure_copy = copy.deepcopy(proposal_body_structure)
    response= Api.Get_Call(url=_Config.json_variables[env]["'get_setting_by_account_id'"]["'url'"].format(proposal_row['accountId']),
                                                                    header=_Config.json_variables[env]["'get_setting_by_account_id'"]["'header'"])
    if(response.status_code==200):
        proposal_body_structure_copy['overlaySettingId'] = json.loads(response.text)['id']
    elif(response.status_code==404):
        errors.append({"key":"overlaySettingId","status":"","account":proposal_row['accountId'],"payload":"","reason":f"Setting_id for this account not found"})
    if(proposal_row['mutualFundDisposalMethod'].lower() not in mutualFundDisposalMethod_valid_values):
        errors.append({"key":"mutualFundDisposalMethod","status":"","account":proposal_row['accountId'],"payload":"","reason":f"The specified value was not met for 'Mutual Fund Disposal Method' must be equal to 'AverageCost' or 'Fifo' or 'SpecificLot'"})
        proposal_body_structure_copy['mutualFundDisposalMethod']=proposal_row['mutualFundDisposalMethod']
    else:
        proposal_body_structure_copy['mutualFundDisposalMethod'] = proposal_mutualFundDisposalMethod_valid_values_dict[proposal_row['mutualFundDisposalMethod'].lower()]
    if(str(proposal_row['taxSensitivities'])!='nan'):               
        temp_tax_sensitivities = proposal_row['taxSensitivities'].replace(" ","").split(',')
        for tax_sensitivity in temp_tax_sensitivities:
            if(tax_sensitivity.lower() not in taxSensitivities_valid_values):
                errors.append({"key":"taxSensitivity","status":"","account":proposal_row['accountId'],"payload":"","reason":f"The specified value was not met for 'TaxSensitivity' must be equal to 'VeryHigh' or 'High' or 'Medium' or 'Low'"})
                proposal_body_structure_copy['taxSensitivities'].append(tax_sensitivity)
            else:
                proposal_body_structure_copy['taxSensitivities'].append(proposal_tax_sensitivity_dict[tax_sensitivity.lower()])
    else:                       ## no tax sensitivity provided in excel
        proposal_body_structure_copy['taxSensitivities'] = ['High','Low','TradeToModel','Medium','VeryHigh']
    if(str(proposal_row['customModelId'])=='nan'):
        del proposal_body_structure_copy['customModelId']
        proposal_body_structure_copy['targetModelId'] = str(proposal_row['targetModelId'])
    else:
        proposal_body_structure_copy['customModelId'] = str(int(proposal_row['customModelId']))
        proposal_body_structure_copy['targetModelId'] = str(proposal_row['targetModelId'])

    return [proposal_body_structure_copy,errors]



def Get_Transformed_SDT_Body(SDT_row)->dict:
    try:
        same_day_trading_payload_structure={"accountId":"",
                                            "amount":"",
                                            "cashIdentifier":""}
        same_day_trading_payload_structure_copy=copy.deepcopy(same_day_trading_payload_structure)
        same_day_trading_payload_structure_copy['accountId']= str(SDT_row['accountId'])
        same_day_trading_payload_structure_copy['amount']= float(SDT_row['amount'])
        same_day_trading_payload_structure_copy['cashIdentifier']= str(SDT_row['cashIdentifier'])
        return same_day_trading_payload_structure_copy
    except Exception as e:
        raise CustomException(e,sys)

def Get_Transformed_OAM_Body(OAM_row)->dict:
    try:
        OAM_body_structure = {
            "accountId": "",
            "targetModelId": "",     
            "customModelId": ""             #optional field
        }
        OAM_body_structure_copy=copy.deepcopy(OAM_body_structure)
        OAM_body_structure_copy['accountId']=str(OAM_row['accountId'])
        if(str(OAM_row['customModelId'])=='nan'):
            del OAM_body_structure_copy['customModelId']
            OAM_body_structure_copy['targetModelId'] = str(OAM_row['targetModelId'])
        else:
            OAM_body_structure_copy['customModelId'] = str(int(OAM_row['customModelId']))
            OAM_body_structure_copy['targetModelId'] = str(OAM_row['targetModelId'])
        return OAM_body_structure_copy
    except Exception as e:
        raise CustomException(e,sys)