import json
import warnings

warnings.filterwarnings("ignore")
def get_model_config():
    file_path = "src\Config\_ModelTypeInput.json"
    with open(file_path,'r') as f:
        data = f.read()
        properties = json.loads(data)
        model_type = properties['model_type']
        model_id = properties['model_id']
    return [model_type,model_id]