# from .._Portfolios import
import sys
import copy
from datetime import datetime
sys.path.insert(1, r'Framework\Utils')
import _PublishFile
import _API
from ConfigScripts import _Config, _Configurations, _Input
import pandas as pd
import json
import _Benchmark
from _Logger import logging
from _Exception import CustomException
import warnings

warnings.filterwarnings("ignore")

# from  import _API
# sys.path.insert(2, r'TMSInvestmentAPIAutomation\src\ConfigScripts')
# import _Config,_Configurations,_Input


class BusinessObjectStructure:

    businessObject = {
        "portfolioValue": "",
        "proxiedPositionsCusips": [""],
        "proposedFutureStates": [],
        "currentState": {}
    }

#########################################################################################################################################

    proposedFutureStates = {
        "taxSensitivity": "",
        "predictedTrackingError": "",
        "transitionAmountDollar": "",
        "transitionAmountPercentage": "",
        "netRealizedLongTermGainLoss": "",
        "netRealizedShortTermGainLoss": "",
        "estimatedTaxAmount": "",
        "detail": {},
        "proposalId": ""
    }

    proposefFutureState_detail = {
        "positions": [],
        "changes": [],
        "analytics": {}
    }

    proposedFutureState_detail_positions = {
        "identifiers": {
            "cusip": "",
            "clientId": ""
        },
        "proxyIdentifiers": {
            "cusip": "",
            "clientId": ""
        },
        "marketValue": "",
        "notionalMarketValue": "",
        "quantity": "",
        "posInfo": {  # Yes if avaliable
            "sleeve": ""
        }
    }

    proposedFutureState_detail_changes = {  # Whole field is TBD except metadata
        "positionIdentifiers": {
            "cusip": "",
            "clientId": ""
        },
        "direction": "",
        "quantity": "",
        "marketValue": "",
        "notionalMarketValue": "",
        "metadata": {}
    }

    proposedFutureState_detail_Changes_metadata = {  # need to
        "sleeve": "DFAT4S",
        "isCashSwap": "N",
        "isSwapTrade": "N",
    }

    proposedFutureState_detail_analytics = {
        "taxAnalytics": {},
        "assetAllocations": []
    }

    proposedFutureState_detail_analytics_taxAnalytics = {
        "realizedShortTerm": {},
        "realizedLongTerm": {},
        "unrealizedShortTerm": {},
        "unrealizedLongTerm": {}
    }

    proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm = {
        "gain": "",
        "loss": "",
        "net": ""
    }

    proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm = {
        "gain": "",
        "loss": "",
        "net": ""
    }

    proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm = {
        "gain": "",
        "loss": "",
        "net": ""
    }

    proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm = {
        "gain": "",
        "loss": "",
        "net": ""
    }

    proposedFutureState_detail_analytics_assetAllocations = {
        "assetClassDescription": "Equity",
        "sectors": []
    }

    proposedFutureState_detail_analytics_assetAllocations_sectors = {
        "sectorDescription": "Technology",
        "sectorWeight": 0.2555
    }

#########################################################################################################################################

    currentState = {
        "predictedTrackingError": "",
        "detail": {}
    }

    currentState_detail = {
        "positions": [],
        "analytics": {}
    }

    currentState_detail_positions = {
        "identifiers": {
            "cusip": "",
            "clientId": ""
        },
        "proxyIdentifiers": {
            "cusip": "",
            "clientId": ""
        },
        "marketValue": "",
        "notionalMarketValue": "",
        "quantity": ""
    }

    currentState_detail_analytics = {
        "taxAnalytics": {},
        "assetAllocations": []
    }

    currentState_detail_analytics_taxAnalytics = {
        "unrealizedShortTerm": {},
        "unrealizedLongTerm": {}
    }

    currentState_detail_analytics_taxAnalytics_unrealizedShortTerm = {
        "gain": 200.00,
        "loss": -100.00,
        "net": 100.00
    }

    currentState_detail_analytics_taxAnalytics_unrealizedLongTerm = {
        "gain": 200.00,
        "loss": -100.00,
        "net": 100.00
    }

    currentState_detail_analytics_assetAllocation = {
        "assetClassDescription": "Equity",
        "sectors": []
    }

    currentState_detail_analytics_assetAllocation_sectors = {
        "sectorDescription": "Technology",
        "sectorWeight": 0.2555
    }


#########################################################################################################################################

business_object_structure = BusinessObjectStructure()


def Create_businessObject(blk_response, struct, taxSensitivity):
    try:
        logging.info('Started creating Business Obejct')
        businessObject_copy = copy.deepcopy(struct)
        businessObject_copy['portfolioValue'] = blk_response['analysis']['original'][
            'portfolios'][0]['portfolio']['nav']['accountBaseMarketValue']  # Done
        if('proxiedPositions' in list(blk_response.keys())):
            businessObject_copy['proxiedPositionsCusips'] = blk_response['proxiedPositions']
        else:
            businessObject_copy['proxiedPositionsCusips'] = []
        temp_obj = Create_proposedFutureStates(
            blk_response=blk_response, struct=business_object_structure.proposedFutureStates, taxSensitivity=taxSensitivity)
        businessObject_copy['proposedFutureStates'].append(temp_obj)  # Done
        businessObject_copy['currentState'] = Create_currentState(
            blk_response=blk_response, struct=business_object_structure.currentState)
        logging.info('Business Obejct Created')
        return businessObject_copy
    except Exception as e:
        raise CustomException(e,sys)

#########################################################################################################################################


def Create_proposedFutureStates(blk_response, struct, taxSensitivity):
    try:
        logging.info('Started creating proposedFutureStates')
        proposedFutureState_copy = copy.deepcopy(struct)
        proposedFutureState_copy['taxSensitivity'] = taxSensitivity  # Done
        proposedFutureState_copy['predictedTrackingError'] = blk_response['analysis'][
            'proposed']['portfolios'][0]['active']['risk']['totalRisk']  # Done
        proposedFutureState_copy['transitionAmountDollar'] = Calculate_proposedFutureState_transitionAmountDollar(
            blk_response = blk_response)  # Done
        proposedFutureState_copy['transitionAmountPercentage'] = proposedFutureState_copy['transitionAmountDollar'] / \
            blk_response['analysis']['original']['portfolios'][0]['portfolio']['nav']['accountBaseMarketValue']  # Done
        for ele in blk_response['analysis']['taxAnalytics']['proposed']['portfolios'][0]['gainOrLoss']['proposedRealized']:
            if(ele['type'] == "SHORT_TERM"):
                # Done
                proposedFutureState_copy['netRealizedShortTermGainLoss'] = ele['net']
            if(ele['type'] == "LONG_TERM"):
                # Done
                proposedFutureState_copy['netRealizedLongTermGainLoss'] = ele['net']
        proposedFutureState_copy['estimatedTaxAmount'] = float(proposedFutureState_copy['netRealizedShortTermGainLoss']*blk_response['proposal']['original']['portfolios'][0]['metadata']['SHORT_TERM_TAX_RATE']/100
                                                          + proposedFutureState_copy['netRealizedShortTermGainLoss']*blk_response[
                                                              'proposal']['original']['portfolios'][0]['metadata']['STATE_TAX_RATE']/100
                                                          + proposedFutureState_copy['netRealizedLongTermGainLoss']*blk_response['proposal']['original']['portfolios'][0]['metadata']['LONG_TERM_TAX_RATE']/100
                                                          + proposedFutureState_copy['netRealizedLongTermGainLoss']*blk_response['proposal']['original']['portfolios'][0]['metadata']['STATE_TAX_RATE']/100)
        proposedFutureState_copy['detail'] = Create_proposedFutureState_detail(
            blk_response=blk_response, struct=business_object_structure.proposefFutureState_detail)
        # Done
        proposedFutureState_copy['proposalId'] = blk_response['proposal']['id']
        logging.info('Created proposedFutureStates')
        return proposedFutureState_copy
    except Exception as e:
        raise CustomException(e,sys)


def Calculate_proposedFutureState_transitionAmountDollar(blk_response):
    try:
        for custom_analytic in blk_response['analysis']['customAnalytics']:
            if(custom_analytic['id'] == 'totalTradeValueInOneDirection'):
                proposedFutureState_transitionAmountDollar = custom_analytic['metadata']['totalTradeValueInOneDirection']
                break
        return float(proposedFutureState_transitionAmountDollar)
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail(blk_response, struct):
    try:
        logging.info('Started creating proposedFutureState_detail')
        proposedFutureState_detail_copy = copy.deepcopy(struct)
        proposedFutureState_detail_copy['positions'] = Create_proposedFutureState_detail_positions(
            blk_response=blk_response, struct=business_object_structure.proposedFutureState_detail_positions)
        proposedFutureState_detail_copy['changes'] = Create_proposedFutureState_detail_changes(
            blk_response=blk_response, struct=business_object_structure.proposedFutureState_detail_changes)
        proposedFutureState_detail_copy['analytics'] = Create_proposedFutureState_detail_analytics(
            blk_response=blk_response, struct=business_object_structure.proposedFutureState_detail_analytics)
        logging.info('created proposedFutureState_detail')
        return proposedFutureState_detail_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_positions(blk_response, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_positions')
        temp_positions = []
        for position in blk_response['proposal']['proposed']['portfolios'][0]['positions']:
            proposedFutureState_detail_positions_copy = copy.deepcopy(struct)
            # Cusip not present in API response object, just to confirm the value
            proposedFutureState_detail_positions_copy['identifiers'][
                'cusip'] = position['identifiers']['clientId']
            proposedFutureState_detail_positions_copy['identifiers'][
                'clientId'] = position['identifiers']['clientId']
            if('proxyIdentifiers' in list(position.keys())):
                proposedFutureState_detail_positions_copy['proxyIdentifiers'][
                    'cusip'] = position['proxyIdentifiers']['clientId']
                proposedFutureState_detail_positions_copy['proxyIdentifiers'][
                    'clientId'] = position['proxyIdentifiers']['clientId']
            else:
                del proposedFutureState_detail_positions_copy['proxyIdentifiers']
            proposedFutureState_detail_positions_copy['marketValue'] = position['marketValue']
            proposedFutureState_detail_positions_copy['notionalMarketValue'] = position['notionalMarketValue']
            proposedFutureState_detail_positions_copy['quantity'] = position['quantity']
            if('posInfo' in list(position.keys())):
                if('SLEEVE_ID' in list(position['posInfo'].keys())):
                    proposedFutureState_detail_positions_copy['posInfo']['sleeve'] = position['posInfo']['SLEEVE_ID']
                else:
                    del proposedFutureState_detail_positions_copy['posInfo']
            else:
                del proposedFutureState_detail_positions_copy['posInfo']
            temp_positions.append(proposedFutureState_detail_positions_copy)
        logging.info('created proposedFutureState_detail_positions')
        return temp_positions
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_changes(blk_response, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_changes')
        temp_changes = []
        for change in blk_response['proposal']['changes']:
            proposedFutureState_detail_changes_copy = copy.deepcopy(struct)
            # Discuss about the cusip field in the response body
            proposedFutureState_detail_changes_copy['positionIdentifiers'][
                'cusip'] = change['identifiers']['clientId']
            # Discuss about the cusip field in the response body
            proposedFutureState_detail_changes_copy['positionIdentifiers'][
                'clientId'] = change['identifiers']['clientId']
            proposedFutureState_detail_changes_copy['direction'] = change['direction']
            proposedFutureState_detail_changes_copy['quantity'] = change['quantity']
            proposedFutureState_detail_changes_copy['marketValue'] = change['marketValue']
            proposedFutureState_detail_changes_copy['notionalMarketValue'] = change['notionalMarketValue']
            proposedFutureState_detail_changes_copy['metadata'] = Create_proposedFutureState_detail_changes_metadata(change = change,struct=business_object_structure.proposedFutureState_detail_Changes_metadata)
            if( proposedFutureState_detail_changes_copy['metadata']==None):
                del proposedFutureState_detail_changes_copy['metadata']
            temp_changes.append(proposedFutureState_detail_changes_copy)
        logging.info('Created proposedFutureState_detail_positions')
        return temp_changes
    except Exception as e:
        raise CustomException(e,sys)

# From where to get mapping of these all attributes of metadata
def Create_proposedFutureState_detail_changes_metadata(change:dict, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_changes_metadata')
        proposedFutureState_detail_Changes_metadata_copy = copy.deepcopy(
            struct)
        if('metadata' in list(change.keys())):
            if('SLEEVE_ID' in change['metadata']):
                proposedFutureState_detail_Changes_metadata_copy['sleeve'] = change['metadata']['SLEEVE_ID']
            else:
                del proposedFutureState_detail_Changes_metadata_copy['sleeve']
            if('IS_CASH' in change['metadata']):
                proposedFutureState_detail_Changes_metadata_copy['isCashSwap'] = change['metadata']['IS_CASH']
            else:
                del proposedFutureState_detail_Changes_metadata_copy['isCashSwap']
            if('IS_SWAP_TRADE' in change['metadata']):
                proposedFutureState_detail_Changes_metadata_copy['isSwapTrade'] = change['metadata']['IS_SWAP_TRADE']
            else:
                del proposedFutureState_detail_Changes_metadata_copy['isSwapTrade']
        else:
            proposedFutureState_detail_Changes_metadata_copy = None
            logging.info('Created proposedFutureState_detail_changes_metadata')
        return proposedFutureState_detail_Changes_metadata_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics(blk_response, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics')
        proposedFutureState_detail_analytics_copy = copy.deepcopy(struct)
        proposedFutureState_detail_analytics_copy['taxAnalytics'] = Create_proposedFutureState_detail_analytics_taxAnalytics(
            blk_response=blk_response, struct=business_object_structure.proposedFutureState_detail_analytics_taxAnalytics)
        proposedFutureState_detail_analytics_copy['assetAllocations'] = Create_proposedFutureState_detail_analytics_assetAllocations(
            blk_response=blk_response, struct=business_object_structure.proposedFutureState_detail_analytics_assetAllocations)
        logging.info('Created proposedFutureState_detail_analytics')
        return proposedFutureState_detail_analytics_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics_taxAnalytics(blk_response, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics_taxAnalytics')
        proposedFutureState_detail_analytics_taxAnalytics_copy = copy.deepcopy(
            struct)
        for ele in blk_response['analysis']['taxAnalytics']['proposed']['portfolios'][0]['gainOrLoss']['proposedRealized']:
            if(ele['type'] == "SHORT_TERM"):
                proposedFutureState_detail_analytics_taxAnalytics_copy['realizedShortTerm'] = Create_proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm(
                    proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_obj=ele, struct=business_object_structure.proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm)
            if(ele['type'] == "LONG_TERM"):
                proposedFutureState_detail_analytics_taxAnalytics_copy['realizedLongTerm'] = Create_proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm(
                    proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_obj=ele, struct=business_object_structure.proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm)
        for ele in blk_response['analysis']['taxAnalytics']['proposed']['portfolios'][0]['gainOrLoss']['unrealized']:
            if(ele['type'] == "SHORT_TERM"):
                proposedFutureState_detail_analytics_taxAnalytics_copy['unrealizedShortTerm'] = Create_proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm(
                    proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj=ele, struct=business_object_structure.proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm)
            if(ele['type'] == "LONG_TERM"):
                proposedFutureState_detail_analytics_taxAnalytics_copy['unrealizedLongTerm'] = Create_proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm(
                    proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj=ele, struct=business_object_structure.proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm)
        logging.info('Created proposedFutureState_detail_analytics_taxAnalytics')
        return proposedFutureState_detail_analytics_taxAnalytics_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm(proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_obj, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm')
        proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_copy = copy.deepcopy(
            struct)
        proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_copy[
            'gain'] = proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_obj['gain']
        proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_copy[
            'loss'] = proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_obj['loss']
        proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_copy[
            'net'] = proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_obj['net']
        logging.info('Created proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm')
        return proposedFutureState_detail_analytics_taxAnalytics_realizedShortTerm_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm(proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_obj, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm')
        proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_copy = copy.deepcopy(
            struct)
        proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_copy[
            'gain'] = proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_obj['gain']
        proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_copy[
            'loss'] = proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_obj['loss']
        proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_copy[
            'net'] = proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_obj['net']
        logging.info('Created proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm')
        return proposedFutureState_detail_analytics_taxAnalytics_realizedLongTerm_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm(proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm')
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy = copy.deepcopy(
            struct)
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy[
            'gain'] = proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj['gain']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy[
            'loss'] = proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj['loss']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy[
            'net'] = proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj['net']
        logging.info('Created proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm')
        return proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm(proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm')
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy = copy.deepcopy(
            struct)
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy[
            'gain'] = proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj['gain']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy[
            'loss'] = proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj['loss']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy[
            'net'] = proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj['net']
        logging.info('Created proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm')
        return proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics_assetAllocations(blk_response, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics_assetAllocations')
        temp_assetAllocations = []
        for assetAllocation in blk_response['analysis']['proposed']['portfolios'][0]['portfolio']['breakdowns']:
            proposedFutureState_detail_Analytics_assetAllocation_copy = copy.deepcopy(
                struct)
            if('displayName' in list(assetAllocation.keys())):
                proposedFutureState_detail_Analytics_assetAllocation_copy[
                    'assetClassDescription'] = assetAllocation['displayName']
            else:
                proposedFutureState_detail_Analytics_assetAllocation_copy[
                    'assetClassDescription'] = "NotFound"

            proposedFutureState_detail_Analytics_assetAllocation_copy['sectors'] = Create_proposedFutureState_detail_analytics_assetAllocations_sectors(
                assetAllocation=assetAllocation, struct=business_object_structure.proposedFutureState_detail_analytics_assetAllocations_sectors)
            temp_assetAllocations.append(
                proposedFutureState_detail_Analytics_assetAllocation_copy)
        logging.info('Created proposedFutureState_detail_analytics_assetAllocations')
        return temp_assetAllocations
    except Exception as e:
        raise CustomException(e,sys)


def Create_proposedFutureState_detail_analytics_assetAllocations_sectors(assetAllocation, struct):
    try:
        logging.info('Started creating proposedFutureState_detail_analytics_assetAllocations_sectors')
        temp_assetAllocation_sectors = []
        for assetAllocation_sector in assetAllocation['sectors']:
            proposedFutureState_detail_analytics_assetAllocation_sectors_copy = copy.deepcopy(
                struct)
            if('displayName' in list(assetAllocation_sector.keys())):
                proposedFutureState_detail_analytics_assetAllocation_sectors_copy[
                    'sectorDescription'] = assetAllocation_sector['displayName']
            else:
                proposedFutureState_detail_analytics_assetAllocation_sectors_copy[
                    'sectorDescription'] = "Not Found"
            proposedFutureState_detail_analytics_assetAllocation_sectors_copy[
                'sectorWeight'] = assetAllocation_sector['contribution']
            temp_assetAllocation_sectors.append(
                proposedFutureState_detail_analytics_assetAllocation_sectors_copy)
        logging.info('Created proposedFutureState_detail_analytics_assetAllocations_sectors')
        return temp_assetAllocation_sectors
    except Exception as e:
        raise CustomException(e,sys)


##########################################################################################################################################

def Create_currentState(blk_response, struct):
    try:
        logging.info('Started creating currentState')
        currentState_copy = copy.deepcopy(struct)
        currentState_copy['predictedTrackingError'] = blk_response['analysis']['original']['portfolios'][0]['active']['risk']['totalRisk']
        currentState_copy['detail'] = Create_currentState_detail(
            blk_response=blk_response, struct=business_object_structure.currentState_detail)
        logging.info('Created currentState')
        return currentState_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_currentState_detail(blk_response, struct):
    try:
        logging.info('Started creating currentState_detail')
        currentState_detail_copy = copy.deepcopy(struct)
        currentState_detail_copy['positions'] = Create_currentState_detail_positions(
            blk_response=blk_response, struct=business_object_structure.currentState_detail_positions)
        currentState_detail_copy['analytics'] = Create_currentState_detail_analytics(
            blk_response=blk_response, struct=business_object_structure.currentState_detail_analytics)
        logging.info('Created currentState_detail')
        return currentState_detail_copy
    except Exception as e:
        print(e)

# Have to confirm the same cusip not present at the location
def Create_currentState_detail_positions(blk_response, struct):
    try:
        logging.info('Started creating currentState_detail_positions')
        temp_positions = []
        for position in blk_response['proposal']['original']['portfolios'][0]['positions']:
            currentState_detail_positions_copy = copy.deepcopy(struct)
            currentState_detail_positions_copy['identifiers']['cusip'] = position['identifiers']['clientId']
            currentState_detail_positions_copy['identifiers']['clientId'] = position['identifiers']['clientId']
            if('proxyIdentifiers' in list(position.keys())):
                currentState_detail_positions_copy['proxyIdentifiers'][
                    'cusip'] = position['proxyIdentifiers']['clientId']
                currentState_detail_positions_copy['proxyIdentifiers'][
                    'clientId'] = position['proxyIdentifiers']['clientId']
            else:
                del currentState_detail_positions_copy['proxyIdentifiers']
            currentState_detail_positions_copy['marketValue'] = position['marketValue']
            currentState_detail_positions_copy['notionalMarketValue'] = position['notionalMarketValue']
            currentState_detail_positions_copy['quantity'] = position['quantity']
            temp_positions.append(currentState_detail_positions_copy)
        logging.info('Created currentState_detail_positions')
        return temp_positions
    except Exception as e:
        raise CustomException(e,sys)


def Create_currentState_detail_analytics(blk_response, struct):
    try:
        logging.info('Started creating currentState_detail_analytics')
        currentState_detail_analytics_copy = copy.deepcopy(struct)
        currentState_detail_analytics_copy['taxAnalytics'] = Create_currentState_detail_analytics_taxAnalytics(
            blk_response=blk_response, struct=business_object_structure.currentState_detail_analytics_taxAnalytics)
        currentState_detail_analytics_copy['assetAllocations'] = Create_currentState_detail_analytics_assetAllocation(
            blk_response=blk_response, struct=business_object_structure.currentState_detail_analytics_assetAllocation)
        logging.info('Created currentState_detail_analytics')
        return currentState_detail_analytics_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_currentState_detail_analytics_taxAnalytics(blk_response, struct):
    try:
        logging.info('Started creating currentState_detail_analytics_taxAnalytics')
        currentState_detail_analytics_taxAnalytics_copy = copy.deepcopy(struct)
        for ele in blk_response['analysis']['taxAnalytics']['original']['portfolios'][0]['gainOrLoss']['unrealized']:
            if(ele['type'] == "SHORT_TERM"):
                currentState_detail_analytics_taxAnalytics_copy['unrealizedShortTerm'] = Create_currentState_detail_analytics_taxAnalytics_unrealizedShortTerm(
                    currentState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj=ele, struct=business_object_structure.currentState_detail_analytics_taxAnalytics_unrealizedShortTerm)
            if(ele['type'] == "LONG_TERM"):
                currentState_detail_analytics_taxAnalytics_copy['unrealizedLongTerm'] = Create_currentState_detail_analytics_taxAnalytics_unrealizedLongTerm(
                    currentState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj=ele, struct=business_object_structure.currentState_detail_analytics_taxAnalytics_unrealizedLongTerm)
        logging.info('Created currentState_detail_analytics_taxAnalytics')
        return currentState_detail_analytics_taxAnalytics_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_currentState_detail_analytics_taxAnalytics_unrealizedShortTerm(currentState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj, struct):
    try:
        logging.info('Started creating currentState_detail_analytics_taxAnalytics_unrealizedShortTerm')
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy = copy.deepcopy(
            struct)
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy[
            'gain'] = currentState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj['gain']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy[
            'loss'] = currentState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj['loss']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy[
            'net'] = currentState_detail_analytics_taxAnalytics_unrealizedShortTerm_obj['net']
        logging.info('Created currentState_detail_analytics_taxAnalytics_unrealizedShortTerm')
        return proposedFutureState_detail_analytics_taxAnalytics_unrealizedShortTerm_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_currentState_detail_analytics_taxAnalytics_unrealizedLongTerm(currentState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj, struct):
    try:
        logging.info('Started creating currentState_detail_analytics_taxAnalytics_unrealizedLongTerm')
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy = copy.deepcopy(
            struct)
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy[
            'gain'] = currentState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj['gain']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy[
            'loss'] = currentState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj['loss']
        proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy[
            'net'] = currentState_detail_analytics_taxAnalytics_unrealizedLongTerm_obj['net']
        logging.info('Created currentState_detail_analytics_taxAnalytics_unrealizedLongTerm')
        return proposedFutureState_detail_analytics_taxAnalytics_unrealizedLongTerm_copy
    except Exception as e:
        raise CustomException(e,sys)


def Create_currentState_detail_analytics_assetAllocation(blk_response, struct):
    try:
        logging.info('Started creating currentState_detail_analytics_assetAllocation')
        temp_assetAllocations = []
        for assetAllocation in blk_response['analysis']['original']['portfolios'][0]['portfolio']['breakdowns']:
            currentState_detail_analytics_assetAllocations_copy = copy.deepcopy(
                struct)
            if('displayName' in list(assetAllocation.keys())):
                currentState_detail_analytics_assetAllocations_copy[
                    'assetClassDescription'] = assetAllocation['displayName']
            else:
                currentState_detail_analytics_assetAllocations_copy[
                    'assetClassDescription'] = "NotFound"
            currentState_detail_analytics_assetAllocations_copy['sectors'] = Create_currentState_detail_analytics_assetAllocation_sectors(
                assetAllocation=assetAllocation, struct=business_object_structure.currentState_detail_analytics_assetAllocation_sectors)
            temp_assetAllocations.append(
                currentState_detail_analytics_assetAllocations_copy)
        logging.info('Created currentState_detail_analytics_assetAllocation')
        return temp_assetAllocations
    except Exception as e:
        raise CustomException(e,sys)


def Create_currentState_detail_analytics_assetAllocation_sectors(assetAllocation, struct):
    try:
        logging.info('Started creating currentState_detail_analytics_assetAllocation_sectors')
        temp_assetAllocation_sectors = []
        for assetAllocation_sector in assetAllocation['sectors']:
            proposedFutureState_detail_analytics_assetAllocation_sectors_copy = copy.deepcopy(
                struct)
            if('displayName' in list(assetAllocation_sector.keys())):
                proposedFutureState_detail_analytics_assetAllocation_sectors_copy[
                    'sectorDescription'] = assetAllocation_sector['displayName']
            else:
                proposedFutureState_detail_analytics_assetAllocation_sectors_copy[
                    'sectorDescription'] = "NotFound"
            proposedFutureState_detail_analytics_assetAllocation_sectors_copy[
                'sectorWeight'] = assetAllocation_sector['contribution']
            temp_assetAllocation_sectors.append(
                proposedFutureState_detail_analytics_assetAllocation_sectors_copy)
        logging.info('Created currentState_detail_analytics_assetAllocation_sectors')
        return temp_assetAllocation_sectors
    except Exception as e:
        raise CustomException(e,sys)

###########################################################################################################################################
