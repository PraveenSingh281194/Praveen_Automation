import requests
import json,pyodbc
import pandas as pd
from pathlib import Path 
from ConfigScripts import _Config,_Configurations,_Input
from ConfigScripts import _SessionConfig as configfile,_ModelTypeInput
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings("ignore")


response,cookies_jar=configfile.session_get(configfile.url5)

header={'Cookie':'FSSESSION='+cookies_jar['FSSESSION']+'; TargetURL=; ASP.NET_SessionId=' + cookies_jar['ASP.NET_SessionId']+'; GFWMSessionId=' + cookies_jar['GFWMSessionId'] +'; ewm_ns='+ cookies_jar['ewm_ns'] + '; website#lang=' + cookies_jar['website#lang']  }


def swagger_dataframe():
    yesterday = datetime.now() - timedelta(1)
    asofdate = datetime.strftime(yesterday, '%Y-%m-%d')

    # response,cookies_jar=configfile.session_get(configfile.url5)

    # header={'Cookie':'FSSESSION='+cookies_jar['FSSESSION']+'; TargetURL=; ASP.NET_SessionId=' + cookies_jar['ASP.NET_SessionId']+'; GFWMSessionId=' + cookies_jar['GFWMSessionId'] +'; ewm_ns='+ cookies_jar['ewm_ns'] + '; website#lang=' + cookies_jar['website#lang']  }

    if _ModelTypeInput.get_model_config()[0]=='standard_model':
        swagger_url=f"https://{_Configurations.env.lower()}.ewealthmanager.com/api/strategies/v2/models/{_ModelTypeInput.get_model_config()[1]}/asofdate/{asofdate}/holdings"
    else:
        swagger_url=f"https://{_Configurations.env.lower()}.ewealthmanager.com/api/strategies/v2/models/{_ModelTypeInput.get_model_config()[1]}/asofdate/{asofdate}/customHoldings"

    swagger_response = requests.request("GET", swagger_url,headers=header,verify=False)
    # if(swagger_response.status_code==200):
    swagger_data=json.loads(swagger_response.text)
    swagger_df = pd.DataFrame.from_records(swagger_data)
    return swagger_df


def Benchmark_Json():
    swagger_dff= swagger_dataframe()   
    id_list = []
    bench_dict = {
        'id':_ModelTypeInput.get_model_config()[1],
        'currency':'USD',
        'components':id_list,

    }
    components_dict = {}
    benchmark_dictionary = {
        'benchmark':bench_dict
    }
    for j,row in swagger_dff.iterrows():
            row_df = row
            string_id = "bench_"+str(j+1)+"_"+row_df['cusip']
            weight_row = row_df['weight']/100
            if(row_df['sleeve']==None):
                components_dict={'id':str(string_id),'identifiers':{'clientId':str(row_df['cusip'])},"weight":float(weight_row)}
            else:
                components_dict={'id':str(string_id),'identifiers':{'clientId':str(row_df['cusip'])},"weight":float(weight_row),"posInfo":{'SLEEVE_ID':str(row_df['sleeve'])}}                
            id_list.append(components_dict)
    return benchmark_dictionary['benchmark']

