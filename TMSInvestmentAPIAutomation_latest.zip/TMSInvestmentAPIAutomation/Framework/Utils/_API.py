import requests as req
import json
import warnings

warnings.filterwarnings("ignore")

class Api:


    def Okta_Token_Call(self,url:str,username:str,password:str,payload:dict,header:dict)->str:
        
        """generates the Okta token

        Args:
            url (str): Okta API url
            username (str): username
            password (str): password
            payload (dict): API body
            header (dict): header parameters

        Returns:
            str: Okta token value
        """   
        response = req.post(str(url),data=payload,auth=(str(username),str(password)),headers=header,verify = False)
        token = "Bearer " + json.loads(response.text)['access_token']
        return token
        

    def Post_Call(self,url:str,payload:dict=None,header:dict=None)->req.models.Response:

        """generates the response of Post API

        Args:
            url (str): Post API url
            payload (dict, optional): API body. Defaults to None.
            header (dict, optional): header parameters. Defaults to None.

        Returns:
            req.models.Response: response object
        """
        response = req.post(url,data=payload,headers=header,verify=False)
        return response


    def Status_Verify(self,response:req.models.Response, status_code)->int:

        """will verify the status_code of the response with the required one

        Args:
            response (req.models.Response): response object of the API
            status_code (Any): the required status code to be compared

        Returns:
            int: will return 1(int) if the status code matches else return 0(int)
        """        
        if(int(response.status_code) == int(status_code)):
            return 1
        else:
            return 0


    def Get_Status(self,response:req.models.Response)->int:

        """given a response object will return the status code of the response

        Args:
            response (req.models.Response): response object of the API

        Returns:
            int: status code of API response object received
        """        
        return response.status_code


    def Get_Call(self,url,header:dict = None)->req.models.Response:

        """generates the response of Get API

        Args:
            get_api_url (_type_): Get API url
            header (dict, optional): header parameters. Defaults to None.

        Returns:
            req.models.Response: response object
        """ 
        response = req.get(str(url),headers=header,verify=False)
        return response