import os,datetime
from allure_combine import combine_allure

# 1) Create complete.html in allure-generated folder
combine_allure("C:\\Users\\Praveen\\Pycharm_Projects\\TMS\\allure-report")

# 2) Make sure that dest folder exists, create if not
combine_allure(
    "C:\\Users\\Praveen\\Pycharm_Projects\\TMS\\allure-report",
    dest_folder="C:\\Users\\Praveen\\Pycharm_Projects\\TMS\\Reports_Allure\\result",
    auto_create_folders=True)

#3) Remove sinon.js and server.js from allure folder after complete.html is generated:
#4) If html/json files what should be utf-8 is has broken encoding, ignore errors:
combine_allure(
    "C:\\Users\\Praveen\\Pycharm_Projects\\TMS\\allure-report",
    remove_temp_files=True,ignore_utf8_errors=True)

dt=datetime.datetime.now().strftime("%Y_%m_%d-%I_%M_%S_%p")
old_name="C:\\Users\\Praveen\\Pycharm_Projects\\TMS\\Reports_Allure\\result\\complete.html"
new_name=f"C:\\Users\\Praveen\\Pycharm_Projects\\TMS\\Reports_Allure\\result\\complete_{dt}.html"
os.rename(old_name,new_name)
