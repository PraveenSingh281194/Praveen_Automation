import subprocess,sys
if __name__=='__main__':
    p = subprocess.Popen('powershell.exe -ExecutionPolicy RemoteSigned -file "C:\\Users\\Praveen\\Pycharm_Projects\\TMS\\bash.ps1"',
                         stdout=sys.stdout)
    p.communicate()
    