behave -f allure_behave.formatter:AllureFormatter -o reports/ features/feature1.feature

allure generate reports\

python final_report.py