from behave import given,when,then
import requests
import time,os,datetime
from _helper.helper import helper

obj=helper()
@given('Summation perform')
def step1(self):
    self.a=2
    self.b=8
    assert self.a + self.b==10, 'summation failed'
    
    
@given('multiplication perform')
def step2(self):
    assert self.a*self.b==16, 'multiplication failed'
    
@given("API is available to test")
def scenario2_given(context):
    url=obj.URL
    assert url , 'URL not found'
    
@when('User makes a get request')
def scenario2_when(context):
    obj.get_response()
    
@then('Response should be fetched with status code {status}')
def scenario2_then(context,status):
    obj.status_verify(int(status))
