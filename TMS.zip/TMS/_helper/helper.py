from features.environment import *
import requests,os,time,datetime
class helper:
    def __init__(self):
        self.URL=Base_URL    
    def get_response(self):
        self.response=requests.get(self.URL)
        assert self.response , 'No Resonse found'
    def status_verify(self,status):
        status_code=self.response.status_code
        assert status_code==status, f'Wrong status code , {status_code}'