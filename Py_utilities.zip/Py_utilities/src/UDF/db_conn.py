import mysql.connector
import config_py.config as config
def mysql_conn(host,user,password,database):
    # Establish the connection
    conn = mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
        )
    if conn.is_connected():
     print(""" connection to database is estalished ..! """)
    return conn

def mysql_db_credentials():
    host=config.db_variables["mysql"]["host"]
    user=config.db_variables["mysql"]["username"]
    password=config.db_variables["mysql"]["password"]
    database=config.db_variables["mysql"]["db_name"]
    port=config.db_variables["mysql"]["port"]
    return user,password,host,port,database