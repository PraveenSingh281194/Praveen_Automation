# import pandas as pd
  
# data = {
#     "A": ["TeamA", "TeamB", "TeamB", "TeamC", "TeamA"],
#     "B": [50, 40, 40, 30, 50],
#     "C": [True, False, False, False, True]
# }
  
# df = pd.DataFrame(data)
# print(df)
# print(df.drop_duplicates(keep=False))
# print(df.drop_duplicates(keep='first'))



# import pandas as pd
# import mysql.connector
# print('hello')
# def mysql_connect():
#     mydb = mysql.connector.connect(host="localhost",user="root",password="281194@ps",
#     database="test_db")
#     mycursor = mydb.cursor()
#     table_name="cutomers"
#     # mycursor.execute(f"CREATE TABLE {table_name} (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), address VARCHAR(255))")
#     # print(f'{table_name} Table created succesfully')
#     # sql = "INSERT INTO test_db.cutomers (name, address) VALUES (%s, %s)"
#     # val = [('Peter', 'Lowstreet 4'),('Amy', 'Apple st 652'),('Hannah', ''),('Michael', 'Valley 345'),
#     # ('Sandy', None),('Betty', ''),('Richard', 'Sky st 331'),('Susan', None),('Vicky', 'Yellow Garden 2'),('Ben', 'Park Lane 38'),('William', 'Central st 954'),('Chuck', 'Main Road 989'),
#     # ('Viola', 'Sideway 1633'),('Betty', 'Green Grass 1'),('Peter', 'Lowstreet 4')]
#     # mycursor.executemany(sql, val)
#     # mydb.commit()
#     # print(mycursor.rowcount, "was inserted.")
# mysql_connect()





