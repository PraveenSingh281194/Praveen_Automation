import subprocess,time

#code execution starts from here
if __name__ == "__main__":
    start_time=time.time()
    print('!!!Welcome to Py_utilities!!!')
    user_input=input("""Please select the type of operation you would like to execute, 
    'a' for data load
    'b' for Validation
    Enter the Sequence : """)
    
    if user_input=='a':
        try:
            print('Code execution starts')
            from data_mysql import data_main
        except Exception as E:
            print(E)
            raise E 
    elif user_input=='b':
        try:
            print('Code execution starts')
            from Validation import Agenda
        except Exception as E:
            print(E)
            raise E
    print(f'Total Time taken: ', time.time()-start_time)  
    
