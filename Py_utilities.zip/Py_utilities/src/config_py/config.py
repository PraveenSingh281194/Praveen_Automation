import pandas as pd
import json


with open(r'src\config_json\input.json','r') as context:
    data=context.read()
    properties=json.loads(data)
    db_variables = {
        "mysql":{
           "host":properties["db"]["mysql"]["host"],
           "db_type":properties["db"]["mysql"]["db_type"],
           "username":properties["db"]["mysql"]["credentials"]["username"],
           "password":properties["db"]["mysql"]["credentials"]["password"],
           "db_name":properties["db"]["mysql"]["db_name"],
           "port":properties["db"]["mysql"]["port"]

        }
    }