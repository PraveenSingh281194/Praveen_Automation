import requests
import json,pyodbc
import pandas as pd
from pathlib import Path 
import configpy as configfile
from configpy import session_get,session_post

session=requests.session()
cookies_jar={}
url1=configfile.url1
response1,cookies_jar=session_get(url1)
url2=configfile.url2
response2,cookies_jar =session_get(url2)
url3=configfile.url3
response3,cookies_jar=session_get(url3)
payload4=configfile.payload
header4=configfile.header
url4=configfile.url4
response4,cookies_jar=session_post(url4,header4,payload4)

url5=configfile.url5
response5,cookies_jar=session_get(url5)
responseurl=requests.request("GET", url5,verify=False)
print('url5')
print(cookies_jar)
print(responseurl.url)
print(response5.status_code)
