import requests,json

session=requests.session()
cookies_jar={}
def session_get(url,header=None,payload=None):
    session.get(url=url,verify=False)
    response=requests.get(url=url,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

def session_post(url,header,payload):
    session.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    response=requests.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

with open(r'C:\Users\Praveen.Singh\Documents\TMS_Swagger\src\config.json','r') as context:
    data=context.read()
    properties=json.loads(data)
    env=properties["env_12_details"]["env"]
    clientid=properties["env_12_details"]["clientid"]
    nonce=properties["env_12_details"]["nonce"]
    redirect_uri=properties["env_12_details"]["redirect_uri"]
    username=properties["credentials"]["username"]
    password=properties["credentials"]["password"]
    options=properties["credentials"]["options"]
    header=properties["header"]
    url1=properties["urls"]["url1"]
    url2=properties["urls"]["url2"]
    url3=properties["urls"]["url3"]
    url4=properties["urls"]["url4"]
    url5=properties["urls"]["url5"]

options['warnBeforePasswordExpired']=True
options['multiOptionalFactorEnroll']=True

def payload_creation():
    payload={
       "password":password,
       "username":username,
       "options":options 
    }
 
    return payload
payload=payload_creation()

def url_split(url:str,env:str):
    url_list=url.split("{env}")
    url = url_list[0] + env + url_list[1]
    return url

def url5_split(url:str,clientid:str,nonce:str,redirect_uri:str,session_token:str,state:str):
    url_list=url.split("{clientid}")
    url_list=url_list[0] + clientid + url_list[1]
    url_list=url_list.split('{nonce}')
    url_list=url_list[0] + nonce + url_list[1]
    url_list=url_list.split('{redirect_uri}')
    url_list=url_list[0] + redirect_uri + url_list[1]
    url_list=url_list.split('{session_token}')
    url_list=url_list[0] + session_token + url_list[1]
    url_list=url_list.split('{state}')
    url_list=url_list[0] + state + url_list[1]
    return url_list


    
if env=='test12':
    clientid='0oa154h4vxthGbCau0h8'
    nonce='gQtMyTRwB4rFcAlYnZcPs7CzgzfgoBh4u44T13qGYWXlz5x1hx5ZWVwVoxXOffzP'
    redirect_uri='https://test12.ewealthmanager.com/authorization/callback'

url1=url_split(url1,'test12')
url2=url_split(url2,'test12')

response2 = requests.request("GET", url2,verify=False)
url=str(response2.url)
state=url.split('=')[-1]
response4 = requests.request("POST", url4, data=json.dumps(payload),headers=header,verify=False)
session_token=json.loads(response4.text)['sessionToken']
url5=url5_split(url5,clientid,nonce,redirect_uri,session_token,state)


# def url5_split(url_list:str,split_list:list):
#     for i in split_list:
#         url_list=url_list.split("{'i'}")
#         url_list=url_list[0] + i + url_list[1]
       
#     print(url_list)
#     return url_list

# payload4={
#   "password": "Test1234t",
#   "username": "SampleAgent2",
#   "options": {
#     "warnBeforePasswordExpired": True,
#     "multiOptionalFactorEnroll": True}}

# header4={'Accept': 'application/json','Content-Type': 'application/json'}


    
# response4 = requests.request("POST", url4, data=json.dumps(payload4),headers=header4,verify=False)
# session_token=json.loads(response4.text)['sessionToken']
# url5=url5_split(url5,clientid,nonce,redirect_uri,session_token,state)
# a=url5


# env='test12'
# url1=f"https://{env}.ewealthmanager.com/eWMLogin/account/login/"
# url2=f"https://{env}.ewealthmanager.com/authorization/callback"
# url3="https://test-login.ewealthmanager.com/login/signout"
# url4="https://test-login.ewealthmanager.com/api/v1/authn"
#url5=f"https://test-login.ewealthmanager.com/oauth2/aus14jen3mw5T6Wls0h8/v1/authorize?client_id={clientid}&nonce={nonce}&redirect_uri={redirect_uri}&response_type=code&sessionToken={session_token}&state={state}&scope=openid"