import requests
import json,pyodbc
import pandas as pd
from pathlib import Path 
session=requests.session()
cookies_jar={}
env='test12'

def session_get(url,header=None,payload=None):
    session.get(url=url,verify=False)
    response=requests.get(url=url,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

def session_post(url,header,payload):
    session.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    response=requests.post(url=url,data=json.dumps(payload),headers=header,verify=False)
    session1_cookies=session.cookies
    for cookie in session1_cookies:
        cookies_jar.update({cookie.name:cookie.value})
    return response,cookies_jar

url1=f"https://{env}.ewealthmanager.com/eWMLogin/account/login/"
response1,cookies_jar=session_get(url1)
print('url1')
print(response1)
print(cookies_jar)

url2=f"https://{env}.ewealthmanager.com/authorization/callback"
response2,cookies_jar =session_get(url2)
url=str(response2.url)
state=url.split('=')[-1]
print('url2')
print(cookies_jar)
print(response2)

url3="https://test-login.ewealthmanager.com/login/signout"
response3,cookies_jar=session_get(url3)
print('url3')
print(response3)
print(cookies_jar)

payload={
  "password": "Test1234t",
  "username": "SampleAgent2",
  "options": {
    "warnBeforePasswordExpired": True,
    "multiOptionalFactorEnroll": True
  }
}
header={'Accept': 'application/json','Content-Type': 'application/json'}

url4="https://test-login.ewealthmanager.com/api/v1/authn"
response4,cookies_jar=session_post(url4,header,payload)
session_token=json.loads(response4.text)['sessionToken']
print('url4')
print(response4)
print(cookies_jar)

url5 = f"https://test-login.ewealthmanager.com/oauth2/aus14jen3mw5T6Wls0h8/v1/authorize?client_id=0oa154h4vxthGbCau0h8&nonce=kdlNKI3sM9FWwhdPq16xF5UTdA6XuropPs3Tf2sdW1NvwjCGfb7OUqLZRUQkDNKr&redirect_uri=https://test12.ewealthmanager.com/authorization/callback&response_type=code&sessionToken={session_token}&state={state}&scope=openid"
response5,cookies_jar=session_get(url5)
print('url5')
print(response5)
print(cookies_jar)
print(response5.url)


#model api hit
modelversionid='AWMCT2'
asofdate='2023-03-15'
header={'Cookie':'FSSESSION='+cookies_jar['FSSESSION']+'; TargetURL=; ASP.NET_SessionId=' + cookies_jar['ASP.NET_SessionId']+'; GFWMSessionId=' + cookies_jar['GFWMSessionId'] +'; ewm_ns='+ cookies_jar['ewm_ns'] + '; website#lang=' + cookies_jar['website#lang']  }

url6=f"https://{env}.ewealthmanager.com/api/strategies/v2/models/{modelversionid}/asofdate/{asofdate}/holdings"
response6 = requests.request("GET", url6,headers=header,verify=False)
print('url6')
# print(response6.text)
# print(response6.status_code)
# print(response6.url)

swagger_data=json.loads(response6.text)
# print(swagger_data)
# print(type(swagger_data))

df = pd.DataFrame.from_records(swagger_data)
df=df.sort_values(by=['cusip','weight'])
print('swaggerdf')
print(df)
print(len)
print(df.columns.tolist())

sql_query=f'''select m.APLID,a.effdt,x.modelversionid,XRefID,SMH.XrefCusip,SMH.Weight FROM [SMI].[dbo].[Model] m JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID WHERE m.APLID = '{modelversionid}' and a.effDt <= '{asofdate}' AND a.StatusCD = 65004  and x.ModelVersionID in (select max(x.modelversionid) FROM [SMI].[dbo].[Model] m JOIN [SMI].[dbo].[ModelVersion] v on m.ModelID = v.ModelID JOIN [SMI].[dbo].[APB_ModelVersion_XRef] x on v.ModelVersionID = x.ModelVersionID JOIN [SMI].[dbo].[APB] a on x.APBID = a.APBID JOIN SMI..SMI_Holding SMH on x.modelversionid = SMH.modelVersionID WHERE m.APLID = '{modelversionid}' and a.effDt <= '{asofdate}' AND a.StatusCD = 65004) order by a.apbid desc, a.effdt desc, x.modelversionid desc, Weight asc'''

def t12ewmbda_conn():
    server_name='t12ewmdba'
    database_name='SMI'
    conn=pyodbc.connect('Driver={SQL Server};'
                        f'Server={server_name};'
                        f'Database={database_name};'
                        'Trusted_Connection=yes;')
    query =sql_query
    df=pd.read_sql_query(query,con=conn)
    return df

sql_df=t12ewmbda_conn()
sqldf_modified=sql_df[['XrefCusip','Weight']]
sqldf_modified=sqldf_modified.rename(columns={'XrefCusip': 'cusip','Weight':'weight'})
sqldf_modified.insert(0, "sleeve", [None]*len(sql_df.index),True)
sqldf_modified=sqldf_modified.sort_values(by=['cusip','weight'])
print('DBdf')
print(sqldf_modified)

reporting_dict=dict()
cusip_list=[]
weight_list=[]

# result list values append based on scenarios
expected_cusip=sqldf_modified['cusip'].values.tolist()
actual_cusip=df['cusip'].values.tolist()

expected_weight=sqldf_modified['weight'].values.tolist()
actual_weight=df['weight'].values.tolist()

for a,b in zip(expected_cusip,actual_cusip):
    cusip_list.append('Pass') if a==b else cusip_list.append('Fail')

for a,b in zip(expected_cusip,actual_cusip):
    weight_list.append('Pass') if a==b else weight_list.append('Fail')
  
reporting_dict.update({'Cusip':df['cusip'].values.tolist(),'swagger_cusip_weight':df['weight'].values.tolist(),'DB_cusip_weight':sqldf_modified['weight'].values.tolist(),'Cusip_result':cusip_list,'Weight_result':weight_list})
report_path=str(Path.home() / "Downloads" /"Model_A_Result.xlsx")
#creating a reporting dataframe and report generation
reporting_df=pd.DataFrame(reporting_dict)
reporting_df.to_excel(report_path)





