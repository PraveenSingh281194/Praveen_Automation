
def nav_data(api_xml_response,id):
    """
    This will return the data required corresponding to the given APL id as argument
    """
    try:
        xml_data = {}
        for t in api_xml_response.findall('taxLotsCustSleevesAccount'):
            for x in t.findall('secTypes'):
                for element in x.findall('security'):
                    xml_data[element.attrib['cusip']] = []
                    for ele in element.findall('taxlot'):
                        dicts = {}
                        dicts['aplid'] = id
                        dicts['shares'] = ele.find('shares').text
                        dicts['sleeve'] = ele.find('sleeve').text
                        dicts['purchDate'] = ele.find('purchDate').text
                        dicts['cost'] = ele.find('cost').text
                        dicts['taxDate'] = ele.find('taxDate').text
                        dicts['value'] = ele.find('value').text
                        dicts['gainLoss'] = ele.find('gainLoss').text
                        dicts['term'] = ele.find('term').text
                        dicts['ticker'] = str(element.attrib['tick'])
                        dicts['cusip'] = str(element.attrib['cusip'])
                        dicts['restriction'] = str(element.attrib['restrc'])
                        dicts['description'] = str(element.attrib['desc'])
                        dicts['secType'] = str(x.attrib['secType'])
                        dicts['actNum'] = str(t.attrib['actNum'])
                        dicts['status'] = str(t.attrib['status'])
                        dicts['custodian'] = str(t.attrib['cust'])
                        dicts['aplTime'] = str(api_xml_response.attrib['aplTime'])
                        dict_copy = dicts.copy()
                        xml_data[element.attrib['cusip']].append(dict_copy)
        return xml_data
    except Exception as e:
        return None