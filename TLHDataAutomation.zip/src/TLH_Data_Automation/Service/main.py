from cgi import test
import functools
import time,multiprocessing,concurrent.futures
from Utils import dbConnection,get_apl_ids_query,getApiResponse,dump_eligible_apl_ids,apiToken,cycle
from Service import navData,wfiData
import pandas as pd
# import requests
# import config
from xml.etree.ElementTree import fromstring
from Utils.logs import testLog

#demo = Logger()
def main_performance_engine():
    # duration_logs_df = pd.DataFrame(columns=['Apl_id','Token','Api_response','Data_processing','Engine_created','Dump_activity'])
    # duration_logs_df = pd.DataFrame(columns=['Apl_id','Token','Api_response','Data_processing','Cycle_duration','records_count'])
    # start_time = time.time()
    # valid_api_response = []
    # not_valid_api_response = []
    testLog("Execution of Code Starts")
    testLog("Execution of Code Starts")
    try:
        conn = dbConnection.create_connection()
    except Exception as e:
        testLog(e)          #here where ever is print insert the logging code with custom message
    # dump_eligible_apl_ids.dump_eligible_apl_ids(conn)
    try:
        query = get_apl_ids_query.apl_ids_query
        apl_query_result_dataframe = pd.read_sql_query(query, conn)
        testLog("Query  for retrieving APL nav ids from DB executed")
    except Exception as e:
        testLog(e)
    try:
        apl_ids = list(apl_query_result_dataframe['AccountAPLID'])
        print(len(apl_ids))
        testLog("Total Number of apl nav ids received from DataBase: {}".format(len(apl_ids)))
    except Exception as e:
        testLog(e)
    # apl_ids = ['AK2TW3',
    # 'AL2GV6',
    # 'AL9EI4',
    # 'AK2U56']
    # try:
    #     bearer_token = apiToken.get_api_token()
    # except Exception as e:
    #     print(e)
    with concurrent.futures.ProcessPoolExecutor(max_workers=16) as executor:
        result = executor.map(cycle.cycle ,apl_ids)

        # for res in result:
        #     print(res)
    # cycle.cycle(apl_ids,bearer_token,valid_api_response,not_valid_api_response,start_time,duration_logs_df)