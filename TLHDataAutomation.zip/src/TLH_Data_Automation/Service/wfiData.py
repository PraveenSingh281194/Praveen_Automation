def wfi_data(api_json_response,id):
    try:
        for i in api_json_response["accountMetadata"].values():
            data = {}
            data[api_json_response["accountMetadata"]["accountAPLID"]] = []
            dicts = {}
            dicts['clientID'] = str(api_json_response["accountMetadata"]["clientID"])
            dicts['advisorAPLID'] = str(api_json_response["accountMetadata"]["advisorAPLID"])
            dicts['smI_IsThirdPartyIMA'] = str(api_json_response["accountMetadata"]["smI_IsThirdPartyIMA"])
            dicts['sleeves'] = api_json_response["accountMetadata"]["sleeves"]
            for j in api_json_response["accountMetadata"]["sleeves"]:
                dicts['sleeves'] = str(j)
            for i in api_json_response["accountHoldings"]:
                dicts['cusip'] = str(i["cusip"])
                dicts['ticker'] = str(i["ticker"])
                dicts['description'] = str(i["description"])
                dicts['securityType'] = str(i["securityType"])
                dicts['quantity'] = str(i["quantity"])
                dicts['holdingGainLossAmount'] = str(i["holdingGainLossAmount"])    
                dicts['holdingProceedsAmount'] = str(i["holdingProceedsAmount"])
            dict_copy = dicts.copy()
            data[api_json_response["accountMetadata"]["accountAPLID"]].append(dict_copy)
        return data
    except Exception as e:
        return None