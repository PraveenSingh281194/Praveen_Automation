import re
import config
import requests
import json
from Utils.logs import testLog

#demo = Logger()
def get_api_token():
    """
    This will return the access token for the api call
    """
    
    api_token_url = config.api_token_url
    api_username = config.api_username
    api_password = config.api_password
    token_req_payload = {'grant_type': 'client_credentials'}                # take data from Json , declare there
    head = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept':'application/json'}               # take data from Json , declare there
    
    try:
        testLog("Request for API Token Raised")
        response = requests.post(api_token_url, data = token_req_payload , auth=(api_username, api_password), headers=head)
        testLog("Response Status Code Received: {}".format(response.status_code))
        token = json.loads(response.text)
        testLog("API token received")
        return token['access_token']

    except Exception as e:
        testLog(str(e))
        return None
    


