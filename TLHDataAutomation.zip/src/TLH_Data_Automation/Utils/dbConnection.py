import sqlalchemy,time,pyodbc
import config
from Utils.logs import testLog
# import pymssql

#demo = Logger()
def create_engine():
    """
    Engine to be created for bulk insertion into database 
    """
    testLog("Database Engine Initiated")
    server_name = config.server_name
    db_name = config.db_name
    con_string = 'mssql+pyodbc://@' + server_name + '/'+ db_name + '?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'           #get this connection string from json file
#/opt/microsoft/msodbcsql17/lib64/libmsodbcsql-17.0.so.1.1
    try:
        engine = sqlalchemy.create_engine(con_string,pool_pre_ping=True)
        testLog("Database Engine Created")
    except Exception as e:
        testLog(str(e))
    return engine

def create_connection():                        
    """
    For establishing connection to database
    """
    # server_name = config.server_name
    # db_name = config.db_name
    # db_conn = pyodbc.connect('Driver={SQL Server};'
    # 'Server={};'
    # 'Database={};'
    # 'Trusted_Connection=yes;').format(str(server_name),str(db_name))
    testLog("Database Connection  Intiated")
    start_time = time.time()
    try:
        # server = '10.23.212.77,1433'
        server = config.server_name
        database = 'TaxHarvest'
        # username = 'DevUser'
        # password = '9SfzgS7Q4k'
        # # fpkt12amdb1
        db_conn = pyodbc.connect('Driver={SQL Server};'
        'Server=%s;'
        'Database=%s;'
        'Trusted_Connection=yes;'% (server,database))



        # db_conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
        # db_conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};''Server=t12ewmdba;''Database=TaxHarvest;''UID=DevUser';'PWD= 9SfzgS7Q4k')
        connection_duration = start_time - time.time()
        testLog("Database Connection established in {} seconds".format(connection_duration))
    except Exception as e:
        testLog("Error in Database Connection : {}".format(e))
    return db_conn
# def create_connection(): 
#     testLog("Database Connection  Intiated")
#     try:
#         db_conn = pymssql.connect(server='t12ewmdba', user='DevUser', password='9SfzgS7Q4k', database='TaxHarvest')
#     except Exception as e:
#         testLog("Error in Database Conenction : {}".format(e))
#     return db_conn

# pymssql.connect(server=<server>, user=<user>, password=<password>, database=<database>)