import requests
import config
from Utils import apiToken
from Utils.logs import testLog
import time
#demo = Logger()

def get_api_response(apl_id,bearer_token):
    """
    This will return the response of the api after getting and verifying from access token
    """
    try:
        # apl_token_start_time = time.time()
        # cache_token = ""
        # if(cache_token == ""):
        #     bearer_token = apiToken.get_api_token()
        # bearer_token = apiToken.get_api_token()
        # testLog("APL token received   in %s seconds" %(time.time()-apl_token_start_time))
        apl_request_start_time = time.time()
        api_response = requests.get(str(config.apl_navigator_url)+apl_id,headers={'Authorization': 'Bearer '+bearer_token,'Ocp-Apim-Subscription-Key': "ae6eec643dd94b21b64f3f492411ae8d"})
        testLog("APL requests receive in %s seconds" %(time.time()-apl_request_start_time))
        return api_response
    except Exception as e:
        testLog(e)
        return None 
    