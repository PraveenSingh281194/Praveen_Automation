# apl_ids_query = """select top 5
# L.AccountID as AccountAPLID,
# L.DTCNO as AccountNumber,
# AT.Name,
# L.CustodianCode,
# case
# when L.FundedDT is not null and L.CloseDate = 0 then 1
# else 0
# end as IsFunded,
# case
# when PM.SupportsCustomModel = 1 then 'MSA' -- is custom model / data coming from UMA
# when PM.SupportsCustomModel = 0 then 'SSA'
# end as AccountType,
# L.ModelCode,
# M.IsThirdPartyIMA, -- HNW = 1, non-HNW = 0
# THT.Value as TradeUniverse,
# L.AgentID
# from AM..account_L L
# join SMI.dbo.Model M on L.ModelCode = M.APLID
# join SMI.dbo.TaxHarvestingExportTemplateFileEnum THT on M.TaxHarvestingExportTemplateFileEV = THT.Id
# join Platform.dbo.Model PM on L.ModelCode = PM.APLID and L.CustodianCode = PM.Custodian_ID
# join Platform.dbo.AccountType AT on L.AccountType = AT.ID
# where L.CloseDate = '0' -- TLH eligible status (account is funded - part 1 of 3)
# and L.TerminationDate = '99999999' -- TLH eligible status (account is funded - part 2 of 3)
# and L.FundedDT is not null -- TLH eligible status (account is funded - part 3 of 3)
# and L.AccountType in (3, 4, 5, 6, 8, 9, 10, 11, 13, 15, 16, 28, 29, 31, 32, 33, 41, 42, 43, 44, 45) -- TLH eligible registrations
# and L.CustodianCode in ('GNW', 'FID', 'PRS', 'TDA') -- TLH eligible custodians
# and L.RR in (1, 2, 3, 4, 5, 7, 8, 11, 13, 14, 15, 16, 17, 75) -- TLH eligible status (not suspended)
# and M.IsAdvisorDirectedTaxHarvestEligible = 1 -- TLH eligible model
# and M.IsThirdPartyIMA = 0 -- non-HNW (both HNW & non-HNW eligible for Wizard / only non-HNW eligible for Tool)
# order by PM.SupportsCustomModel"""

# apl_ids_query = """ select distinct AccountAPLID FROM [TaxHarvest].[dbo].[TLH_Eligible_Accounts] where CustodianCode = 'GNW'
# and AccountAPLID not in (SELECT distinct aplid
#   FROM [TaxHarvest].[dbo].[TestAPLNavIDs])"""

apl_ids_query = """select top 2800 AccountAPLID FROM [TaxHarvest].[dbo].[TLH_Eligible_Accounts]"""

eligible_apl_ids_query = """-- CREATE TEMP TABLE: all SMI models latest model version & APB as of today
              set nocount on
              select M.ModelID,
                             Max (A.APBID) as MaxAPB,
                             Max (MV.ModelVersionID) as MaxMV
              into #MaxMV
              from SMI..Model M
                             left join SMI..ModelVersion MV on M.ModelID = MV.ModelID
                             left join SMI..APB_ModelVersion_XRef X on MV.ModelVersionID = X.ModelVersionID
                             left join SMI..APB A on X.APBID = A.APBID
              where A.StatusCD = 65004 -- approved APB
                             and CAST(a.EffDT AS DATE) <= GETDATE()
              group by M.ModelID
              order by M.ModelID



-- CREATE TEMP TABLE: latest allocations for all models that hold securities (security/cusip weights)
              select
                             MV.ModelVersionID,
                             M.ModelID,
                             M.APLID as Model_APLID,
                             M.SleeveAPLID as Model_SleeveAPLID,
                             M.IsAdvisorDirectedTaxHarvestEligible as Model_IsTLHEligible,
                             M.IsFlattened as Model_IsFlattened,
                             S.Ticker,
                             H.XRefCUSIP as Cusip,
                             H.Weight as CusipWeight,
                             S.IssueTypeCode,
                             M.TaxHarvestingExportTemplateFileEV as TradeUniverse,
                             M.IsThirdPartyIMA
              into #CusipWeights
              from SMI..model M
                             left join SMI..ModelVersion MV on M.ModelID = MV.ModelID
                             left join SMI..SMI_Holding H on MV.ModelVersionID = H.ModelVersionID
                             left join SMI..APB_ModelVersion_XRef X on MV.ModelVersionID = X.ModelVersionID
                             left join SMI..APB A on X.APBID = A.APBID
                             join #MaxMV MaxMV on MV.ModelVersionID = MaxMV.MaxMV and A.APBID = MaxMV.MaxAPB
                             join AM..Securities S on H.XRefCusip = S.CusipNo
              where H.XRefTypeCD = 61000 -- security holding
              order by M.APLID



-- CREATE TEMP TABLE: latest allocations for all models that hold sleeves (sleeve weights)
              select 
                             MV.ModelVersionID,
                             M.ModelID,
                             M.APLID Model_APLID,
                             M.SleeveAPLID as Model_SleeveAPLID,
                             M.IsAdvisorDirectedTaxHarvestEligible as Model_IsTLHEligible,
                             M.IsFlattened as Model_IsFlattened,
                             M2.ModelID as Sleeve_ModelID,
                             M2.APLID as Sleeve_APLID,
                             M2.SleeveAPLID as Sleeve_SleeveAPLID,
                             M2.IsAdvisorDirectedTaxHarvestEligible as Sleeve_IsTLHEligible,
                             M2.IsFlattened as Sleeve_IsFlattened,
                             H.Weight as SleeveWeight,
                             M.TaxHarvestingExportTemplateFileEV as TradeUniverse,
                             M.IsThirdPartyIMA as Model_IsThirdPartyIMA,
                             M2.IsThirdPartyIMA as Sleeve_IsThirdPartyIMA
              into #SleeveWeights
              from SMI..model M
                             left join SMI..ModelVersion MV on M.ModelID = MV.ModelID
                             left join SMI..SMI_Holding H on MV.ModelVersionID = H.ModelVersionID
                             left join SMI..Model M2 on H.XRefID = M2.ModelID
                             left join SMI..APB_ModelVersion_XRef X on MV.ModelVersionID = X.ModelVersionID
                             left join SMI..APB A on X.APBID = A.APBID
                             join #MaxMV MaxMV on MV.ModelVersionID = MaxMV.MaxMV and A.APBID = MaxMV.MaxAPB
              where H.XRefTypeCD = 61001 -- model holding
              order by M.ModelID, M2.ModelID



-- CREATE TEMP TABLE: sleeved models that are TLH eligible & have at least one TLH eligible sleeve
              select distinct Model_APLID
              into #SleeveWeights_TLHEligibleModel
              from #SleeveWeights
              where Model_IsTLHEligible = 1
                             and Sleeve_IsTLHEligible = 1


-- CREATE TEMP TABLE: sleeved models that are TLH eligible & have at least one TLH eligible sleeve + their holdings
              select SW.*
              into #SleeveWeights_TLHEligibleModelWeights
              from #SleeveWeights SW
                             join #SleeveWeights_TLHEligibleModel SWE on SW.Model_APLID = SWE.Model_APLID



-- CREATE TEMP TABLE: latest allocations for custom models (custom model sleeve weights)
              select
                             L.CustomModelID,
                             L.AccountID as AccountAPLID,
                             L.ModelCode as Model_APLID,
                             M.SleeveAPLID as Model_SleeveAPLID,
                             M.IsAdvisorDirectedTaxHarvestEligible as Model_IsTLHEligible,
                             M.IsFlattened as Model_IsFlattened,
                             H.HoldingID as Sleeve_APLID,
                             M2.SleeveAPLID as Sleeve_SleeveAPLID,
                             M2.IsAdvisorDirectedTaxHarvestEligible as Sleeve_IsTLHEligible,
                             M2.IsFlattened as Sleeve_IsFlattened,
                             H.Allocation as SleeveWeight,
                             M.TaxHarvestingExportTemplateFileEV as TradeUniverse,
                             M.IsThirdPartyIMA as Model_IsThirdPartyIMA,
                             M2.IsThirdPartyIMA as Sleeve_IsThirdPartyIMA
              into #CustomModelSleeveWeights
              from AM..account_L L
                             join SMI..Model M on L.ModelCode = M.APLID
                             join UMA.dbo.ModelVersionAccount MVA on L.CustomModelID = MVA.ModelVersionAccountID
                             join UMA.dbo.ModelVersionHolding H on MVA.ModelVersionID = H.ModelVersionID 
                             join SMI..Model M2 on H.HoldingID = M2.APLID
              order by L.AccountID, H.HoldingID
              -- ask Nate - are all CustomModelID's in AM the active MV? (so filtering for 202004 status in UMA..ModelVersoin status is unneccesary)?



-- CREATE TEMP TABLE: custom models that are TLH eligible & have at least one TLH eligible sleeve
              select distinct CustomModelID, AccountAPLID
              into #CustomModelSleeveWeights_TLHEligibleModel
              from #CustomModelSleeveWeights
              where Model_IsTLHEligible = 1
                             and Sleeve_IsTLHEligible = 1
              order by CustomModelID


-- CREATE TEMP TABLE: custom models that are TLH eligible & have at least one TLH eligible sleeve + their holdings
              select CMSW.*
              into #CustomModelSleeveWeights_TLHEligibleModelWeights
              from #CustomModelSleeveWeights CMSW
                             join #CustomModelSleeveWeights_TLHEligibleModel CMSWE on CMSW.CustomModelID = CMSWE.CustomModelID



-- CREATE TEMP TABLE: TLH eligible accounts
              select 
                             L.AccountID as AccountAPLID,
                             L.DTCNO as AccountNumber,
                             L.CustodianCode,
                             L.RR,
                             Case
                                           when L.RR in (1, 2, 3, 4, 5, 7, 8, 11, 13, 14, 15, 16, 17, 75) then '0'
                                           else '1'
                                           end as 'IsSuspended',
                             Case
                                           when L.CloseDate = 0 and L.TerminationDate = '99999999' then '0'
                                           else '1'
                                           end as 'IsClosed',
                             Case when L.FundedDT is null  then '0'
                                           else '1'
                                           end as 'IsFunded',
                             L.AccountType,
                             AT.Name as AccountTypeName,
                             L.ModelCode as Model_APLID,
                             M.SleeveAPLID as Model_SleeveAPLID,
                             PM.SupportsCustomModel,
                             L.CustomModelID,
                             M.IsAdvisorDirectedTaxHarvestEligible as Model_IsTLHEligible,
                             THT.Value as TradeUniverse,
                             M.IsThirdPartyIMA, -- HNW = 1, non-HNW = 0
                             L.AgentID,
                             L.CloseDate,
                             L.TerminationDate,
                             L.FundedDT
              into #TLHEligibleAccounts
              from AM..account_L L 
                             join SMI.dbo.Model M on L.ModelCode = M.APLID
                             left join SMI.dbo.TaxHarvestingExportTemplateFileEnum THT on M.TaxHarvestingExportTemplateFileEV = THT.Id
                             join Platform.dbo.Model PM on L.ModelCode = PM.APLID and L.CustodianCode = PM.Custodian_ID
                             join Platform..AccountType AT on L.AccountType = AT.ID
              where L.CloseDate = '0' -- TLH eligible status (account is funded - part 1 of 3)
                             and L.TerminationDate = '99999999' -- TLH eligible status (account is funded - part 2 of 3)
                             and L.FundedDT is not null -- TLH eligible status (account is funded - part 3 of 3)
                             and L.AccountType in (3, 4, 5, 6, 8, 9, 10, 11, 13, 15, 16, 28, 29, 31, 32, 33, 41, 42, 43, 44, 45) -- TLH eligible registrations
                             and L.CustodianCode in ('GNW', 'FID', 'PRS', 'TDA') -- TLH eligible custodians
                             and L.RR in (1, 2, 3, 4, 5, 7, 8, 11, 13, 14, 15, 16, 17, 75) -- TLH eligible status (not suspended)
                             and M.IsAdvisorDirectedTaxHarvestEligible = 1 -- TLH eligible model
                             order by L.AccountID, L.ModelCode



-- CREATE TEMP TABLE: combine all holding types (cusips, sleeves, custom sleeves) for TLH eligible accounts
              select *
              into #TLHEligibleAccountsAndHoldings
              from
                             (

                             ---- MODELS THAT HOLD CUSIPS
                             select
                                           EA.AccountAPLID,
                                           CW.Model_APLID,
                                           '' as Sleeve_APLID,
                                           '' as SleeveWeight,
                                           '' as Sleeve2_APLID,
                                           '' as Sleeve2Weight,
                                           CW.Cusip,
                                           CW.CusipWeight,
                                           CW.IssueTypeCode,
                                           CW.Model_IsFlattened,
                                           CW.Model_IsTLHEligible,
                                           '' as Sleeve_IsTLHEligible,
                                           '' as Sleeve_IsFlattened,
                                           '' as Sleeve2_IsTLHEligible,
                                           --'' as Sleeve2_IsFlattened,
                                           'CusipHolding' as HoldingType,
                                           EA.IsThirdPartyIMA
                             from #TLHEligibleAccounts EA
                             join #CusipWeights CW on EA.Model_APLID = CW.Model_APLID
                             where EA.SupportsCustomModel = 0 -- filter out MSA's (SMI has these 100% allocated to a cash cusip)

              union

                             ---- MODELS THAT HOLD SLEEVES
                             select
                                           EA.AccountAPLID,
                                           SW.Model_APLID,
                                           SW.Sleeve_APLID,
                                           SW.SleeveWeight,
                                           '' as Sleeve2_APLID,
                                           '' as Sleeve2Weight,
                                           CW.Cusip,
                                           CW.CusipWeight,
                                           CW.IssueTypeCode,
                                           SW.Model_IsFlattened,
                                           SW.Model_IsTLHEligible,
                                           SW.Sleeve_IsTLHEligible,
                                           SW.Sleeve_IsFlattened,
                                           '' as Sleeve2_IsTLHEligible,
                                           --'' as Sleeve2_IsFlattened,
                                           'SleeveHolding' as HoldingType,
                                           EA.IsThirdPartyIMA
                             from #TLHEligibleAccounts EA
                             join #SleeveWeights_TLHEligibleModelWeights SW on EA.Model_APLID = SW.Model_APLID
                             left join #CusipWeights CW on SW.Sleeve_APLID = CW.Model_APLID

              union 

                             ---- CUSTOM MODELS
                             select 
                                           EA.AccountAPLID,
                                           CMW.Model_APLID,
                                           CMW.Sleeve_APLID,
                                           CMW.SleeveWeight,
                                           SW.Sleeve_APLID as Sleeve2_APLID,
                                           SW.SleeveWeight as Sleeve2Weight,
                                           Case
                                                          When CMW.Sleeve_IsFlattened = 1 or SW.Sleeve_APLID is not null then CW2.Cusip -- 'or' added to handle models not marked as flattened that should be (ex. UVSTLL)
                                                          Else CW.Cusip
                                                          End as 'Cusip',
                                           Case
                                                          When CMW.Sleeve_IsFlattened = 1  or SW.Sleeve_APLID is not null then CW2.CusipWeight -- 'or' added to handle models not marked as flattened that should be (ex. UVSTLL)
                                                          Else CW.CusipWeight
                                                          End as 'CusipWeight',
                                           Case
                                                          When CMW.Sleeve_IsFlattened = 1  or SW.Sleeve_APLID is not null then CW2.IssueTypeCode -- 'or' added to handle models not marked as flattened that should be (ex. UVSTLL)
                                                          Else CW.IssueTypeCode
                                                          End as 'IssueTypeCode',
                                           CMW.Model_IsFlattened,
                                           CMW.Model_IsTLHEligible,
                                           CMW.Sleeve_IsTLHEligible,
                                           CMW.Sleeve_IsFlattened,
                                           SW.Sleeve_IsTLHEligible as Sleeve2_IsTLHEligible,
                                           --SW.Sleeve_IsFlattened as Sleeve2_IsFlattened,
                                           'CustomHolding' as HoldingType,
                                           EA.IsThirdPartyIMA
                             from #TLHEligibleAccounts EA
                             join #CustomModelSleeveWeights_TLHEligibleModelWeights CMW on EA.CustomModelID = CMW.CustomModelID
                             left join #CusipWeights CW on CMW.Sleeve_APLID = CW.Model_APLID -- non-flat models
                             left join #SleeveWeights SW on CMW.Sleeve_APLID = SW.Model_APLID -- flat models sleeves
                             left join #CusipWeights CW2 on SW.Sleeve_APLID = CW2.Model_APLID -- flat model cusips
                             --order by HoldingType, AccountAPLID
                             ) as a



-- identify COMMON HOLDINGS (basic): STEP 1 - cusip count of eligible holdings
              -- non-HNW
              select AccountAPLID, CUSIP, count(*) CusipCount
              into #EligibleHoldingCount_HNWandNonHNW
              from #TLHEligibleAccountsAndHoldings
              where IsThirdPartyIMA = 0
                             and IssueTypeCode in (28, 37, 210) -- TLH eligible issue types for non-HNW accounts
              group by AccountAPLID, CUSIP
              union
              -- HNW
              select AccountAPLID, CUSIP, count(*) CusipCount
              from #TLHEligibleAccountsAndHoldings
              where IsThirdPartyIMA = 1
                             and IssueTypeCode <> 1 -- TLH eligible issue types for HNW accounts
              group by AccountAPLID, CUSIP
              order by AccountAPLID, CUSIP


-- identify COMMON HOLDINGS (basic): STEP 2.1 - identify accounts with common holdings (ACCOUNT LEVEL)
              select distinct AccountAPLID
              into #TLHEligibleAccountsWithCommonHoldings_account
              from #EligibleHoldingCount_HNWandNonHNW
              where CusipCount > 1
              order by AccountAPLID


-- identify COMMON HOLDINGS (basic): STEP 2.2 - identify accounts with common holdings (ACCOUNT & CUSIP LEVEL)
              select distinct AccountAPLID, CUSIP
              into #TLHEligibleAccountsWithCommonHoldings_cusip
              from #EligibleHoldingCount_HNWandNonHNW
              where CusipCount > 1
              order by AccountAPLID




-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 1 - cusip count of eligible holdings & sleeve elig
              -- non-HNW
              select AccountAPLID, Sleeve_IsTLHEligible, CUSIP, count(*) CusipCount
              into #EligibleHoldingCount_HNWandNonHNW_WithSleeveElig
              from #TLHEligibleAccountsAndHoldings
              where HoldingType <> 'CusipHolding'
                             and IsThirdPartyIMA = 0
                             and IssueTypeCode in (28, 37, 210) -- TLH eligible issue types for non-HNW accounts
              group by AccountAPLID, Sleeve_IsTLHEligible, CUSIP
              union
              -- HNW
              select AccountAPLID, Sleeve_IsTLHEligible, CUSIP, count(*) CusipCount
              from #TLHEligibleAccountsAndHoldings
              where HoldingType <> 'CusipHolding'
                             and IsThirdPartyIMA = 1
                             and IssueTypeCode <> 1 -- TLH eligible issue types for HNW accounts
              group by AccountAPLID, Sleeve_IsTLHEligible, CUSIP
              order by AccountAPLID, Sleeve_IsTLHEligible, CUSIP



-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 2.1 - identify common holdings WITHIN ELIGIBLE sleeve (ACCOUNT LEVEL)
              select distinct AccountAPLID
              into #TLHEligibleAccountsWithCommonHoldingsWithinEligSleeve_account
              from #EligibleHoldingCount_HNWandNonHNW_WithSleeveElig
              where CusipCount > 1
                             and Sleeve_IsTLHEligible = 1


-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 2.2 - identify common holdings WITHIN ELIGIBLE sleeve (ACCOUNT & CUSIP LEVEL)
              select distinct AccountAPLID, Cusip
              into #TLHEligibleAccountsWithCommonHoldingsWithinEligSleeve_cusip
              from #EligibleHoldingCount_HNWandNonHNW_WithSleeveElig
              where CusipCount > 1
                             and Sleeve_IsTLHEligible = 1


-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 3.1 - identify common holdings WITHIN IN-ELIGIBLE sleeve (ACCOUNT LEVEL)
              select distinct AccountAPLID
              into #TLHEligibleAccountsWithCommonHoldingsWithinIneligSleeve_account
              from #EligibleHoldingCount_HNWandNonHNW_WithSleeveElig
              where CusipCount > 1
                             and Sleeve_IsTLHEligible = 0


-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 3.2 - identify common holdings WITHIN IN-ELIGIBLE sleeve (ACCOUNT & CUSIP LEVEL)
              select distinct AccountAPLID, Cusip
              into #TLHEligibleAccountsWithCommonHoldingsWithinIneligSleeve_cusip
              from #EligibleHoldingCount_HNWandNonHNW_WithSleeveElig
              where CusipCount > 1
                             and Sleeve_IsTLHEligible = 0



-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 4.0 - identify common holdings ACROSS elig & inelig sleeve
              select distinct AccountAPLID, Cusip, Count(*) as CusipCount
              into #EligibleHoldingCount_HNWandNonHNW_CountSleeveElig
              from #EligibleHoldingCount_HNWandNonHNW_WithSleeveElig
              group by AccountAPLID, Cusip



-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 4.1 - identify common holdings ACROSS elig & inelig sleeve (ACCOUNT LEVEL)
              select distinct AccountAPLID
              into #TLHEligibleAccountsWithCommonHoldingsAcrossEligAndIneligSleeves_account
              from #EligibleHoldingCount_HNWandNonHNW_CountSleeveElig
              where CusipCount > 1
              order by AccountAPLID


-- identify COMMON HOLDINGS (detailed scenarios for sleeved models): STEP 4.2 - identify common holdings ACROSS elig & inelig sleeve (ACCOUNT & CUSIP LEVEL)
              select distinct AccountAPLID, Cusip
              into #TLHEligibleAccountsWithCommonHoldingsAcrossEligAndIneligSleeves_cusip
              from #EligibleHoldingCount_HNWandNonHNW_CountSleeveElig
              where CusipCount > 1
              order by AccountAPLID, Cusip



-- identify ACCOUNTS W/ FLATTENED MODELS
              select distinct AccountAPLID
              into #TLHEligibleAccountsWithFlattened
              from #TLHEligibleAccountsAndHoldings
              where Sleeve_IsFlattened = 1




-- DETAILED HOLDINGS REPORT WITH SCENARIOS (to support analysis) 
              select EA.*,
                             Case      
                                           When EA.Sleeve_APLID = '' then 'No'
                                           Else 'Yes'
                                           End as 'HasSleeves',
                             Case      
                                           When CH.AccountAPLID is null then 'No'
                                           Else 'Yes'
                                           End as 'IsCommonHolding',
                             Case      
                                           When CHE.AccountAPLID is not null then 'Yes'
                                           Else 'No'
                                           End as 'IsCommonHoldingWithinEligSleeves',
                             Case      
                                           When CHI.AccountAPLID is not null then 'Yes'
                                           Else 'No'
                                           End as 'IsCommonHoldingWithinIneligSleeves',
                             Case      
                                           When CHEI.AccountAPLID is not null then 'Yes'
                                           Else 'No'
                                           End as 'IsCommonHoldingAcrossEligAndIneligSleeves'
              into #TLHEligbleAccountsAndHoldingsWithScenarios
              from #TLHEligibleAccountsAndHoldings EA
                             left join #TLHEligibleAccountsWithCommonHoldings_cusip CH  on EA.AccountAPLID = CH.AccountAPLID and EA.Cusip = CH.Cusip
                             left join #TLHEligibleAccountsWithCommonHoldingsWithinEligSleeve_cusip CHE on EA.AccountAPLID = CHE.AccountAPLID and EA.Cusip = CHE.Cusip
                             left join #TLHEligibleAccountsWithCommonHoldingsWithinIneligSleeve_cusip CHI on EA.AccountAPLID = CHI.AccountAPLID  and EA.Cusip = CHI.Cusip
                             left join #TLHEligibleAccountsWithCommonHoldingsAcrossEligAndIneligSleeves_cusip CHEI on EA.AccountAPLID = CHEI.AccountAPLID and EA.Cusip = CHEI.Cusip
              order by EA.AccountAPLID, CH.Cusip




-- TLH ELIGIBLE ACCOUNT LIST WITH SCENARIOS
              select distinct
                             EA.AccountAPLID,
                             EA.AccountNumber,
                             EA.CustodianCode,
                             EA.AccountTypeName,
                             EA.SupportsCustomModel, -- 0 = SSA, 1 = MSA & Custom models
                             EA.IsThirdPartyIMA, -- HNW = 1, non-HNW = 0
                             EA.Model_APLID,
                             EA.Model_IsTLHEligible,
                             EA.TradeUniverse,
                             EA.AgentID,
                             Case      
                                           When EAH.Sleeve_APLID = '' then 'No'
                                           Else 'Yes'
                                           End as 'HasSleeves',
                             Case      
                                           When ACH.AccountAPLID is null then 'No'
                                           Else 'Yes'
                                           End as 'HasCommonHoldings',
                             Case      
                                           When CHE.AccountAPLID is not null then 'Yes'
                                           Else 'No'
                                           End as 'HasCommonHoldingWithinEligSleeves',
                             Case      
                                           When CHI.AccountAPLID is not null then 'Yes'
                                           Else 'No'
                                           End as 'HasCommonHoldingWithinIneligSleeves',
                             Case      
                                           When CHEI.AccountAPLID is not null then 'Yes'
                                           Else 'No'
                                           End as 'HasCommonHoldingAcrossEligAndIneligSleeves',
                             Case      
                                           When F.AccountAPLID is not null then 'Yes'
                                           Else 'No'
                                           End as 'HasFlattenedModel',
                             EA.IsClosed,
                             EA.IsFunded,
                             EA.RR,
                             EA.IsSuspended
              from #TLHEligibleAccounts EA
              join #TLHEligbleAccountsAndHoldingsWithScenarios EAH on EA.AccountAPLID = EAH.AccountAPLID
              left join #TLHEligibleAccountsWithCommonHoldings_account ACH on EA.AccountAPLID = ACH.AccountAPLID
              left join #TLHEligibleAccountsWithFlattened F on EA.AccountAPLID = F.AccountAPLID
              left join #TLHEligibleAccountsWithCommonHoldingsWithinEligSleeve_account CHE on EA.AccountAPLID = CHE.AccountAPLID
              left join #TLHEligibleAccountsWithCommonHoldingsWithinIneligSleeve_account CHI on EA.AccountAPLID = CHI.AccountAPLID
              left join #TLHEligibleAccountsWithCommonHoldingsAcrossEligAndIneligSleeves_account CHEI on EA.AccountAPLID = CHEI.AccountAPLID
              order by EA.AccountAPLID, EA.SupportsCustomModel, HasSleeves, HasFlattenedModel, HasCommonHoldings
"""