from Utils import get_apl_ids_query,dbConnection
from Utils.logs import testLog

import pandas as pd

def dump_eligible_apl_ids(conn):
    try:
        query = get_apl_ids_query.eligible_apl_ids_query
        df = pd.read_sql_query(query,conn)
        testLog("Data dumped in TLH_Eligible_Accounts")
    except Exception as e:
        print(e)
    try:
        engine = dbConnection.create_engine()
    except Exception as e:
        print(e)
    print(df.head())
    try:
        data_added = df.to_sql('TLH_Eligible_Accounts', con=engine , if_exists = 'append' , index = False)
    
        if data_added==0:
            testLog("Error no data added in TLH_Eligible_Accounts")
        else:
            testLog("Data added in Table TLH_Eligible_Accounts")
            testLog("Number of Records added in TLH_Eligible_Accounts are : %s"%len(df))# get the DB name from JSON for bulk insertion of data
    except Exception as e:
        testLog(e)