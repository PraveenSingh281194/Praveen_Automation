from Utils.logs import testLog
from Utils import getApiResponse,apiToken,dbConnection
from Service import navData

import pandas as pd
from xml.etree.ElementTree import fromstring
import time

# def cycle(apl_ids,bearer_token,valid_api_response,not_valid_api_response,start_time,duration_logs_df):
def cycle(id):
        import runner
        # bearer_token = bearer_token
        # latest_api_hit_time = time.time()
    # for id in apl_ids:
        # cycle_start_time = time.time()
        df = pd.DataFrame()
        try:
            bearer_token = apiToken.get_api_token()
        except Exception as e:
            print(e)
        # if(time.time()-latest_api_hit_time>3590):
        #     apl_token_start_time = time.time()
        #     bearer_token = apiToken.get_api_token()
        #     api_token_time_duration = time.time() - apl_token_start_time
        #     latest_api_hit_time = time.time()                 #time.time()
        #     testLog("APL token received   in %s seconds" %(api_token_time_duration))
        # else:
        #     api_token_time_duration = 0
        # try:
        #     engine = dbConnection.create_engine()
        # except Exception as e:
        #     print(e)
        
        # apl_token_start_time = time.time()
        # bearer_token = apiToken.get_api_token()
        # testLog("APL token received   in %s seconds" %(time.time()-apl_token_start_time))
    
    
        # api_response_start_time = time.time()
        api_response = getApiResponse.get_api_response(id,bearer_token)
        testLog("Received {0} for API nav id {1}".format(api_response,id))
        # api_response_time_duration = time.time() - api_response_start_time
    # except Exception as e:
    #     testLog(e)
        if str(api_response.status_code) == '200':
            # try:
            #     valid_api_response.append(id)                   # for getting count we can use len() to get count when and where we needed.
            # except Exception as e:
            #     print(e)
            try:
                # data_processing_start_time = time.time()
                api_xml_response = fromstring(api_response.json())
                testLog("Api Xml Response received")
            except Exception as e:
                testLog(e)
            try:
                api_xml_data = navData.nav_data(api_xml_response,id)
                testLog("Api Xml Data received")
            except Exception as e:
                testLog(e)
            for r in api_xml_data.keys():
                try:
                    df = df.append(pd.DataFrame.from_dict(api_xml_data[r]))                  # here is one problem data is there but it is not appending into the dataframe
                except Exception as e:
                    testLog(e)
        else:
            runner.miss_list.append(id)
        return(df)
            # data_processing_time_duration = time.time() - data_processing_start_time
            

        # else:
        #     try:
        #         not_valid_api_response.append(id)  
                
        #     except Exception as e:
        #         testLog(e)

        
        # try:
        #     data_added = df.to_sql('TestAPLNavIDs', con=engine , if_exists = 'append' , index = False) 
        #     if data_added==0:
        #         testLog("Error no data added in TestNav")
        #     else:
        #         testLog("Data added in Table TestNav")
        #         testLog("Number of Records added in TestNav are : %s"%len(df))# get the DB name from JSON for bulk insertion of data
        # except Exception as e:

        #     testLog(e)
        # cycle_duration_time = time.time() - cycle_start_time
    #     duration_logs_df = duration_logs_df.append({'Apl_id':id,'Token':api_token_time_duration,'Api_response':api_response_time_duration,'Data_processing':data_processing_time_duration,'Cycle_duration':cycle_duration_time,'records_count':len(df)},ignore_index=True)
    # testLog("Number of API Nav ids having no valid response :{}".format(len(not_valid_api_response)))                 # for getting count we can use len() to get count when and where we needed.
    # testLog("Code Executed in %s seconds" %(time.time()-start_time)) 
    # print(duration_logs_df)
    # duration_logs_df.to_csv('duration_logs.csv')

 
