from Service import main
import pandas as pd

if __name__=='__main__':
    miss_list = []
    main.main_performance_engine()
    miss_df = pd.DataFrame(miss_list,columns=['apl_ids'])
    miss_df.to_csv('TLH_miss.csv')