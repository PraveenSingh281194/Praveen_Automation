import json
# from Config import config

import os

cur_path = os.path.dirname(__file__)
file_path = cur_path+"/Config/config.json"

with open(file_path, 'r') as f:
    data = f.read()
    properties = json.loads(data)
    server_name = properties['SERVER_NAME']
    db_name = properties['DB_NAME']
    apl_navigator_url = properties['GET_API_NAVIGATOR']
    api_token_url = properties['API_TOKEN_URL']
    api_username = properties['API_USERNAME']
    api_password = properties['API_PASSWORD']

    