import pandas as pd
from Services import _CreateSetting
from Framework.Utils._PublishFile import Publish_File

# accounts = []
# result = []
# invalid_accounts = []
# tax_sensitivity_dict = {'veryhigh':'VeryHigh','medium':'Medium','high':'High','low':'Low'}


def Create_Setting():
    accounts = []
    df = pd.read_excel(r'C:\Users\Paritosh.Sharma\Documents\repos\csv_to_json\TMSSettings_03142023.xlsx',sheet_name = 'SampleDataSheet314')
    full_list = list(df.groupby('accountId'))
    for account in full_list:
        accounts.append(account[0])

    # _CreateSetting.Create_Add_Settings_Api_Body(full_list)

    invalid_accounts = _CreateSetting.Create_Settings(accounts = accounts,full_list=full_list)
    publish_file=  Publish_File()
    publish_file.Publish_Json_File(content = invalid_accounts)

    invalid_accounts_df = pd.DataFrame(columns = ['account','status code','reason'])
    for invalid_entry in invalid_accounts:
        invalid_accounts_df = invalid_accounts_df.append({'account':invalid_entry['account'],'status code':invalid_entry['status_code'],'reason':str(invalid_entry['reason'])},ignore_index=True)
    invalid_accounts_df.to_csv('Output.csv')

def Approve_Settings():
    approve_response = _CreateSetting.Approve_Settings()
    publish_file=  Publish_File()
    publish_file.Publish_Json_File(content = approve_response[1],filename='create_settings_invalid_accounts.json')
    publish_file.Publish_Json_File(content = approve_response[0],filename='approve_settings_invalid_ids.json')


if __name__=="__main__":
    Create_Setting()
    Approve_Settings()