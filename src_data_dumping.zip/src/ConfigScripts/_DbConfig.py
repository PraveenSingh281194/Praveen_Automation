import json,os

cur_path = os.path.dirname(__file__)
file_path = "src\Config\_DbConfig.json"

with open(file_path, 'r') as f:
    data = f.read()
    properties = json.loads(data)
    db_variables = {
        'TMS' : {
            'Test10' : {
                'Server' : properties['TMS']['Test10']['Server'],
                'Port' : properties['TMS']['Test10']['Port'],
                'Db' : properties['TMS']['Test10']['Db'],
                'Username' : properties['TMS']['Test10']['Username'],
                'Password' : properties['TMS']['Test10']['Password']
            }
        }
    }