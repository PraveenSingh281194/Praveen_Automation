import json

class Publish_File():
    def Publish_Json_File(self,content,filename:str = 'Output.json'):
        with open(filename, "w") as outfile:
            outfile.write(json.dumps(content,indent = 2))
            # handle path issue for a particular location, pass location as parameter.

    def Publish_Csv_File(self):
        print()

    def Publish_Excel_File(self):
        print()
        # if excel is existing then flag is raised and add a sheet to the existing excel file

    def Text_File(self):
        print()
