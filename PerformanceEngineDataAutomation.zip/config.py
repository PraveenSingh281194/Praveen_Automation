import json
# from Config import config

import os

cur_path = os.path.dirname(__file__)
file_path = cur_path+"\Config\config.json"

with open(file_path, 'r') as f:
    data = f.read()
    properties = json.loads(data)
    server_name = properties['SERVER_NAME']
    db_name = properties['DB_NAME']
    apl_navigator_url = properties['GET_API_NAVIGATOR']
    api_token_url = properties['API_TOKEN_URL']
    api_username = properties['API_USERNAME']
    api_password = properties['API_PASSWORD']
    in_file_path = properties['INPUT_FILE_PATH']
    sm_file_path = properties['INPUT_SUMMARY_FILE_PATH']
    in_file_extension = properties['FILE_EXTENSION']
    in_file_prefix = properties['INPUT_FILE_PREFIX']
    scenario_list = properties['SCENARIO_LIST']
    scenario_reason = properties['SCENARIO_REASON']
    account_dataframe_column_list = properties['ACCOUNT_DATAFRAME_COLUMN_LIST']
    accounts_file_path = properties['ACCOUNTS_FILE_PATH']
    year_value = properties['YEAR_VALUE']
    sip_year_value = properties['SIP_YEAR_VALUE']
    float_5year_value = properties['FLOAT_5YEAR_VALUE']
    float_3year_value = properties['FLOAT_3YEAR_VALUE']

    