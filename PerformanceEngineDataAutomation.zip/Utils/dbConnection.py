from http import server
import sqlalchemy
import config
import pyodbc

def create_engine():
    """
    Engine to be created for bulk insertion into database
    
    """
    server_name = config.server_name
    db_name = config.db_name
    con_string = 'mssql+pyodbc://@' + server_name + '/'+ db_name + '?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'
    engine = sqlalchemy.create_engine(con_string,pool_pre_ping=True)
    return engine

def create_connection():
    """
    For establishing connection to database


    """
    server_name = config.server_name
    db_name = config.db_name
   
    # 'Trusted_Connection=yes;').format(server_name,db_name)
    db_conn = pyodbc.connect('Driver={SQL Server};'
        'Server=t12ewmdba;'
        'Database=TaxHarvest;'
        'Trusted_Connection=yes;')
    return db_conn