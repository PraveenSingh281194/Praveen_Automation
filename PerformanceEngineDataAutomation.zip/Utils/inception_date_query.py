# get_inception_query = """SELECT TOP (1000) [AccountID]
#       ,[SleeveID]
#       ,[PerfSector]
#       ,[MonthEndDate]
#       ,[AsOfDate]
#       ,[MTDPerformance]
#       ,[YTDPerformance]
#       ,[OneYrPerformance]
#       ,[TwoYrPerformance]
#       ,[ThreeYrPerformance]
#       ,[FiveYrPerformance]
#       ,[TenYrPerformance]
#       ,[SIPerformance]
#       ,[InceptionDate]
#       ,[NetInvestment]
#       ,[InsertedOn]
#       ,[ModifiedOn]
#       ,[IsPeriodicValidated]
#       ,[IsYTDValidated]
#       ,[IsSIValidated]
#   FROM [HistoricalPerformance].[dbo].[Performance] where AccountID='{}'"""


get_inception_query = """select *  
from OPENROWSET (BULK '00raw/APL/PerformanceSummary/2022/07/16/', DATA_SOURCE='EDH_DataLake',
FORMAT='PARQUET',FIRSTROW=1) as t  where AccountID='{}'"""