is_validated_query = """
select * 

from OPENROWSET (BULK '/01stage/APL/Performance/Reconciled/*/*/', DATA_SOURCE='EDH_DataLake',

FORMAT='PARQUET',FIRSTROW=1) as t  where AccountID in {}
"""

# is_validated_query = """
# select *  
# from OPENROWSET (BULK '/01stage/APL/Performance/Reconciled/Account/*/', DATA_SOURCE='EDH_DataLake',
# FORMAT='PARQUET',FIRSTROW=1) as t  where AccountID in ('AEC8DP','AEC73R','AEC8HG','AEC64M','AEC3N0','AEC79T')
# """


