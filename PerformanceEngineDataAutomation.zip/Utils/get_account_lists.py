get_accounts_query = """
select distinct AccountID,InceptionDate,MonthEndDate,AsOfDate
from OPENROWSET (BULK '00raw/APL/PerformanceSummary/2022/09/27/', DATA_SOURCE='EDH_DataLake',
FORMAT='PARQUET',FIRSTROW=1) as t where AccountID in ('CZAF5G','CE1RR3','CE3GG5','CE3HE0','CE3IW8','CE3KA3','CE5HN8','CE5I56','CE5IQ2','CE5RI8','CE5X60')
 and perfSector='01'
"""

# get_accounts_query = """
#  select distinct AccountID,InceptionDate,AsOfDate
# from OPENROWSET (BULK '00raw/APL/PerformanceSummary/2022/09/02/', DATA_SOURCE='EDH_DataLake',
# FORMAT='PARQUET',FIRSTROW=1) as t where AccountID in ('C12821',
# 'C11187',
# 'C15197',
# 'C66235') """




get_account_data_query ="""
select *  
from OPENROWSET (BULK '/01stage/APL/CurrentView/*/*', DATA_SOURCE='EDH_DataLake',
FORMAT='PARQUET',FIRSTROW=1) as t where AccountID in {}
order by endingdate desc
"""


