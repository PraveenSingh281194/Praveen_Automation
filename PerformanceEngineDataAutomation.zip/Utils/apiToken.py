import config
import requests
import json

def get_api_token():
    """
    This will return the access token for the api call
    """
    api_token_url = config.api_token_url
    api_username = config.api_username
    api_password = config.api_password
    token_req_payload = {'grant_type': 'client_credentials'}
    head = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept':'application/json'}
    response = requests.post(api_token_url, data = token_req_payload , auth=(api_username, api_password), headers=head)
    tokens = json.loads(response.text)
    return tokens



