# from dbm import _Database
from lib2to3.pgen2.driver import Driver
import pydoc
from telnetlib import AUTHENTICATION, ENCRYPT
from xmlrpc.client import Server
import pyodbc 
import pandas as pd


def datalake_connection():
    server_name = 'azncd01edhsynwrkspc1-ondemand.sql.azuresynapse.net'
    database_name = 'EDH'

    tcon ='Yes'
    conn = pyodbc.connect(Driver='{ODBC Driver 17 for SQL Server}',
                    Server='tcp:azncd01edhsynwrkspc1-ondemand.sql.azuresynapse.net',
                    Port='1433',
                    Database='EDH',
                    AUTHENTICATION='ActiveDirectoryPassword',
                    User ='ashima.sethi@assetmark.com',
                    Password='Welcome208383!',
                    MARS_Connection='Yes'
                    
                    )


    return conn

# print(conn)
# cursor = conn.cursor()
# cursor.execute("""select *  
# from OPENROWSET (BULK '/01stage/APL/Performance/Reconciled/Account/Qualified', DATA_SOURCE='EDH_DataLake',
# FORMAT='PARQUET',FIRSTROW=1) as t  where AccountID='A35930'""")

# for i in cursor:
#     print(i)