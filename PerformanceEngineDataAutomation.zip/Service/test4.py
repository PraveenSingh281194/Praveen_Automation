import pandas as pd

import sqlalchemy



def db_load(arg_df):



    server_name = 't12ewmdba'

    db_name = 'TaxHarvest'

    con_string = 'mssql+pyodbc://@' + server_name + '/'+ db_name + '?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'

    engine = sqlalchemy.create_engine(con_string,pool_pre_ping=True)

    arg_df.to_sql('PEAcctSum', engine , if_exists = 'append' , index = False)



df  = pd.read_csv('M:\IT\Ashima\Account_A.csv',names =['AccountID','PerfSector','MonthEndDate','AsOfDate','MTDPerformance','YTDPerformance','OneYrPerformance','TwoYrPerformance','ThreeYrPerformance','FiveYrPerformance','TenYrPerformance','SIPerformance','InceptionDate','SleeveID','NetInvestment','DateOfData','Date_diff_Inception','Perf_SI','Perf_YTD','Perf_1_Year','Perf_3_Year','Perf_5_Year','Inception_Year','IsYTDValidated','Is1YrValidated','Is3YrValidated','Is5YrValidated','IsSIValidated','ISDirty_flag'], header = None)
# print(df)
temp_df = df[['AccountID','MonthEndDate','AsOfDate','InceptionDate','YTDPerformance','OneYrPerformance','ThreeYrPerformance','FiveYrPerformance','SIPerformance','Perf_SI','Perf_YTD','Perf_1_Year','Perf_3_Year','Perf_5_Year']].copy()

temp_df.rename(columns = {'Perf_SI':'Dev_SI','Perf_YTD':'Dev_YTD','Perf_1_Year':'Dev_OneYr','Perf_3_Year':'Dev_ThreeYr','Perf_5_Year':'Dev_FiveYr'}, inplace = True)

# print(temp_df.head())
db_load(temp_df)


