from cgi import test
from unicodedata import numeric
import pandas as pd
import config
from xml.etree.ElementTree import fromstring
from importlib.metadata import files
from numpy import divide, double, number, power
import pandas as pd
import glob
import datetime
from  datetime import date,datetime
from Utils.logs import testLog
from datetime import date, timedelta
from Utils.dbConnection import create_connection
from Utils.inception_date_query import get_inception_query
from Utils.data_lake_connection import datalake_connection
from Utils.get_account_lists import get_accounts_query,get_account_data_query
from Utils.check_isValidated_query import is_validated_query
import numpy as np
import config
import time
import os
from dateutil.relativedelta import relativedelta


def five_year_calculation(prev_last,account_number,number_of_days,account_dataframe,next_date_calc,year_value):
    try:
        """
            year_value - 365.2425
            calculate_from_date - The date from which calculation for 5 Year will start . For  eg 20170901
            next_date_calc - The date till which calculation for 5 Year will be done . For eg 20220831 (MonthEndDate)
            temp_df - dataframe having rows from calculate_from_date to next_date_calc
            Steps :
                    Take column NetOfFeeReturns
                    Divide it with 100
                    Then add 1
                    find prdouct of all rows
                    Subtract 1 from final result
                    find power

            final_value_fives  -  round value to 2 . For instance , powe value came 12.3456,then final_value_fives = 12.35
            perf_value_fives  - value without rounding off . perf_values_fives = 12.34

        """
        multiply_5 = 5*year_value
        float_value = config.float_5year_value
        calculate_from_date = next_date_calc-timedelta(days =int(multiply_5))
        calculate_from_date = calculate_from_date+timedelta(days =1)
        account_dataframe['EndingDate'] = pd.to_datetime(account_dataframe['EndingDate'],format = '%Y%m%d', errors='coerce')
        temp_df = account_dataframe.loc[(account_dataframe['EndingDate'].dt.date>=calculate_from_date) & (account_dataframe['EndingDate'].dt.date<=next_date_calc)]
        temp_df = temp_df.assign(Product=lambda x: (temp_df['NetOfFeeReturns'].astype(double)/100))   
        temp_df = temp_df.assign(plus1=lambda x: (temp_df['Product'].astype(double)+1))
        col_list = temp_df['plus1'].values.tolist()
        result = np.prod(np.array(col_list))
        result_1 = result-1
        powers = pow(result_1+1,year_value/float_value)
        powe = (powers-1)*100 
        final_value_five = round(powe,2)
        final_value_fives=format(final_value_five,'.2f')
        perf_value_five = str(powe).split('.')
        perf_value_fives ='%s.%s' % (perf_value_five[0], perf_value_five[1][:2])
        return final_value_fives,perf_value_fives
        
    except Exception as e:
        print(e)
        return None
 




def three_year_calculation(prev_last,account_number,number_of_days,account_dataframe,next_date_calc,year_value):
    """
        year_value - 365.2425
        calculate_from_date - The date from which calculation for 3 Year will start . For  eg 20190901
        next_date_calc - The date till which calculation for 5 Year will be done . For eg 20220831 (MonthEndDate)
        temp_df - dataframe having rows from calculate_from_date to next_date_calc
        Steps :
                Take column NetOfFeeReturns
                Divide it with 100
                Then add 1
                find prdouct of all rows
                Subtract 1 from final result
                find power

        final_value_fives  -  round value to 2 . For instance , powe value came 12.3456,then final_value_fives = 12.35
        perf_value_fives  - value without rounding off . perf_values_fives = 12.34

    """
    try:
        
        multiply_3 = 3*year_value
        float_3_value = config.float_3year_value
        calculate_from_date = next_date_calc-timedelta(days =round(multiply_3))
        calculate_from_date = calculate_from_date+timedelta(days =1)
        account_dataframe['EndingDate'] = pd.to_datetime(account_dataframe['EndingDate'],format = '%Y%m%d', errors='coerce')
        temp_df = account_dataframe.loc[(account_dataframe['EndingDate'].dt.date>=calculate_from_date) & (account_dataframe['EndingDate'].dt.date<=next_date_calc)]
        temp_df = temp_df.assign(Product=lambda x: (temp_df['NetOfFeeReturns'].astype(double)/100))   
        temp_df = temp_df.assign(plus1=lambda x: (temp_df['Product'].astype(double)+1))
        col_list = temp_df['plus1'].values.tolist()
        result = np.prod(np.array(col_list))
        result_1 = result-1
        powers = pow(result_1+1,year_value/float_3_value)
        powe = (powers-1)*100 
        final_value_three = round(powe,2)
        final_value_threes=format(final_value_three,'.2f')
        perf_value_three = str(powe).split('.')
        perf_value_threes ='%s.%s' % (perf_value_three[0], perf_value_three[1][:2])
        return final_value_threes,perf_value_threes
    except:
        return None


def one_year_calculation(prev_last,account_number,number_of_days,account_dataframe,next_date_calc,year_value):
    """
        year_value - 365.2425
        calculate_from_date - The date from which calculation for 1 Year will start . For  eg 20210901
        next_date_calc - The date till which calculation for 5 Year will be done . For eg 20220831 (MonthEndDate)
        temp_df - dataframe having rows from calculate_from_date to next_date_calc
        Steps :
                Take column NetOfFeeReturns
                Divide it with 100
                Then add 1
                find prdouct of all rows
                Subtract 1 from final result
                find power

        final_value_fives  -  round value to 2 . For instance , powe value came 12.3456,then final_value_fives = 12.35
        perf_value_fives  - value without rounding off . perf_values_fives = 12.34

    """
    try:
        calculate_from_date = next_date_calc-timedelta(days =int(year_value))
        calculate_from_date = calculate_from_date+timedelta(days =1)
        account_dataframe['EndingDate'] = pd.to_datetime(account_dataframe['EndingDate'],format = '%Y%m%d', errors='coerce')
        temp_df = account_dataframe.loc[(account_dataframe['EndingDate'].dt.date>=calculate_from_date) & (account_dataframe['EndingDate'].dt.date<=next_date_calc)]
        temp_df = temp_df.assign(Product=lambda x: (temp_df['NetOfFeeReturns'].astype(double)/100))   
        temp_df = temp_df.assign(plus1=lambda x: (temp_df['Product'].astype(double)+1))
        col_list = temp_df['plus1'].values.tolist()
        result = np.prod(np.array(col_list))
        result_1 = result-1
        powers = pow(result_1+1,year_value/year_value)
        powe = (powers-1)*100 
        final_value_one = round(powe,2)
        final_value_ones=format(final_value_one,'.2f')
        perf_value_one = str(powe).split('.')
        perf_value_ones ='%s.%s' % (perf_value_one[0], perf_value_one[1][:2])
        return final_value_ones,perf_value_ones
    except:
        return None
    


def sip_performance(prev_last,account_number,number_of_days,account_dataframe,date_calc,year_value,final_inception_date):
    """
        year_value - 365.2425
        calculate_from_date - The date from which calculation 
        next_date_calc - The date till which calculation  For eg 20220922 (AsOfDate)
        temp_df - dataframe having rows from calculate_from_date to next_date_calc
        Steps :
                Take column NetOfFeeReturns
                Divide it with 100
                Then add 1
                find prdouct of all rows
                Subtract 1 from final result
                find power

        final_value_fives  -  round value to 2 . For instance , powe value came 12.3456,then final_value_fives = 12.35
        perf_value_fives  - value without rounding off . perf_values_fives = 12.34
        

    """
    try:
        temp_df = account_dataframe
        sip_year_value = config.sip_year_value
        calculate_from_date = date_calc
        n_days = calculate_from_date-final_inception_date
        number_of_days = float(n_days.days)
        account_dataframe['EndingDate'] = pd.to_datetime(account_dataframe['EndingDate'],format = '%Y%m%d', errors='coerce')
        temp_df = account_dataframe.loc[account_dataframe['EndingDate'].dt.date<=calculate_from_date & (account_dataframe['EndingDate'].dt.date>=final_inception_date)]
        temp_df = temp_df.assign(Product=lambda x: (temp_df['NetOfFeeReturns'].astype(double)/100))   
        temp_df = temp_df.assign(plus1=lambda x: (temp_df['Product'].astype(double)+1))        
        col_list = temp_df['plus1'].values.tolist()
        result = np.prod(np.array(col_list))
        result_1 = result-1
        powers = pow(result_1+1,sip_year_value/number_of_days)
        powe = (powers-1)*100 
        final_value_sip = round(powe,2)
        final_value_sips=format(final_value_sip,'.2f')
        perf_value_sip = str(powe).split('.')
        perf_value_sips ='%s.%s' % (perf_value_sip[0], perf_value_sip[1][:2])
        return final_value_sips,perf_value_sips

    except:
        print('Line 134')
        return None

def sip_ytd_performance(prev_last,account_number,number_of_days,account_dataframe,date_calc,year_value,final_inception_date):
    """
        year_value - 365.2425
        calculate_from_date - The date from which calculation for
        next_date_calc - The date till which calculation  . For eg 20220922 (AsOfDate)
        temp_df - dataframe having rows from calculate_from_date to next_date_calc
        Steps :
                Take column NetOfFeeReturns
                Divide it with 100
                Then add 1
                find prdouct of all rows
                Subtract 1 from final result
                find power

        final_value_fives  -  round value to 2 . For instance , powe value came 12.3456,then final_value_fives = 12.35
        perf_value_fives  - value without rounding off . perf_values_fives = 12.34

    """
    try:
        temp_df = account_dataframe
        calculate_from_date = date_calc
        n_days = calculate_from_date-final_inception_date
        number_of_days = float(n_days.days)
        account_dataframe['EndingDate'] = pd.to_datetime(account_dataframe['EndingDate'],format = '%Y%m%d', errors='coerce')
        temp_df =account_dataframe.loc[account_dataframe['EndingDate'].dt.date<=calculate_from_date & (account_dataframe['EndingDate'].dt.date>=final_inception_date)]
        temp_df = temp_df.assign(Product=lambda x: (temp_df['NetOfFeeReturns'].astype(double)/100))   
        temp_df = temp_df.assign(plus1=lambda x: (temp_df['Product'].astype(double)+1))
        col_list = temp_df['plus1'].values.tolist()
        result = np.prod(np.array(col_list))
        result_1 = result-1
        powe = result_1*100 
        final_value_sip_ytd = round(powe,2)
        final_value_sip_ytds=format(final_value_sip_ytd,'.2f')
        perf_value_sip_ytd = str(powe).split('.')
        perf_value_sip_ytds ='%s.%s' % (perf_value_sip_ytd[0], perf_value_sip_ytd[1][:2])
        return final_value_sip_ytds,perf_value_sip_ytds
    except:
        return None
def ytd_performance(prev_last,account_number,number_of_days,account_dataframe,date_calc,year_value,final_inception_date):
    """
        year_value - 365.2425
        calculate_from_date - The date from which calculation  
        next_date_calc - The date till which calculation . For eg 20220922 (AsOfDate)
        temp_df - dataframe having rows from calculate_from_date to next_date_calc
        Steps :
                Take column NetOfFeeReturns
                Divide it with 100
                Then add 1
                find prdouct of all rows
                Subtract 1 from final result
                find power

        final_value_fives  -  round value to 2 . For instance , powe value came 12.3456,then final_value_fives = 12.35
        perf_value_fives  - value without rounding off . perf_values_fives = 12.34

    """
    try:
        temp_df = account_dataframe
        calculate_from_date = date_calc
        year_start_date = date.today().replace(month=1,day=1)
        final_year_start_date = year_start_date-timedelta(days=1)
        n_days = calculate_from_date-year_start_date
        number_of_days = float(n_days.days)
        account_dataframe['EndingDate'] = pd.to_datetime(account_dataframe['EndingDate'],format = '%Y%m%d', errors='coerce')
        temp_df =account_dataframe.loc[(account_dataframe['EndingDate'].dt.date<=calculate_from_date) & (account_dataframe['EndingDate'].dt.date>=year_start_date)]       
        temp_df = temp_df.assign(Product=lambda x: (temp_df['NetOfFeeReturns'].astype(double)/100))   
        temp_df = temp_df.assign(plus1=lambda x: (temp_df['Product'].astype(double)+1))
        col_list = temp_df['plus1'].values.tolist()
        result = np.prod(np.array(col_list))
        result_1 = result-1 
        powe = result_1*100
        final_value_ytd = round(powe,2)
        final_value_ytds=format(final_value_ytd,'.2f')
        perf_value_ytd= str(powe).split('.')
        perf_value_ytds ='%s.%s' % (perf_value_ytd[0], perf_value_ytd[1][:2])
        return final_value_ytds,perf_value_ytds
    except Exception as e:
        print(e)
        return None


def change_timezone(date_str ):
    from datetime import timezone
    try:
        d1 = datetime.strptime(date_str.split('T')[0], "%Y-%m-%d")
        
        date_string = d1.strftime('%Y%m%d')
        print(date_string)
    except:
        date_string = date_str

    return date_string

def  get_results(all_accounts_dataframe,reconciled_dataframe,file_df,unique_account_number,year_value):
    result_list =[]
    five_year_reasons_list = []
    three_year_reasons_list = []
    one_year_reasons_list = []
    sip_reasons_list = []
    ytd_reasons_list = []
    mismatch_accounts = []
    if len(reconciled_dataframe.index)==0:
        # return None
        """Mismatch Accounts are if account is present in performance sumamry but not present in reconciled data"""
        missing_accounts = ','.join(unique_account_number)
        mismatch_accounts.append(missing_accounts)
    else:
        #Code Execution for each Account Starts Here  
        for i in unique_account_number:
            print('&&*********()))()',i)
            count = 1
            testLog(count)
            inception_dataframe = file_df.loc[file_df['AccountID']==str(i)]
            if len(inception_dataframe)==0:
                mismatch_accounts.append(i)
            else:
                """
                    final_inception_dated - Inception Date for Particular Account
                    prev_last,new_date -  MonthEndDate for that particular account
                    sed ,number_of_days  - Number of days to calculate from InceptionDate till MonthEndDate for that particulare account
                    account_dataframe -  all rows in current view for that particular account
                """
                try:
                    final_inception_dated= inception_dataframe['InceptionDate'].astype(str)
                    final_inception_dates = final_inception_dated.values[0]
                    previous_last_date = inception_dataframe['MonthEndDate'].astype(str)
                    previous_last_dated = previous_last_date.values[0]              
                    prev_lasts = datetime.strptime(previous_last_dated,'%Y%m%d').date()
                    prev_last = prev_lasts
                    final_inception_date = datetime.strptime(final_inception_dates,"%Y%m%d")
                    final_inception_date = final_inception_date.date()              
                    sed = prev_last-final_inception_date
                    number_of_days = float(sed.days)
                    account_dataframe = all_accounts_dataframe.loc[all_accounts_dataframe["AccountID"]==str(i)]
                    if len(account_dataframe)==0:
                        """
                        If account present in performance summary but no entry in current view then we will categorize this account has mismatch
                        """
                        mismatch_accounts.append(i)
                    else:
                        """
                            ROW_1 -  getting EndingDate from first row from account_dataframe
                        """
                        row_1 = account_dataframe.iloc[0]
                        date_calc = datetime.strptime(row_1['EndingDate'],"%Y%m%d")
                        date_calc = date_calc.date()
                        first_date_calc = date_calc.replace(day=1)
                        next_date_calc = first_date_calc - timedelta(days=1)
                        temp_validate_dataframe = reconciled_dataframe.loc[reconciled_dataframe['AccountID']==str(i)]
                        # print(temp_validate_dataframe)
                        new_date = prev_last
                        next_date_calc = new_date
                        one_year_date_subtraction = new_date - relativedelta(years=1)
                        three_year_date_subtraction = new_date - relativedelta(years=3)
                        five_year_date_subtraction = new_date - relativedelta(years=5)
                        year_start_date = date.today().replace(month=1,day=1)
                        final_year_start_date = year_start_date-timedelta(days=1)
                        if len(temp_validate_dataframe)==0:
                            mismatch_accounts.append(i)
                        else:
                                testLog('Calculation for 5 Year Started')
                                if number_of_days>= 5*year_value:
                                    print("line 227")
                                    """
                                        ending_dates - EndingDate taken from Current View Query
                                        asof_date -  taken from Performance summary
                                    """
                                    ending_date_string = str(account_dataframe['EndingDate'].values[0])  
                                    date_string_change = change_timezone(ending_date_string)                          
                                    ending_dates =  np.array(np.datetime64(date_string_change))
                                    asof_date =  np.array(np.datetime64(str(inception_dataframe['AsOfDate'].values[0])))
                                    if ending_dates<asof_date:
                                        """
                                            check if endingdate in current view is less than as of date in performance
                                            if yes:
                                                dont calculate SIP and YTD
                                            else:
                                                calculate SIP and YTD
                                        """
                                        sip_performance_result = ('0.00','0.00')
                                        ytd_performance_result = ('0.00','0.00')
                                    else:    
                                        """
                                            final_year_start_date -  previous year last date
                                            check if entry present for say '20211231'
                                            if yes:
                                                calculate YTD
                                            else:
                                                calculate SIP and make YTD as 0.00
                                        """                          
                                        sip_performance_result = sip_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        ytd_performance_result = ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        temp_df_ytd = account_dataframe.loc[account_dataframe['EndingDate'].dt.date==final_year_start_date]

                                        if len(temp_df_ytd)==0:
                                            ytd_performance_result = ('0.00','0.00')
                                        else:
                                            testLog("Line 260")
                                    try:
                                        """
                                            temp_validate_dataframe -  dataframe creayed from Reconciled Query
                                            sip_performance_result - value return from sip_performance 
                                            sip_performance_result[0] -  round off value
                                        """
                                        temp_sip = str(temp_validate_dataframe['Perf_SI'].values[0]).split('.')
                                        temp_sip ='%s.%s' % (temp_sip[0], temp_sip[1][:2])

                                        if str(sip_performance_result[0])=='-0.00':
                                            sip_year_value = str(sip_performance_result[0]).replace('-','')
                                        else:
                                            sip_year_value = sip_performance_result[0]
                                        #print(temp_sip)
                                        if temp_validate_dataframe['IsSIValidated'].values[0]=='0' :
                                            testLog("Success")
                                        else:
                                            if str(sip_year_value)== temp_validate_dataframe['SIPerformance'].values[0] and temp_validate_dataframe['IsSIValidated'].values[0]=='1' :
                                                testLog("Success")
                                            else:
                                                sip_reasons_list.append(i)
                                    except Exception as e:
                                        testLog(e)

                                    try:
                                        """
                                            temp_validate_dataframe -  dataframe creayed from Reconciled Query
                                            ytd_performance_result - value return from ytd_performance 
                                            ytd_performance_result[0] -  round off value
                                        """
                                        temp_ytd = str(temp_validate_dataframe['Perf_YTD'].values[0]).split('.')
                                        temp_ytd ='%s.%s' % (temp_ytd[0], temp_ytd[1][:2])

                                        if str(ytd_performance_result[0])=='-0.00':
                                            ytd_year_value = str(ytd_performance_result[0]).replace('-','')
                                        else:
                                            ytd_year_value = ytd_performance_result[0]
                                        if  temp_validate_dataframe['IsYTDValidated'].values[0]=='0':
                                                testLog("Success")
                                        else:
                                            if str(ytd_year_value)== temp_validate_dataframe['YTDPerformance'].values[0] and temp_validate_dataframe['IsYTDValidated'].values[0]=='1':
                                                testLog("Success")
                                            else:
                                                ytd_reasons_list.append(i)
                                    except Exception as e:
                                        testLog(e)
                                    date_1 = datetime.strftime(one_year_date_subtraction,"%Y%m%d")
                                    new_date_1 = datetime.strftime(new_date,"%Y%m%d")
                                    """ 
                                        date_1, new_date_1 - start and end date  for that particular account
                                        check if both dates are present then only calculate One year Performance
                                        if yes:
                                            calculate one year performance
                                        else:
                                            mark one year performance as 0.00
                                    """
                                    temp_account_dataframe = account_dataframe.loc[(account_dataframe["EndingDate"]==str(date_1)) | (account_dataframe["EndingDate"]==str(new_date_1)) ]
                                    if len(temp_account_dataframe) <2:
                                        one_year_calculation_result = ('0.00','0.0')
                                    else:
                                        one_year_calculation_result = one_year_calculation(prev_last,i,number_of_days,account_dataframe,next_date_calc,year_value)
                                    try: 
                                        if one_year_calculation_result is not None:   
                                            print(one_year_calculation_result)
                                            temp_one = str(temp_validate_dataframe['Perf_1_Year'].values[0]).split('.')
                                            temp_one ='%s.%s' % (temp_one[0], temp_one[1][:2])
                                            if str(one_year_calculation_result[0])=='-0.00':
                                                one_year_value = str(one_year_calculation_result[0]).replace('-','')
                                            else:
                                                one_year_value = one_year_calculation_result[0]
                                            if temp_validate_dataframe['Is1YrValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(one_year_value)== temp_validate_dataframe['OneYrPerformance'].values[0] and temp_validate_dataframe['Is1YrValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:
                                                    one_year_reasons_list.append(i)
                                        else:
                                            testLog("Error in One Year Value")
                                    except Exception as e:
                                        testLog(e)



                                    date_3 = datetime.strftime(three_year_date_subtraction,"%Y%m%d")
                                    new_date_1 = datetime.strftime(new_date,"%Y%m%d")
                                    """ 
                                        date_3, new_date_1 - start and end date  for that particular account
                                        check if both dates are present then only calculate three year Performance
                                        if yes:
                                            calculate three year performance
                                        else:
                                            mark three year performance as 0.00
                                    """
                                    temp_account_dataframe = account_dataframe.loc[(account_dataframe["EndingDate"]==str(date_3)) | (account_dataframe["EndingDate"]==str(new_date_1)) ]
                                    if len(temp_account_dataframe) <2:
                                    
                                        three_year_calculation_result = ('0.00','0.0')
                                    else:
                                        three_year_calculation_result = three_year_calculation(prev_last,i,number_of_days,account_dataframe,next_date_calc,year_value)
                                    try:
                                        if three_year_calculation_result is not None: 
                                            temp_three = str(temp_validate_dataframe['Perf_3_Year'].values[0]).split('.')
                                            temp_three ='%s.%s' % (temp_three[0], temp_three[1][:2])
                                            if str(three_year_calculation_result[0])=='-0.00':
                                                three_year_value = str(three_year_calculation_result[0]).replace('-','')
                                            else:
                                                three_year_value = three_year_calculation_result[0]
                                            if  temp_validate_dataframe['Is3YrValidated'].values[0]=='0':
                                                    testLog("Success")
                                            else:
                                                if str(three_year_value)== temp_validate_dataframe['ThreeYrPerformance'].values[0] and temp_validate_dataframe['Is3YrValidated'].values[0]=='1':
                                                    testLog("Success")
                                                else:
                                                    three_year_reasons_list.append(i)
                                        else:
                                                testLog('Error in 3 Year Value')
                                    except Exception as e:
                                        testLog(e)



                                    date_5 = datetime.strftime(five_year_date_subtraction,"%Y%m%d")
                                    """ 
                                        date_5, new_date_1 - start and end date  for that particular account
                                        check if both dates are present then only calculate five year Performance
                                        if yes:
                                            calculate five year performance
                                        else:
                                            mark five year performance as 0.00
                                    """
                                    temp_account_dataframe = account_dataframe.loc[(account_dataframe["EndingDate"]==str(date_5)) | (account_dataframe["EndingDate"]==str(new_date_1)) ]
                                    if len(temp_account_dataframe) <2:
                                        five_year_calculation_result = ('0.00','0.0')
                                    else:
                                        five_year_calculation_result = five_year_calculation(prev_last,i,number_of_days,account_dataframe,next_date_calc,year_value)
                                
                                    try:
                                        if five_year_calculation_result is not None:
                                            temp_five = str(temp_validate_dataframe['Perf_5_Year'].values[0]).split('.')
                                            temp_five ='%s.%s' % (temp_five[0], temp_five[1][:2])
                                            if str(five_year_calculation_result[0])=='-0.00':
                                                five_year_value = str(five_year_calculation_result[0]).replace('-','')
                                            else:
                                                five_year_value = five_year_calculation_result[0] 
                                            if  temp_validate_dataframe['Is5YrValidated'].values[0]=='0' :
                                                testLog("Success")
                                            else:
                                                if str(five_year_value)== temp_validate_dataframe['FiveYrPerformance'].values[0] and temp_validate_dataframe['Is5YrValidated'].values[0]=='1' :
                                                    testLog("Success")
                                                else:
                                                    five_year_reasons_list.append(i)
                                        else:
                                                testLog('Error in 5 Year Value')
                                    except Exception as e:
                                        testLog(e)

                                    
                                elif number_of_days< 5*year_value and number_of_days>=3*year_value: 
                                    print("line 367")  
                                    ending_date_string = str(account_dataframe['EndingDate'].values[0])                            
                                    date_string_change = change_timezone(ending_date_string)                          
                                    ending_dates =  np.array(np.datetime64(date_string_change))
                                    asof_date =  np.array(np.datetime64(str(inception_dataframe['AsOfDate'].values[0])))

                                    if ending_dates<asof_date:
                                        sip_performance_result = ('0.00','0.00')
                                        ytd_performance_result = ('0.00','0.00')
                                    else:
                                        sip_dated= temp_validate_dataframe['AsOfDate'].astype(str)
                                        sip_dates = sip_dated.values[0]
                                        sip_inception_date = datetime.strptime(sip_dates,"%Y%m%d")
                                        sip_inception_date = sip_inception_date.date()  
                                        sed_sip = sip_inception_date-final_inception_date
                                        number_of_sip_days = float(sed_sip.days)
                                        if number_of_sip_days<1*year_value:
                                            sip_performance_result = sip_ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        else:
                                            sip_performance_result = sip_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        ytd_performance_result = ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        temp_df_ytd = account_dataframe.loc[account_dataframe['EndingDate'].dt.date==final_year_start_date]
                                        if len(temp_df_ytd)==0:
                                            ytd_performance_result = ('0.00','0.00')
                                        else:
                                            testLog("Line 260")
                                    try:
                                        if sip_performance_result is None:
                                            testLog("Error in SIP")
                                        else:
                                            temp_sip = str(temp_validate_dataframe['Perf_SI'].values[0]).split('.')
                                            temp_sip ='%s.%s' % (temp_sip[0], temp_sip[1][:2])

                                            if str(sip_performance_result[0])=='-0.00':
                                                sip_year_value = str(sip_performance_result[0]).replace('-','')
                                            else:
                                                sip_year_value = sip_performance_result[0]
                                            if temp_validate_dataframe['IsSIValidated'].values[0]=='0':
                                                    testLog("Success")
                                            else:
                                                if str(sip_year_value)== temp_validate_dataframe['SIPerformance'].values[0] and temp_validate_dataframe['IsSIValidated'].values[0]=='1':
                                                    testLog("Success")
                                                else:
                                                    
                                                    sip_reasons_list.append(i)
                                    except Exception as e:
                                        testLog(e)
                                    try:
                                        if ytd_performance_result is not  None:
                                            temp_ytd = str(temp_validate_dataframe['Perf_YTD'].values[0]).split('.')
                                            temp_ytd ='%s.%s' % (temp_ytd[0], temp_ytd[1][:2])

                                            if str(ytd_performance_result[0])=='-0.00':
                                                ytd_year_value = str(ytd_performance_result[0]).replace('-','')
                                            else:
                                                ytd_year_value = ytd_performance_result[0]
                                            if  temp_validate_dataframe['IsYTDValidated'].values[0]=='0':
                                                    testLog("Success")
                                            else:
                                                if str(ytd_year_value)== temp_validate_dataframe['YTDPerformance'].values[0] and temp_validate_dataframe['IsYTDValidated'].values[0]=='1':
                                                        testLog("Success")
                                                else:
                                                
                                                    testLog("line 389")
                                                    ytd_reasons_list.append(i)
                                        else:
                                            testLog("Error in YTD")

                                    except Exception as e:
                                        testLog(e)

                                

                                    
                                    date_1 = datetime.strftime(one_year_date_subtraction,"%Y%m%d")
                                    new_date_1 = datetime.strftime(new_date,"%Y%m%d")
                                    temp_account_dataframe = account_dataframe.loc[(account_dataframe["EndingDate"]==str(date_1)) | (account_dataframe["EndingDate"]==str(new_date_1)) ]
                                    if len(temp_account_dataframe) <2:
                                        print("Line 343")
                                        one_year_calculation_result = ('0.00','0.0')
                                    else:
                                        one_year_calculation_result = one_year_calculation(prev_last,i,number_of_days,account_dataframe,next_date_calc,year_value)
                                    try:
                                        if one_year_calculation_result is not  None:
                                            temp_one = str(temp_validate_dataframe['Perf_1_Year'].values[0]).split('.')
                                            temp_one ='%s.%s' % (temp_one[0], temp_one[1][:2])
                                            if str(one_year_calculation_result[0])=='-0.00':
                                                one_year_value = str(one_year_calculation_result[0]).replace('-','')
                                            else:
                                                one_year_value = one_year_calculation_result[0]
                                            if  temp_validate_dataframe['Is1YrValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(one_year_value)== temp_validate_dataframe['OneYrPerformance'].values[0] and temp_validate_dataframe['Is1YrValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:
                                                
                                                    one_year_reasons_list.append(i)
                                        else:
                                            testLog('Error in One Year Calculation')
                                    except Exception as e:
                                        testLog(e)


                                    date_3 = datetime.strftime(three_year_date_subtraction,"%Y%m%d")
                                    temp_account_dataframe = account_dataframe.loc[(account_dataframe["EndingDate"]==str(date_3)) | (account_dataframe["EndingDate"]==str(new_date_1)) ]
                                    if len(temp_account_dataframe) <2:
                                        three_year_calculation_result = ('0.00','0.0')
                                    else:
                                        three_year_calculation_result = three_year_calculation(prev_last,i,number_of_days,account_dataframe,next_date_calc,year_value)
                                    try:
                                        if three_year_calculation_result is not  None:
                                            temp_three = str(temp_validate_dataframe['Perf_3_Year'].values[0]).split('.')
                                            temp_three ='%s.%s' % (temp_three[0], temp_three[1][:2])
                                            if str(three_year_calculation_result[0])=='-0.00':
                                                three_year_value = str(three_year_calculation_result[0]).replace('-','')
                                            else:
                                                three_year_value = three_year_calculation_result[0]
                                            if temp_validate_dataframe['Is3YrValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(three_year_value)== temp_validate_dataframe['ThreeYrPerformance'].values[0] and temp_validate_dataframe['Is3YrValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:
                                                
                                                    three_year_reasons_list.append(i)
                                        else:
                                            testLog('Error in 3 Year Calculation')
                                    except Exception as e:
                                        testLog(e)
                                    

                                elif number_of_days<3*year_value and number_of_days>=1*year_value:
                                    print("line 498")
                                    ending_date_string = str(account_dataframe['EndingDate'].values[0])                            
                                    date_string_change = change_timezone(ending_date_string)                          
                                    ending_dates =  np.array(np.datetime64(date_string_change))
                                    asof_date =  np.array(np.datetime64(str(inception_dataframe['AsOfDate'].values[0])))
                                    if ending_dates<asof_date:
                                        sip_performance_result = ('0.00','0.00')
                                        ytd_performance_result = ('0.00','0.00')
                                    else: 
                                        sip_dated= temp_validate_dataframe['AsOfDate'].astype(str)
                                        sip_dates = sip_dated.values[0]
                                        sip_inception_date = datetime.strptime(sip_dates,"%Y%m%d")
                                        sip_inception_date = sip_inception_date.date()  
                                        sed_sip = sip_inception_date-final_inception_date
                                        number_of_sip_days = float(sed_sip.days)
                                        if number_of_sip_days<1*year_value:
                                            sip_performance_result = sip_ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        else:
                                            sip_performance_result = sip_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        ytd_performance_result = ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        temp_df_ytd = account_dataframe.loc[account_dataframe['EndingDate'].dt.date==final_year_start_date]
                                        if len(temp_df_ytd)==0:
                                            ytd_performance_result = ('0.00','0.00')
                                        else:
                                            testLog("Line 260")
                                    try:
                                        if sip_performance_result is not None:
                                            temp_sip = str(temp_validate_dataframe['Perf_SI'].values[0]).split('.')
                                            temp_sip ='%s.%s' % (temp_sip[0], temp_sip[1][:2])

                                            if str(sip_performance_result[0])=='-0.00':
                                                sip_year_value = str(sip_performance_result[0]).replace('-','')
                                            else:
                                                sip_year_value = sip_performance_result[0]
                                            if  temp_validate_dataframe['IsSIValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(sip_year_value)== temp_validate_dataframe['SIPerformance'].values[0] and temp_validate_dataframe['IsSIValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:                                               
                                                    sip_reasons_list.append(i)
                                        else:
                                            testLog("Error in SIP")
                                    except Exception as e:
                                        testLog(e)
                                    try:
                                        if ytd_performance_result is not None:
                                            temp_ytd = str(temp_validate_dataframe['Perf_YTD'].values[0]).split('.')
                                            temp_ytd ='%s.%s' % (temp_ytd[0], temp_ytd[1][:2])
                                            if str(ytd_performance_result[0])=='-0.00':
                                                ytd_year_value = str(ytd_performance_result[0]).replace('-','')
                                            else:
                                                ytd_year_value = ytd_performance_result[0]
                                            #print(temp_ytd)
                                            if  temp_validate_dataframe['IsYTDValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(ytd_year_value)== temp_validate_dataframe['YTDPerformance'].values[0] and temp_validate_dataframe['IsYTDValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:                                                
                                                    ytd_reasons_list.append(i)
                                        else:
                                            testLog("Error in YTD")

                                    except Exception as e:
                                        testLog(e)
                                    date_1 = datetime.strftime(one_year_date_subtraction,"%Y%m%d")
                                    new_date_1 = datetime.strftime(new_date,"%Y%m%d")
                                    temp_account_dataframe = account_dataframe.loc[(account_dataframe["EndingDate"]==str(date_1)) | (account_dataframe["EndingDate"]==str(new_date_1)) ]
                                    if len(temp_account_dataframe) <2:
                                        one_year_calculation_result = ('0.00','0.0')  
                                    else:
                                        one_year_calculation_result = one_year_calculation(prev_last,i,number_of_days,account_dataframe,next_date_calc,year_value)
                                    try:
                                        if one_year_calculation_result is not  None:
                                            temp_one = str(temp_validate_dataframe['Perf_1_Year'].values[0]).split('.')
                                            temp_one ='%s.%s' % (temp_one[0], temp_one[1][:2])
                                            #print(temp_one)
                                            if str(one_year_calculation_result[0])=='-0.00':
                                                one_year_value = str(one_year_calculation_result[0]).replace('-','')
                                            else:
                                                one_year_value = one_year_calculation_result[0]
                                            if temp_validate_dataframe['Is1YrValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(one_year_value)== temp_validate_dataframe['OneYrPerformance'].values[0] and temp_validate_dataframe['Is1YrValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:                                           
                                                    one_year_reasons_list.append(i)
                                        else:
                                            testLog("Error in 1 Year")
                                    except Exception as e:
                                        testLog(e)
                                        
                                        

                                elif final_inception_date<=date.today().replace(month=1,day=1)-timedelta(days=1):
                                    print("line 593")
                                    """
                                        check if an account has been opened before the monthenddate
                                        if yes:
                                            calculate sip_ytd_performance, sip_performance
                                        else:
                                            no calculation
                                    """
                                    ytd_performance_result = ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                    sip_dated= temp_validate_dataframe['AsOfDate'].astype(str)
                                    sip_dates = sip_dated.values[0]
                                    sip_inception_date = datetime.strptime(sip_dates,"%Y%m%d")
                                    sip_inception_date = sip_inception_date.date()  
                                    sed_sip = sip_inception_date-final_inception_date
                                    number_of_sip_days = float(sed_sip.days)
                                    ending_date_string = str(account_dataframe['EndingDate'].values[0])                            
                                    date_string_change = change_timezone(ending_date_string)                          
                                    ending_dates =  np.array(np.datetime64(date_string_change))
                                    print(ending_dates)
                                    asof_date =  np.array(np.datetime64(str(inception_dataframe['AsOfDate'].values[0])))
                                    print(type(account_dataframe['EndingDate'].values[0]))
                                    print('ending date for account: {}   {}'.format(i,ending_dates))
                                    print(asof_date)
                                    if ending_dates<asof_date:
                                        print("OOOOOP")
                                        sip_ytd_performance_result = ('0.00','0.00')
                                        ytd_performance_result = ('0.00','0.00')
                                    else:
                                        print("line811")
                                        if number_of_sip_days<1*year_value:
                                            
                                            sip_ytd_performance_result = sip_ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        else:
                                            sip_ytd_performance_result = sip_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        temp_df_ytd = account_dataframe.loc[account_dataframe['EndingDate'].dt.date==final_year_start_date]
                                        if len(temp_df_ytd)==0:
                                            ytd_performance_result = ('0.00','0.00')
                                        else:
                                            testLog("Line 260")
                                    try:
                                        if ytd_performance_result is not None:
                                            temp_ytd = str(temp_validate_dataframe['Perf_YTD'].values[0]).split('.')
                                            temp_ytd ='%s.%s' % (temp_ytd[0], temp_ytd[1][:2])

                                            if str(ytd_performance_result[0])=='-0.00':
                                                ytd_year_value = str(ytd_performance_result[0]).replace('-','')
                                            else:
                                                ytd_year_value = ytd_performance_result[0]
                                            if  temp_validate_dataframe['IsYTDValidated'].values[0]=='0':
                                                    testLog("Success")
                                            else:
                                                if str(ytd_year_value)== temp_validate_dataframe['YTDPerformance'].values[0] and temp_validate_dataframe['IsYTDValidated'].values[0]=='1':
                                                    testLog("Success")
                                                else:                                           
                                                    ytd_reasons_list.append(i)
                                        else:
                                            testLog("Erro in YTD")

                                    except Exception as e:
                                        testLog(e)
                                    try:
                                        if sip_ytd_performance_result is not None:
                                            temp_sip = str(temp_validate_dataframe['Perf_SI'].values[0]).split('.')
                                            temp_sip ='%s.%s' % (temp_sip[0], temp_sip[1][:2])
                                            if str(sip_ytd_performance_result[0])=='-0.00':
                                                sip_year_value = str(sip_ytd_performance_result[0]).replace('-','')
                                            else:
                                                sip_year_value = sip_ytd_performance_result[0]
                                            if  temp_validate_dataframe['IsSIValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(sip_year_value)== temp_validate_dataframe['SIPerformance'].values[0] and temp_validate_dataframe['IsSIValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:                                           
                                                    sip_reasons_list.append(i)
                                        else:
                                            testLog('Error in SIP')
                                    except Exception as e:
                                        testLog(e)


                                elif  final_inception_date<prev_last:
                                    print("line 659")
                                    sip_dated= temp_validate_dataframe['AsOfDate'].astype(str)
                                    sip_dates = sip_dated.values[0]
                                    sip_inception_date = datetime.strptime(sip_dates,"%Y%m%d")
                                    sip_inception_date = sip_inception_date.date()  
                                    sed_sip = sip_inception_date-final_inception_date
                                    number_of_sip_days = float(sed_sip.days)
                                    
                                    ending_date_string = str(account_dataframe['EndingDate'].values[0])                            
                                    date_string_change = change_timezone(ending_date_string)                          
                                    ending_dates =  np.array(np.datetime64(date_string_change))
                                    asof_date =  np.array(np.datetime64(str(inception_dataframe['AsOfDate'].values[0])))
                                    print(type(account_dataframe['EndingDate'].values[0]))
                                    print('ending date for account: {}    {}'.format(i,ending_dates))
                                    print(asof_date)
                                    if ending_dates<asof_date:
                                        sip_ytd_performance_result = ('0.00','0.00')
                                        ytd_performance_result = ('0.00','0.00')
                                        print("Line 670")
                                    else:
                                        print("Asd")
                                        if number_of_sip_days<1*year_value:
                                            sip_ytd_performance_result = sip_ytd_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                        else:
                                            sip_ytd_performance_result = sip_performance(prev_last,i,number_of_days,account_dataframe,date_calc,year_value,final_inception_date)
                                    try:
                                        if sip_ytd_performance_result is not None:
                                            temp_sip = str(temp_validate_dataframe['Perf_SI'].values[0]).split('.')
                                            temp_sip ='%s.%s' % (temp_sip[0], temp_sip[1][:2])
                                            # print(sip_year_value)
                                            # print(temp_validate_dataframe['SIPerformance'].values[0])
                                            if str(sip_ytd_performance_result[0])=='-0.00':
                                                sip_year_value = str(sip_ytd_performance_result[0]).replace('-','')
                                            else:
                                                sip_year_value = sip_ytd_performance_result[0]  
                                            if  temp_validate_dataframe['IsSIValidated'].values[0]=='0' :
                                                    testLog("Success")
                                            else:
                                                if str(sip_year_value)== temp_validate_dataframe['SIPerformance'].values[0] and temp_validate_dataframe['IsSIValidated'].values[0]=='1' :
                                                        testLog("Success")
                                                else:
                                                
                                                    sip_reasons_list.append(i)
                                        else:
                                            testLog("Error in YTD")

                                    except Exception as e:
                                        testLog(e)

                                
                except:
                    pass


                
    return five_year_reasons_list,three_year_reasons_list,one_year_reasons_list,sip_reasons_list,ytd_reasons_list,mismatch_accounts

def main_performance_engines():
    testLog("Code Execution for Validating the file Started")
    t1 = time.time()
    testLog(t1)
    column_name_dict  = {'Id':[],
            'Scenario':[],
            'Result':[],
            'Reason':[],
            'FileName':[],
        }


    validated_df = pd.DataFrame(column_name_dict)

    # Intializing Values 

    account_columns_name = config.account_dataframe_column_list
    file_path = config.accounts_file_path
    file_name = file_path.split('\\')[-1]
    year_value = config.year_value

    # Datalake connection created
    datalake_conn = datalake_connection()

    
    """
        code will execute query from perfromance summary that will return
        
            AccountID  -  unique Account Id for that Account
            InceptionDate - First Entry Recorded
            MonthEndDate -  Previous month end date
            AsOfDate  -
    """
    file_df = pd.read_sql_query(get_accounts_query,datalake_conn)

    # Tuple formed for Unique Account Numbers
    unique_account_number = tuple(file_df['AccountID'].unique())
    testLog('Number of Records Found {}'.format(len(unique_account_number)))
    all_accounts_start_time = time.time()

    # all_accounts_dataframe will have all entries from Current View Query for N number of Accounts
    all_accounts_dataframe =pd.DataFrame()

    # reconciled_dataframe will have all entries from Reconsiled Query  for N number of Accounts
    reconciled_dataframe = pd.DataFrame()
    five_year_reasons_list = []
    three_year_reasons_list = []
    one_year_reasons_list =[]
    sip_reasons_list = []
    ytd_reasons_list =[]
    mismatch_accounts = []

    testLog("I am at line 759")
    for i in range(0,len(unique_account_number),100):
      limit_range =i+100
      print(limit_range)
      datalake_conn = datalake_connection()
      """
                Query executed will return list of all entries in current view for accounts from tuple defined above and will create a dataframe
      """
      all_accounts_dataframe = pd.read_sql_query(get_account_data_query.format(unique_account_number[i:limit_range]),datalake_conn)
      reconciled_dataframe = pd.read_sql_query(is_validated_query.format(unique_account_number[i:limit_range]),datalake_conn)

      """
         Function will do calculation for accounts from range [i:limit_range]
      """
      all_results = get_results(all_accounts_dataframe,reconciled_dataframe,file_df,unique_account_number[i:limit_range],year_value)
      datalake_conn.close()
      five_year_reasons_list.extend(all_results[0])
      three_year_reasons_list.extend(all_results[1])
      one_year_reasons_list.extend(all_results[2])
      sip_reasons_list.extend(all_results[3])
      ytd_reasons_list.extend(all_results[4])
      mismatch_accounts.extend(all_results[5])

    testLog("Time Taken by currentview query to execute: {} seconds".format(time.time()-all_accounts_start_time))

    file_name = "Account"    
    if len(five_year_reasons_list)==0:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['five_scenario'], 'Pass','',str(file_name)]
    else:

        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['five_scenario'], 'Fail','Mismatch Account are:'+str(','.join(five_year_reasons_list)),str(file_name)]

    if len(three_year_reasons_list)==0:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['three_scenario'], 'Pass','',str(file_name)]
    else:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['three_scenario'], 'Fail','Mismatch Account are:'+str(','.join(three_year_reasons_list)),str(file_name)]

    if len(one_year_reasons_list)==0:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['one_scenario'], 'Pass','',str(file_name)]
    else:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['one_scenario'], 'Fail','Mismatch Account are:'+str(','.join(one_year_reasons_list)),str(file_name)]

    if len(sip_reasons_list)==0:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['sip_scenario'], 'Pass','',str(file_name)]
    else:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['sip_scenario'], 'Fail','Mismatch Account are:'+str(','.join(sip_reasons_list)),str(file_name)]

    if len(ytd_reasons_list)==0:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['ytd_scenario'], 'Pass','',str(file_name)]
    else:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['ytd_scenario'], 'Fail','Mismatch Account are:'+str(','.join(ytd_reasons_list)),str(file_name)]
    if len(mismatch_accounts)==0:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['absent_accounts'],'','',str(file_name)]
    else:
        validated_df.loc[len(validated_df.index)] = ['C0001',config.scenario_list['absent_accounts'], 'Fail','Mismatch Account are:'+str(','.join(mismatch_accounts)),str(file_name)]
    validated_df.to_excel('PE_Accounts.xlsx',sheet_name="Sheet 1",index=False)
    t2 = time.time()
    testLog(t2)
    
  