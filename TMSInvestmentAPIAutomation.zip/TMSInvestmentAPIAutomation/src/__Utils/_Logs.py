import logging
import inspect
from stat import filemode
import datetime

# class Logger:
def testLog(message,loglevel = logging.INFO):

    logger_name = inspect.stack()[1][3]
    logger = logging.getLogger(logger_name)
    if logger.hasHandlers():
        # Logger is already configured, remove all handlers
        logger.handlers = []
    logger.setLevel(loglevel)
    
    consoleHandler = logging.StreamHandler()
    # consoleHandler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s  %(levelname)s: %(message)s')
    fileHandler = logging.FileHandler(filename='TLH_logs.log')
    consoleHandler.setFormatter(formatter)
    fileHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)
    logger.addHandler(fileHandler)
    logger.info(message)

    return logger



