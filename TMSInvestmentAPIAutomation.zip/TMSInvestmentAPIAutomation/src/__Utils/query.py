query_variables = {
    "'add_setting'":{
		"'data'":"""select * from [dbo].[overlay_setting_audit] where overlay_setting_id = '{overlay_setting_id}' and status = 'Proposed'"""
	},
    "'approve_setting'":{
		"'status'":"""select status from overlay_setting_audit where overlay_setting_audit_id = '{overlay_setting_id}'"""
	},
    "'add_holding'":{
		"'data'":"""select * from [dbo].[external_holding] where account_id = '{account_id}'""",
        "'ext_holding_audit'":"""select * from [dbo].[external_holding_audit] where external_holding_id = '{external_holding_id}' and audit_time_start like '{audit_time_start}%'"""
	}
}
create_settings_overlay_setting_db_verification_query = """select * from [dbo].[overlay_setting_audit] where overlay_setting_id = '{overlay_setting_id}' and status = 'Proposed'"""

create_settings_data_db_verification_query = """select [data] FROM [dbo].[overlay_setting_audit]"""

approve_settings_status_verifcation_before_hit_query = """select status from overlay_setting_audit where overlay_setting_audit_id = '{overlay_setting_id}'"""

