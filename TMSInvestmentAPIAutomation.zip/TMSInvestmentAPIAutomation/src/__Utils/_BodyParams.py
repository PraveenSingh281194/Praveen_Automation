import pandas as pd
import json
# params_df = pd.read_excel('tms\src\__BodyParams\_BodyParams.xlsx',sheet_name='create_settings')
# params_df = params_df.to_json(orient="records")
# # result = json.dumps(json.loads(params_df),indent=4)
# # result = params_df.to_dict(orient='records')
# # result = json.dumps(r)
# result = json.loads(params_df)
# print(result)
# print(type(result))

def body_params(sheet_name:str)->list:
    """
    yes
    """
    # params_df = pd.DataFrame
    # params_df = pd.read_excel(r'C:\Users\Paritosh.Sharma\Documents\repos\TMSInvestmentAPIAutomation\src\__BodyParams\_BodyParams.xlsx',sheet_name=sheet_name).to_json(orient="records")
    params_df = pd.read_excel(r'C:\Users\Paritosh.Sharma\Documents\repos\TMSInvestmentAPIAutomation\src\__BodyParams\_BodyParams.xlsx',sheet_name=sheet_name)
    account_id = params_df['Account'].to_list()
    # return json.loads(params_df)
    return [account_id, params_df.iloc[:,1:].to_dict('records')]

