import requests as req,json
import sqlalchemy,time,pyodbc
from __Config import _Config
from __Utils._Logs import testLog

class Api():


    def Okta_Token_Call(self,post_api_url:str,api_username:str,api_password:str,payload:dict,header:dict)->req.models.Response:
        """
        post_api_url : the post api url to make a hit
        api_username : api usename for the verified user
        api_password : api_paswword for that particular username
        payload : api body
        header : head parameters
        
        return : returns the api response object
        """
        response = req.post(str(post_api_url),data=payload,auth=(str(api_username),str(api_password)),headers=header,verify = False)
        return response
        

    def Post_Call(self,post_api_url:str,payload=None,header=None)->req.models.Response:
        """
        post_api_url : the post api url to make a hit
        api_username : api usename for the verified user
        api_password : api_paswword for that particular username
        payload : api body
        header : head parameters
        
        return : returns the api response object
        """
        response = req.post(str(post_api_url),data=payload,headers=header,verify=False)
        return response


    def Status_Verify(self,response:req.models.Response, status_code)->str:
        """
        will verify the status_code of the response with the required one

        parameters:
            response : response of the api
            status : the required status code to be compared

        return:
            will return Pass(string) if the status code matches else return Fail(string)
        """
        if(int(response.status_code) == int(status_code)):
            return 'Pass'
        else:
            return 'Fail'

    
    def Get_Status(self,response:req.models.Response)->int:
        """
        given a response object will return the status code of the response

        parameters:
            response : response object of the api

        return:
            will return the status_code(int) of the response 
        """
        return response.status_code


    def Get_Call(self,get_api_url,header:dict)->req.models.Response:
        """
        will hit the get api url given header parameters of the API
        
        parameters:
            get_api_url : the get api url to make a hit
            header : head parameters of the API
        
        return:
            will return the response of the API
        """
        self.response = req.get(str(get_api_url),headers=header,verify=False)
        return self.response


    def fun():
        print()


    #demo = Logger()
    