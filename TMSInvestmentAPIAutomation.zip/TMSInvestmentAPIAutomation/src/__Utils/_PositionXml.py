import requests as req

def position_get_xml(api_xml_response:req.models.Response):
    for ele_1 in api_xml_response.findall('portfolioPositionsAccounts'):
        for ele_2 in api_xml_response.findall('portfolioPositionsAccounts'):
            
            for ele_3 in api_xml_response.findall('portfolioPositionsAccounts'):
                for ele_4 in api_xml_response.findall('portfolioPositionsAccounts'):
        