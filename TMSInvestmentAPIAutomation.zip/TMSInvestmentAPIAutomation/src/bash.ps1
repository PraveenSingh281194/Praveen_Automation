tags=''
behave -f allure_behave.formatter:AllureFormatter -o _Reports/ __Features/add_holding.feature tags
allure generate --clean _Reports\
python _FinalAllureReport.py