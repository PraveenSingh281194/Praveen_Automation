import json,os

cur_path = os.path.dirname(__file__)
file_path = cur_path+"\_Payload.json"

with open(file_path, 'r' ) as f:
    data = f.read()
    properties = json.loads(data)
    payload_variables = {
        "'add_setting'":{
            "C164454":properties['ADD_SETTING']['C164454'],
            "C165674":properties['ADD_SETTING']['C165674'],
            "C165675":properties['ADD_SETTING']['C165675'],
            "C165710":properties['ADD_SETTING']['C165710'],
            "C165676_A":properties['ADD_SETTING']['C165676_A'],
            "C165676_B":properties['ADD_SETTING']['C165676_B'],
            "C165676_C":properties['ADD_SETTING']['C165676_C'],
            "C165676_D":properties['ADD_SETTING']['C165676_D'],
            "C165676_E":properties['ADD_SETTING']['C165676_E'],
            "C165676_F":properties['ADD_SETTING']['C165676_F'],
            "C165676_G":properties['ADD_SETTING']['C165676_G'],
            "C165711":properties['ADD_SETTING']['C165711'],
            "C165712":properties['ADD_SETTING']['C165712'],
            "C165714":properties['ADD_SETTING']['C165714'],
            "C166434":properties['ADD_SETTING']['C166434'],
            "C166435":properties['ADD_SETTING']['C166435'],
            "C166436":properties['ADD_SETTING']['C166436'],
        },
        "'add_holding'":{
            "C165925":properties['ADD_HOLDING']['C165925'],
            "C165931_A":properties['ADD_HOLDING']['C165931_A'],
            "C165931_B":properties['ADD_HOLDING']['C165931_B'],
            "C165931_C":properties['ADD_HOLDING']['C165931_C'],
            "C165931_D":properties['ADD_HOLDING']['C165931_D'],
            "C165931_E":properties['ADD_HOLDING']['C165931_E'],
            "C166434":properties['ADD_HOLDING']['C166434'],
            "C166435":properties['ADD_HOLDING']['C166435'],
            "C166439":properties['ADD_HOLDING']['C166439'],
            "C172359":properties['ADD_HOLDING']['C172359'],
            "C172492":properties['ADD_HOLDING']['C172492'],
            "C172360":properties['ADD_HOLDING']['C172360'],
            "C172489":properties['ADD_HOLDING']['C172489'],
            "C172491":properties['ADD_HOLDING']['C172491'],
            "C172493":properties['ADD_HOLDING']['C172493'],
            "C172494":properties['ADD_HOLDING']['C172494'],
            "C172495":properties['ADD_HOLDING']['C172495'],
            "C166442":properties['ADD_HOLDING']['C166442'],
            "C172361":properties['ADD_HOLDING']['C172361'],
            "C172362":properties['ADD_HOLDING']['C172362'],
            "C172363":properties['ADD_HOLDING']['C172363'],
            "C172364":properties['ADD_HOLDING']['C172364'],
            "C172365":properties['ADD_HOLDING']['C172365'],
            "C172366":properties['ADD_HOLDING']['C172366'],
            "C172367":properties['ADD_HOLDING']['C172367'],
            "C172490":properties['ADD_HOLDING']['C172490'],
            "C172368":properties['ADD_HOLDING']['C172368'],
            "C172531":properties['ADD_HOLDING']['C172531'],
            "C172354":properties['ADD_HOLDING']['C172354'],
            "C172355":properties['ADD_HOLDING']['C172355'],
            "C172356":properties['ADD_HOLDING']['C172356'],
            "C173516":properties['ADD_HOLDING']['C173516'],
            "C172357":properties['ADD_HOLDING']['C172357'],
            "C172421":properties['ADD_HOLDING']['C172421'],
            "C166440_A":properties['ADD_HOLDING']['C166440_A'],
            "C166440_B":properties['ADD_HOLDING']['C166440_B'],
        }
    }