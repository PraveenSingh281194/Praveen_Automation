import json,os

cur_path = os.path.dirname(__file__)
file_path = cur_path+"\_Configurations.json"

with open(file_path, 'r' ) as f:
    data = f.read()
    properties = json.loads(data)
    env = properties['env']