import json,os

cur_path = os.path.dirname(__file__)
file_path = cur_path+"\_Error.json"

with open(file_path, 'r' ) as f:
    data = f.read()
    properties = json.loads(data)
    error_variables = {
        "'add_setting'":{
            "C165674":properties['ADD_SETTING']['C165674'],
            "C165675":properties['ADD_SETTING']['C165675'],
            "C165710":properties['ADD_SETTING']['C165710'],
        },
        "'add_holding'":{
            "C165925":properties['ADD_HOLDING']['C165925'],
            "C172359":properties['ADD_HOLDING']['C172359'],
            "C172492":properties['ADD_HOLDING']['C172492'],
            "C172360":properties['ADD_HOLDING']['C172360'],
            "C172491":properties['ADD_HOLDING']['C172491'],
            "C172493":properties['ADD_HOLDING']['C172493'],
            "C172494":properties['ADD_HOLDING']['C172494'],
            "C172495":properties['ADD_HOLDING']['C172495'],
            "C166442":properties['ADD_HOLDING']['C166442'],
            "C172363":properties['ADD_HOLDING']['C172363'],
            "C172364":properties['ADD_HOLDING']['C172364'],
            "C172367":properties['ADD_HOLDING']['C172367'],
    }
    }