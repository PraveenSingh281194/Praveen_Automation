import subprocess,sys
if __name__=='__main__':
    p = subprocess.Popen('powershell.exe -ExecutionPolicy RemoteSigned -file "C:\\Users\\Praveen.Singh\\Documents\\TMSInvestmentAPIAutomation\\src\\bash.ps1"',stdout=sys.stdout)
    p.communicate()