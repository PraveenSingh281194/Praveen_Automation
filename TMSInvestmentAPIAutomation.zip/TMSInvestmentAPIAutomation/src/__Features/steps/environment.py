from behave import fixture

@fixture
def before_feature(context, feature):
    if 'expensive_setup' in feature.tags:
        context.execute_steps('''
            Given some setup condition that only runs once per feature
              And some other run once setup action
        ''')

# def before_feature(context, feature): print("Runs Before Each Feature")

# def after_feature(context, feature): print("Run After Each Feature")

# def before_scenario(context, scenario): print("Run Before Each Scenario")

# def after_scenario(context, scenario): print("Run After Each Scenario")