from __Utils import _Db
from __Utils import _BodyParams,_Logs,query,_PostCall
from __Config import _Config,_Payload,_Error,_Configurations
import requests as req,pandas as pd
import json
from behave import *
from datetime import datetime
import allure,random,string
from deepdiff import DeepDiff


class TMS():

    @Given('setup env')
    def Setup_Env(self):
        self.env = _Configurations.env
        allure.attach(self.env,'env', allure.attachment_type.TEXT)
        assert self.env

    
    @Given('The url setup for the POST request {api_endpoint}') 
    def Get_Api_Url(self,api_endpoint):
        self.api_endpoint = api_endpoint
        self.url = _Config.json_variables[self.env][self.api_endpoint]["'url'"]
        allure.attach(self.url,'url', allure.attachment_type.TEXT)
        assert self.url

    
    @Given('user setup the basic authentication by adding {username} and {password}')
    def Get_Auth_Params(self,username,password):
        self.username,self.password = _Config.json_variables[self.env][self.api_endpoint][username], _Config.json_variables[self.env][self.api_endpoint][password]
        assert self.username,self.password


    @Given('user setup the {header} for {api_endpoint} endpoint')
    def Get_Header(self,header,api_endpoint):
        self.api_endpoint = api_endpoint
        self.header = _Config.json_variables[self.env][self.api_endpoint][header]
        allure.attach(f'{json.dumps(self.header,indent=4)}','Header', allure.attachment_type.TEXT)
        assert self.header


    @Given('user setup the {payload} for post request token generation')
    def Get_Payload_Okta_Token(self,payload):
        self.payload = _Config.json_variables[self.env][self.api_endpoint][payload]
        allure.attach(f'{json.dumps(self.payload,indent=4)}','payload', allure.attachment_type.TEXT)
        assert self.payload


    @Then('user verify the okta status code as {status_code}')
    def Auth_Token(self,status_code):
        api = _PostCall.Api()
        self.response = api.Okta_Token_Call(self.url,self.username,self.password,self.payload,self.header) 
        result = api.Status_Verify(self.response,status_code.encode())
        allure.attach(str(api.Get_Status(self.response)),'Status Code', allure.attachment_type.TEXT)
        assert result =='Pass', f'Staus Code mismatched with status code {api.Get_Status(self.response)}'


    @Then('user retrieve the key value from result {key_from_response}')
    def Get_Token(self,key_from_response):
        self.token = json.loads(self.response.text)[key_from_response]
        assert self.token


    @Given('okta token added to the header of {api_endpoint}')
    def Add_Token_To_Header(self,api_endpoint):
        _Config.json_variables[self.env][api_endpoint]["'header'"]['Authorization'] = "Bearer " + str(self.token)


    @Given('user setup the endpoint {api_endpoint} for Account {account_id}')
    def Get_Add_Setting_Api_Url(self,api_endpoint,account_id):
        self.api_endpoint = api_endpoint
        self.account_id = account_id
        self.url = _Config.json_variables[self.env][self.api_endpoint]["'url'"]+str(account_id)
        allure.attach(self.url,'url', allure.attachment_type.TEXT)
        assert self.url


    @Given('setup the endpoint {api_endpoint} without parameter')
    def Get_URL_Without_Parameter(self,api_endpoint):
        self.url = _Config.json_variables[self.env][api_endpoint]["'url'"].format('')
        allure.attach(self.url,'url', allure.attachment_type.TEXT)
        assert self.url


    @Given('user setup the {payload} for {api_endpoint} for testcase {test_case}')
    def Get_Headers(self,payload,api_endpoint,test_case):
        
        self.api_endpoint,self.test_case = api_endpoint,test_case
        self.payload = _Payload.payload_variables[self.api_endpoint][self.test_case]
        print(self.payload)
        allure.attach(json.dumps(self.payload),'payload',allure.attachment_type.TEXT)
        assert self.payload
        
    

    @Then('user verify the status code as {status_code}')
    def Verify_Status(self,status_code):
        api = _PostCall.Api()
        self.response = api.Post_Call(self.url,payload = json.dumps(self.payload),header = self.header)
        result = api.Status_Verify(self.response,status_code)
        print(self.response.text)
        assert result =='Pass', f'Staus Code mismatched with status code {api.Get_Status(self.response)}'

    @Then('for get holding user verify the {status_code}')
    def get_external_holding_status_verify(self,status_code):
        api = _PostCall.Api()
        self.response = api.Get_Call(self.url,header = self.header)
        assert int(self.response.status_code)==int(status_code),f'Staus Code mismatched with status code {self.response.status_code}'


    @Then('Validate Server response for bad request')
    def Verify_Server_Response(self):
        api = _PostCall.Api()
        self.response = api.Post_Call(self.url,payload = json.dumps(self.payload),header = self.header)
        result= self.response.text
        assert result =='"AccountId will accept only uppercase letters, numbers (i.e. A-Z or 0-9) and max lengh 10."', f'Wrong text provided, server rsponse is {self.response.text}'

    @Then('attach server text')
    def Attach_Server_Text(self):
        allure.attach(self.response.text,'Server Text',allure.attachment_type.TEXT)

    @Then('user retreive the overlay setting id from location header in the response')
    def Retreive_Setting_Id(self):
        self.setting_id = self.response.headers['Location'].split('/')[-1]
        allure.attach(self.setting_id,'overlay setting id',allure.attachment_type.TEXT)
        assert self.setting_id

    @Then('the user retreive the account id from location header in the response')
    def Retreive_Setting_Id(self):
        self.account_id = self.response.headers['Location'].split('/')[-1]
        allure.attach(self.account_id,'account id',allure.attachment_type.TEXT)
        assert self.account_id

    
    @Then('user verify the {data} from DB')
    def Verify_From_Db(self,data):
        db = _Db.Db()
        self.conn = db.Azure_Db_connection()
        db_response = pd.read_sql_query(query.query_variables[self.api_endpoint][data].format(overlay_setting_id = self.setting_id),self.conn)
        assert len(db_response) == 1,allure.attach('data not validated','error msg',allure.attachment_type.TEXT)
        assert len(DeepDiff(self.payload,json.loads(db_response['data'].to_dict()[0]))) == 0,allure.attach('data entry in db does not match','error msg',allure.attachment_type.TEXT)

    @Then('for add holding user verify {data} from DB')
    def Verify_From_Db(self,data):
        db = _Db.Db()
        self.conn = db.Azure_Db_connection()
        db_response = pd.read_sql_query(query.query_variables[self.api_endpoint][data].format(account_id = self.account_id),self.conn)
        assert len(db_response) == 1,allure.attach('data not validated','error msg',allure.attachment_type.TEXT)
        assert len(DeepDiff(self.payload,json.loads(db_response['data'].to_dict()[0]))) == 0,allure.attach('data entry in db does not match','error msg',allure.attachment_type.TEXT)
    
    @Then('for add holding with {deepdiff_data} user verify {data} from DB')
    def Verify_From_deepdiff_data_with_Db(self,data,deepdiff_data):
        db = _Db.Db()
        self.conn = db.Azure_Db_connection()
        db_response = pd.read_sql_query(query.query_variables[self.api_endpoint][data].format(account_id = self.account_id),self.conn)
        self.external_holding_id=db_response['external_holding_id'].values.tolist()[0]
        self.data=json.loads(db_response['data'].to_dict()[0])
        print(DeepDiff(self.payload,json.loads(db_response['data'].to_dict()[0])))
        assert str(DeepDiff(self.payload,json.loads(db_response['data'].to_dict()[0])))==str(deepdiff_data),allure.attach('data entry in db does not match','error msg',allure.attachment_type.TEXT)
        #assert False
    @Then('for {ext_holding_audit} add holding user verify from DB')
    def Verify_From_ext_holding_audit_Db(self,ext_holding_audit):
        self.audit_time_start=datetime.today().strftime('%Y-%m-%d')
        db = _Db.Db()
        self.conn = db.Azure_Db_connection()
        self.ext_holding_audit_db_response = pd.read_sql_query(query.query_variables[self.api_endpoint][ext_holding_audit].format(external_holding_id = self.external_holding_id,audit_time_start=self.audit_time_start),self.conn)
        assert len(self.ext_holding_audit_db_response)==1,allure.attach('data entry in db does not match','error msg',allure.attachment_type.TEXT)
    
    @Then('User validates the get external holding data with DB')
    def Verify_From_get_ext_holding(self):
         api = _PostCall.Api()
         self.response = api.Get_Call(self.url,header = self.header)
         self.ext_holding_response_payload=json.loads(self.response.text)[0]
         replacement={"securityIdentifier":"SecurityIdentifier","quantity":"Quantity","costBasis":"CostBasis","purchaseDate":"PurchaseDate","term":"Term","currentMarketValue":"CurrentMarketValue",
                      "proxySecurityIdentifier":"ProxySecurityIdentifier","isCash":"IsCash","other":"Other"}
        #  ini_key_names=list(self.data[0].keys())        #can change this to a dictionary key mapping object 
        #  ext_holding_response_payload_dict=[dict(zip(ini_key_names,list(ext_holding_response_payload.values())))]
         for k,v in list(self.ext_holding_response_payload.items()):
             self.ext_holding_response_payload[replacement.get(k, k)] = self.ext_holding_response_payload.pop(k)   
         assert len(DeepDiff(str(self.data),str([self.ext_holding_response_payload])))==0,allure.attach('data entry in db does not match','error msg',allure.attachment_type.TEXT)

    @Given('user setup the endpoint {api_endpoint} for {id}')
    def Get(self,api_endpoint,id):
        self.url = _Config.json_variables[self.env][api_endpoint]["'url'"].format(id)
        allure.attach(self.url,'url', allure.attachment_type.TEXT)
        assert self.url

    @Given('create Uppercase random account id for testing')
    def create_random_account_id(self):
        random_account_length = random.randint(2,8)
        res = ''.join(random.choices(string.ascii_uppercase +string.digits, k=random_account_length))
        self.random_account_id= 'TA'+str(res)

    @Given('create lowercase random account id for testing')
    def create_random_account_id(self):
        random_account_length = random.randint(2,8)
        res = ''.join(random.choices(string.ascii_uppercase +string.digits, k=random_account_length))
        self.random_account_id= 'ta'+str(res)

    @Given('user setup the endpoint {api_endpoint}')
    def Get(self,api_endpoint):
        self.url = _Config.json_variables[self.env][api_endpoint]["'url'"].format(self.random_account_id)
        allure.attach(self.url,'url', allure.attachment_type.TEXT)
        assert self.url

    @Given('setup the endpoint {api_endpoint} for setting_id from create setting')
    def Get(self,api_endpoint):
        self.url = _Config.json_variables[self.env][api_endpoint]["'url'"].format(self.setting_id)
        allure.attach(self.url,'url', allure.attachment_type.TEXT)
        assert self.url
    

    @Then('verify that all aacounts in response have status {status}')
    def Verify_Get_Setting_By_Status_Response_Status(self,status):
        temp = []
        for ele in json.loads(self.response.text):
            if(ele['status'] != status):
                temp.append(ele['id'])
        assert len(temp) == 0,allure.attach(temp,'mismatched IDs',allure.attachment_type.TEXT)


    @Then('verify the status code as {status_code}')
    def Verify_Status_Get_Call(self,status_code):
        api = _PostCall.Api()
        self.response = api.Get_Call(self.url,header = self.header)
        result = api.Status_Verify(self.response,status_code)
        assert result =='Pass', f'Staus Code mismatched with status code {api.Get_Status(self.response)}'


    @Given('TMS setting is provided in {sheet_name}')
    def get_body(self,sheet_name):
        self.body = _BodyParams.body_params(sheet_name)[1]
        self.account_id = _BodyParams.body_params(sheet_name)[0]
        allure.attach(f'{len(self.body)}','number of parameters with which tested', allure.attachment_type.TEXT)
        assert self.body


    @Given('appending account id for {index}')
    def Append_Account_Id(self,index):
        self.index = int(index)
        self.url = self.url + str(self.account_id[self.index])


    @Then('attach error')
    def Attach_Error(self):
        _Logs.testLog(f"errors = {self.response.json()['errors']}")
        allure.attach(f"errors = {json.dumps(self.response.json()['errors'],indent=4)}",'errors', allure.attachment_type.TEXT)


    @Then('validate error')
    def Validate_Error(self):
        assert(len(DeepDiff(self.response.json()['errors'],_Error.error_variables[self.api_endpoint][self.test_case])) ==0)



