from allure_combine import combine_allure
import os
import datetime

# 1) Create complete.html in allure-generated folder
combine_allure(r"C:\\Users\\Praveen.Singh\\Documents\\TMSInvestmentAPIAutomation\\src\\allure-report")

#2) Create complete.html in specified folder
combine_allure(r"C:\\Users\\Praveen.Singh\\Documents\\TMSInvestmentAPIAutomation\\src\\allure-report", 
               dest_folder=r"C:\Users\Praveen.Singh\Documents\TMSInvestmentAPIAutomation\src\tmp")

# 3) Make sure that desssst folder exists, create if not
combine_allure(
    r"C:\\Users\\Praveen.Singh\\Documents\\TMSInvestmentAPIAutomation\\src\\allure-report",
    dest_folder=r"C:\Users\Praveen.Singh\Documents\TMSInvestmentAPIAutomation\src\tmp",
    auto_create_folders=True
)

# 4) Remove sinon.js and server.js from allure folder after complete.html is generated:
combine_allure(
    r"C:\\Users\\Praveen.Singh\\Documents\\TMSInvestmentAPIAutomation\\src\\allure-report",
    remove_temp_files=True
)

# 5) If html/json files what should be utf-8 is has broken encoding, ignore errors:
combine_allure(
    r"C:\\Users\\Praveen.Singh\\Documents\\TMSInvestmentAPIAutomation\\src\\allure-report",
    ignore_utf8_errors=True
)


# get the current date and time
dt = datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S")
old_name=r'C:\Users\Praveen.Singh\Documents\TMSInvestmentAPIAutomation\src\tmp\complete.html'
new_name =  r'C:\Users\Praveen.Singh\Documents\TMSInvestmentAPIAutomation\src\tmp\complete '+dt+'.html'
os.rename(old_name,new_name)